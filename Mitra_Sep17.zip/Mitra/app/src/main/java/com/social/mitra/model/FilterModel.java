package com.social.mitra.model;

import java.util.ArrayList;

public class FilterModel {
    private ArrayList<ProfessionalNameList> profNameLists;
    private ArrayList<CityList> cityNameLists;

    public FilterModel(ArrayList<ProfessionalNameList> profNameLists, ArrayList<CityList> cityNameLists) {
        this.profNameLists = profNameLists;
        this.cityNameLists = cityNameLists;
    }

    public ArrayList<ProfessionalNameList> getProfNameLists() {
        return profNameLists;
    }

    public void setProfNameLists(ArrayList<ProfessionalNameList> profNameLists) {
        this.profNameLists = profNameLists;
    }

    public ArrayList<CityList> getCityNameLists() {
        return cityNameLists;
    }

    public void setCityNameLists(ArrayList<CityList> cityNameLists) {
        this.cityNameLists = cityNameLists;
    }
}
