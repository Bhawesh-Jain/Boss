package com.social.mitra.fragments;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.social.mitra.UI.NewsFragment;

public class ListingTabsAdapter extends FragmentPagerAdapter {

    int totalTabs;
    private Context context;
    String user_id;

    public ListingTabsAdapter(FragmentManager fm, Context context, int totalTabs, String user_id) {
        super(fm);
        this.context = context;
        this.totalTabs = totalTabs;
        this.user_id=user_id;
    }


    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                NewsFragment fragment11 = new NewsFragment();
                return fragment11;
            case 1:
                ShareFragment fragment22 = new ShareFragment();
                return fragment22;

            default:
                return null;
        }
    }




    @Override
    public int getCount() {
        return totalTabs;
    }
}

