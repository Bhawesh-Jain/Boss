package com.social.mitra.fragments;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_all_categories_users;
import static com.social.mitra.util.BaseUrl.get_my_design;

import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;
import com.social.mitra.adapter.DesignAdapter;
import com.social.mitra.model.DesignModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DesignIndeFragment extends Fragment {

    private final String TAG = DesignIndeFragment.class.getSimpleName();
    TextView nearme, nearme1, kitchen, kitchen1, badroom, badroom1, rates1, rates;
    RecyclerView design_recycler;
    private ArrayList<DesignModel> designModels = new ArrayList<>();
    private Session session;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_design_inde, container, false);
        session = new Session(getContext());

        kitchen = root.findViewById(R.id.kitchen);
        badroom = root.findViewById(R.id.badroom);
        nearme = root.findViewById(R.id.nearme);
        rates = root.findViewById(R.id.rates);

        kitchen1 = root.findViewById(R.id.kitchen1);
        badroom1 = root.findViewById(R.id.badroom1);
        nearme1 = root.findViewById(R.id.nearme1);
        rates1 = root.findViewById(R.id.rates1);

        design_recycler = root.findViewById(R.id.design_recycler);

        kitchen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kitchen.setVisibility(View.GONE);
                kitchen1.setVisibility(View.VISIBLE);
                kitchen1.setBackgroundResource(R.drawable.background_greenovel);
                kitchen1.setTextColor(getResources().getColor(R.color.white));
            }
        });

        kitchen1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kitchen1.setVisibility(View.GONE);
                kitchen.setVisibility(View.VISIBLE);
            }
        });

        nearme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nearme.setVisibility(View.GONE);
                nearme1.setVisibility(View.VISIBLE);
                nearme1.setBackgroundResource(R.drawable.background_greenovel);
                nearme1.setTextColor(getResources().getColor(R.color.white));
            }
        });

        nearme1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nearme1.setVisibility(View.GONE);
                nearme.setVisibility(View.VISIBLE);
            }
        });

        rates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rates.setVisibility(View.GONE);
                rates1.setVisibility(View.VISIBLE);
                rates1.setBackgroundResource(R.drawable.background_greenovel);
                rates1.setTextColor(getResources().getColor(R.color.white));
            }
        });

        rates1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rates1.setVisibility(View.GONE);
                rates.setVisibility(View.VISIBLE);
            }
        });

        badroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                badroom.setVisibility(View.GONE);
                badroom1.setVisibility(View.VISIBLE);
                badroom1.setBackgroundResource(R.drawable.background_greenovel);
                badroom1.setTextColor(getResources().getColor(R.color.white));
            }
        });
        badroom1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                badroom1.setVisibility(View.GONE);
                badroom.setVisibility(View.VISIBLE);
            }
        });
        get_design();

        return root;
    }

    private void get_design() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_my_design, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.d(TAG, "get_design onResponse() called with: response = [" + response + "]");
                    if (jsonObject.getString("result").equals("true")) {
                        designModels.clear();
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        String path = jsonObject.getString("path");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObject = jsonArray.getJSONObject(i);

                            DesignModel designModel = new DesignModel(
                                    dataObject.getString("id"),
                                    dataObject.getString("file"));
                            designModels.add(designModel);
                        }
                        RecyclerView.LayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                        design_recycler.setLayoutManager(layoutManager);
                        design_recycler.setAdapter(new DesignAdapter(designModels, getContext(), path));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Log.e(TAG, "onErrorResponse: Material Support", error)) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", session.getUser_Id());
                Log.e(TAG, "  Params: " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }
}