package com.social.mitra.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;

import org.json.JSONException;
import org.json.JSONObject;

public class ForgotPasswordActivity extends AppCompatActivity {

    TextView cancel_tv;
    Button forget_pass_send;
    EditText forget_password_mobile_edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        forget_password_mobile_edt = findViewById(R.id.forget_password_mobile_edt);
        forget_pass_send = findViewById(R.id.forget_pass_send);
        cancel_tv = findViewById(R.id.Cancel);



        forget_pass_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(forget_password_mobile_edt.getText().toString().equals("")){

                    checkMobileNo(forget_password_mobile_edt.getText().toString());
                }else {

                    forget_password_mobile_edt.setFocusable(true);
                    forget_password_mobile_edt.setError("Enter Mobile No");

                }

            }
        });

    }

    private void checkMobileNo(String mobile) {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){


        };
    }
}