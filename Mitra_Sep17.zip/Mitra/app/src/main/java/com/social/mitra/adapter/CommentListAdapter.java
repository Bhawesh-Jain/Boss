package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.model.CommentListModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommentListAdapter extends RecyclerView.Adapter<CommentListAdapter.MyViewHolder> {

    Context context;
    ArrayList<CommentListModel> commentListModels;

    public CommentListAdapter(Context context, ArrayList<CommentListModel> commentListModels) {
        this.context = context;
        this.commentListModels = commentListModels;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.comment_list_lay, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull CommentListAdapter.MyViewHolder holder, int position) {

        if(commentListModels.size()>0)
        {
            CommentListModel commentListModel = commentListModels.get(position);

            holder.comment_user_name.setText(commentListModel.getUserName());
            holder.commnet_tv.setText(commentListModel.getUserComment());
            holder.time_ago.setText(commentListModel.getTime_ago());
            holder.total_comment_likes.setText(commentListModel.getTotalLike());

            holder.like_comment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return commentListModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        CircleImageView user_img;
        TextView comment_user_name, commnet_tv, time_ago, total_comment_likes;
        ImageView like_comment;

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            user_img = itemView.findViewById(R.id.user_img);
            comment_user_name = itemView.findViewById(R.id.comment_user_name);
            commnet_tv = itemView.findViewById(R.id.commnet_tv);
            time_ago = itemView.findViewById(R.id.time_ago);
            total_comment_likes = itemView.findViewById(R.id.total_comment_likes);
            like_comment = itemView.findViewById(R.id.like_comment);

        }
    }
}
