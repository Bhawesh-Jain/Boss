package com.social.mitra.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.activity.BuyLeadActivity;
import com.social.mitra.model.SearchProductModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class SearchProductAdapter extends RecyclerView.Adapter<SearchProductAdapter.MyViewHolder> {

    Context context;
    ArrayList<SearchProductModel> searchProductModels;


    public SearchProductAdapter(Context context, ArrayList<SearchProductModel> searchProductModels) {
        this.context = context;
        this.searchProductModels = searchProductModels;
    }

    @NonNull
    @NotNull
    @Override
    public SearchProductAdapter.MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.search_product_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull SearchProductAdapter.MyViewHolder holder, int position) {

        if (searchProductModels.size() > 0) {
            SearchProductModel searchProductModel = searchProductModels.get(position);

            holder.post_date.setText(searchProductModel.getPost_date());
            holder.post_qty.setText("Quantity: "+searchProductModel.getPost_qty());
            holder.post_of_discharge.setText("Part Of Discharge "+searchProductModel.getPost_of_discharge());
            holder.post_discription.setText(searchProductModel.getPost_discription());
            holder.country_name.setText(searchProductModel.getCountry_name());



            holder.interasted_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(context, BuyLeadActivity.class);
                    intent.putExtra("product_id",searchProductModel.getProduct_id());
                    context.startActivity(intent);
                }
            });

        }else {
            Toast.makeText(context, "No Product Found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return searchProductModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView country_name,post_discription,post_qty,post_of_discharge,post_date;

        Button interasted_tv;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            country_name = itemView.findViewById(R.id.country_name);
            post_discription = itemView.findViewById(R.id.post_discription);
            post_qty = itemView.findViewById(R.id.post_qty);
            post_of_discharge = itemView.findViewById(R.id.post_of_discharge);
            interasted_tv = itemView.findViewById(R.id.interasted_tv);
            post_date = itemView.findViewById(R.id.post_date);

        }
    }
}
