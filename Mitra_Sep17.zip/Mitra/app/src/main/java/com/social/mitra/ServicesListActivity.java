package com.social.mitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ServicesListActivity extends AppCompatActivity {
    TextView question1;
    LinearLayout ans1,ans12,ans123,ans1234;
    TextView question12;
    TextView question123;
    TextView question1234;
    RelativeLayout isclick1;
    Button continuee;
    ImageView backbutton;
    boolean clicked = false;
    boolean clicked2 = false;
    boolean clicked3 = false;
    boolean clicked4 = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services_list);

        question1 = findViewById(R.id.question1);
        question12 = findViewById(R.id.question12);
        question123 = findViewById(R.id.question123);
        question1234 = findViewById(R.id.question1234);
        isclick1 = findViewById(R.id.isclick1);
        ans1 = findViewById(R.id.ans1);
        ans12 = findViewById(R.id.ans12);
        ans123 = findViewById(R.id.ans123);
        ans1234 = findViewById(R.id.ans1234);
        continuee = findViewById(R.id.continuee);
        backbutton = findViewById(R.id.backbutton);


        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServicesListActivity.this, UpdateDetailsActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.enter, R.anim.exit);

            }
        });


      continuee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServicesListActivity.this, UpdateDetailsActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.enter, R.anim.exit);

            }
        });






        question1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (clicked) {
                    ans1.setVisibility(View.GONE);

                    question1.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand, //left
                            0);

                    clicked = false;
                } else {
                    ans1.setVisibility(View.VISIBLE);
                    question1.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand_less, //left
                            0);
                    clicked = true;
                }

            }
        });

        question12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (clicked2) {
                    ans12.setVisibility(View.GONE);

                    question12.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand, //left
                            0);

                    clicked2 = false;
                } else {
                    ans12.setVisibility(View.VISIBLE);
                    question12.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand_less, //left
                            0);

                    clicked2 = true;
                }

            }
        });

        question123.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (clicked3) {
                    ans123.setVisibility(View.GONE);

                    question123.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand, //left
                            0);

                    clicked3 = false;
                } else {
                    ans123.setVisibility(View.VISIBLE);
                    question123.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand_less, //left
                            0);
                    clicked3 = true;
                }

            }
        });

        question1234.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (clicked4) {
                    ans1234.setVisibility(View.GONE);

                    question1234.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand, //left
                            0);

                    clicked4 = false;
                } else {
                    ans1234.setVisibility(View.VISIBLE);
                    question1234.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_baseline_expand_less, //left
                            0);
                    clicked4 = true;
                }

            }
        });


    }
}