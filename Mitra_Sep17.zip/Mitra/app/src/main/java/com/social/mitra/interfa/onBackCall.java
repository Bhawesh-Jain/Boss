package com.social.mitra.interfa;

public interface onBackCall {
    void onBackPress();


}
