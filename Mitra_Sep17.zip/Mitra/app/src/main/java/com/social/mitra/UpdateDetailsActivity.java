package com.social.mitra;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.IMAGE_URL;
import static com.social.mitra.util.BaseUrl.get_cities;
import static com.social.mitra.util.BaseUrl.get_profile;
import static com.social.mitra.util.BaseUrl.subCatArray;
import static com.social.mitra.util.BaseUrl.update_extra_detail;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.core.motion.utils.Oscillator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.adapter.User_Selected_SubCateAdapter;
import com.social.mitra.model.CityList;
import com.social.mitra.model.UserSelected_Subcat;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UpdateDetailsActivity extends AppCompatActivity {
    TextView upload_updates, full_services;
    ImageView back_img;
    Session session;
    EditText full_name_edt,
            type_location,
            type_language,
            type_company_socialmedia;

    ArrayList<CityList> simple_months = new ArrayList<>();
    ArrayAdapter<String> spinnermnthArrayAdapter;
    ArrayList<String> monthlist = new ArrayList<>();
    String about = "", location = "", social_media = "", language = "";
    LinearLayout llsubcat;
    RecyclerView rvsubcat;
    TextView txtcat;
    boolean flag = false;
    User_Selected_SubCateAdapter user_selected_subCateAdapter;
    ArrayList<UserSelected_Subcat> userSelected_subcats = new ArrayList<>();

    @Override
    protected void onResume() {
        super.onResume();
        if (flag)
            subCatArray(session.getUser_Id());
        flag = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_details);
        session = new Session(getApplicationContext());
        upload_updates = findViewById(R.id.upload_updates);
        full_services = findViewById(R.id.full_services);
        back_img = findViewById(R.id.back_img);

        rvsubcat = findViewById(R.id.rvsubcat);
        llsubcat = findViewById(R.id.llsubcat);

        full_name_edt = findViewById(R.id.full_name_edt);
        type_location = findViewById(R.id.type_location);
        type_language = findViewById(R.id.type_language);
        txtcat = findViewById(R.id.txtcat);
        type_company_socialmedia = findViewById(R.id.type_company_socialmedia);

        back_img.setOnClickListener(v -> {
            Intent intent = new Intent(UpdateDetailsActivity.this, HomeActivity.class);
            startActivity(intent);
        });


        upload_updates.setOnClickListener(v -> {
            about = full_name_edt.getText().toString();
            location = type_location.getText().toString();
            social_media = type_language.getText().toString();
            language = type_company_socialmedia.getText().toString();

            update_extra_detail();
        });


        full_services.setOnClickListener(v -> {

            Intent intent = new Intent(UpdateDetailsActivity.this, ServicesListActivity.class);
            startActivity(intent);
        });
        txtcat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ProfessionalCategoryListUpdate.class);
                startActivity(intent);
            }
        });

        Get_Profile(session.getUser_Id());
        get_cities();
        subCatArray(session.getUser_Id());


    }

    private void Get_Profile(String user_id) {
        Log.e(TAG, "ProfileFragment_Get_Profile: ");
        ProgressDialog progressDialog = new ProgressDialog(UpdateDetailsActivity.this);
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, "onResponse: ProfileFragment_Get_Profile     " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String User_id = data.getString("id");
                        String name__ = data.getString("name");
                        String First_name = data.getString("fname");
                        String Last_name = data.getString("lname");
                        String Mobile_ = data.getString("mobile");
                        String TYPE = data.getString("type");
                        String IMAGGE = data.getString("image");
                        String company = data.getString("company");
                        String language = data.getString("language");
                        String social_media = data.getString("social_media");
                        String category_id = data.getString("category_id");
                        String second_category_id = data.getString("second_category_id");
                        String category_name = data.getString("category_name");
                        String location = data.getString("location");
                        String about = data.getString("bio");
                        txtcat.setText(category_name);
                        full_name_edt.setText(name__);
                        type_location.setText(location);
                        type_language.setText(language);
                        type_company_socialmedia.setText(social_media);

                        Log.e(TAG, "onResponse: " + IMAGE_URL + IMAGGE);

                        if (TYPE.equalsIgnoreCase("service_provider")) {

                            llsubcat.setVisibility(View.VISIBLE);
                            txtcat.setVisibility(View.VISIBLE);

                        } else if (TYPE.equalsIgnoreCase("material_supplier")) {
                            llsubcat.setVisibility(View.VISIBLE);
                            txtcat.setVisibility(View.VISIBLE);

                        } else {
                            llsubcat.setVisibility(View.GONE);
                            txtcat.setVisibility(View.GONE);
                        }

                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "--getParams:ProfileFragment " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(UpdateDetailsActivity.this).addToRequestQueue(stringRequest);

    }

    private void get_cities() {

        simple_months.clear();
        monthlist.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.e(TAG, "onResponse:get_months---    " + response);

                        try {

                            JSONObject obj = new JSONObject(response);

                            String result = obj.getString("result");
                            if (result.equalsIgnoreCase("true")) {

                                monthlist.add("Select city");


                                JSONArray jsonArray = obj.getJSONArray("data");

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                                    String plan_id = jsonObject1.getString("id");
                                    String special = jsonObject1.getString("name");


                                    CityList allCommunityModel = new CityList(plan_id, special);
                                    monthlist.add(special);
                                    simple_months.add(allCommunityModel);

                                }
                                simple_months.add(0, new CityList("", "Select city"));

                                spinnermnthArrayAdapter = new ArrayAdapter<String>
                                        (UpdateDetailsActivity.this, android.R.layout.simple_spinner_item, monthlist); //selected item will look like a spinner set from XML
                                spinnermnthArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                                spinmonth.setAdapter(spinnermnthArrayAdapter);
                            } else {
                                // Toast.makeText(AddcartActivity.this, "No item available", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {
/*
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("userid", session.getUserId());
                params.put("token", session.getToken());

                return params;
            }
*/
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


    private void update_extra_detail() {
        ProgressDialog progressDialog = new ProgressDialog(UpdateDetailsActivity.this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + update_extra_detail, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "get_event_question Response: " + response);
                    if (jsonObject.getString("result").equals("true")) {
                        onBackPressed();
                    }
                    //Toast.makeText(getActivity(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", session.getUser_Id());
                map.put("about", about);
                map.put("location", location);
                map.put("social_media", social_media);
                map.put("language", language);

                Log.e(TAG, "get_event_question Response:  Params: " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(UpdateDetailsActivity.this).addToRequestQueue(stringRequest);
    }


    private void subCatArray(String user_idd) {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + subCatArray, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(Oscillator.TAG, "==onResponse:get_my_community" + response);
//                    progressDialog.dismiss();

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        userSelected_subcats.clear();
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String id_ID = dataObj.getString("id");
                            String _name = dataObj.getString("name");

                            UserSelected_Subcat jobDataList = new UserSelected_Subcat(id_ID, _name);

                            userSelected_subcats.add(jobDataList);
                        }

                        User_Selected_SubCateAdapter user_selected_subCateAdapter = new User_Selected_SubCateAdapter(UpdateDetailsActivity.this, userSelected_subcats);

                        LinearLayoutManager layoutManager = new LinearLayoutManager(UpdateDetailsActivity.this, LinearLayoutManager.HORIZONTAL, false);
//                        rvsubcat.setLayoutManager(layoutManager);
                        rvsubcat.setLayoutManager(new GridLayoutManager(UpdateDetailsActivity.this, 3));

                        rvsubcat.setAdapter(user_selected_subCateAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
//                    progressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

//                progressDialog.dismiss();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_idd);


                Log.e(TAG, "getParams:  " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);


    }


}