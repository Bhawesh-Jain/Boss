package com.social.mitra.util;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.se.omapi.Session;
import android.text.Layout;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.vansuita.pickimage.bean.PickResult;
import com.vansuita.pickimage.bundle.PickSetup;
import com.vansuita.pickimage.dialog.PickImageDialog;
import com.vansuita.pickimage.listeners.IPickCancel;
import com.vansuita.pickimage.listeners.IPickResult;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class utils_file {
    private static final int REQUEST_PHONE_CALL = 1;
    public static ProgressDialog dialog;
    public static File imgFile1;
    private static AlertDialog.Builder builder;
    private static AlertDialog alert;
    Session session;
    Context context;
    String usertype = "customer";
    String password;
    String mobile_email;


    public utils_file(Context context) {

//        Login_Api(password,mobile_email,usertype,context);
    }


    public static void Share_App(Context context) {
        final String appPackageName = context.getPackageName();
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, "Check out the App at: https://play.google.com/store/apps/details?id=" + appPackageName);
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    public static void GET_KNOW_DEVICE_LANGUUAGE() {
        String languagename = Locale.getDefault().getDisplayLanguage();
        String country = Locale.getDefault().getCountry();
    }

//    public static void Logout_Api(final String user_id, final Context context) {
//        final Session session = new Session(context);
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, "Base_Url.Logout",
//                new com.android.volley.Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject obj = new JSONObject(response);
//                            String result = obj.getString("result");
//
//                            if (result.equals("true")) {
//                                session.setLogin(false);
//                                session.setUserId("");
//
//                                session.setUser_name("");
//                                session.logout();
//
//                                /// dialog.dismiss();
//                            } else {
//                                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
//                            }
//                        } catch (JSONException e) {
//                            System.out.println("<><><>" + e.getMessage());
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new com.android.volley.Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                params.put("user_id", user_id);
//                return params;
//            }
//        };
//
//        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
//
//    }







    public static CharSequence Current_Date(Context context) {
        Date d = new Date();
        CharSequence s = DateFormat.format("MMMM d, yyyy ", d.getTime());

        return s;
    }

//
//    public static void  Login_Api(final String password,String mobile_email,String usertype, final Context context) {
//        final Session session = new Session(context);
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, "Base_Url.login",
//                new com.android.volley.Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject obj = new JSONObject(response);
//                            String result = obj.getString("result");
//
//                            if (result.equals("true")) {
//                                session.setLogin(false);
//
//
//
//                                /// dialog.dismiss();
//                            } else {
//                                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
//                            }
//                        } catch (JSONException e) {
//                            System.out.println("<><><>" + e.getMessage());
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new com.android.volley.Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                params.put("password", password);
//                params.put("mob_mail", mobile_email);
//                params.put("usertype", usertype);
//                return params;
//            }
//        };
//
//        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
//
//    }










    public static void Do_you_want_exit_Dialoge(final Context context) {
        new AlertDialog.Builder(context)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Closing Application")
                .setMessage("Are you sure you want to close this App?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (Build.VERSION.SDK_INT >= 16 && Build.VERSION.SDK_INT < 21) {
                            // getActivity().finishAffinity();


                            System.exit(0);


                            Intent a = new Intent(Intent.ACTION_MAIN);
                            a.addCategory(Intent.CATEGORY_HOME);
                            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(a);


                        } else if (Build.VERSION.SDK_INT >= 21) {



                      /*  Intent i=new Intent(Intent.ACTION_MAIN);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(i);*/

                            System.exit(0);
                        }
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }

    public static void dismissProgressDialog() {
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    public static void showProgressDialog(Context context) {
        dialog = new ProgressDialog(context);
        dialog.setTitle("");
        dialog.setMessage("Loading please wait..");
        //  dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(true);
        dialog.show();

    }

    public static void Dialoge(Context context, Layout layout) {


        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;

        dialog.getWindow().setAttributes(lp);

        // ok.setText(R.string.alert_error_msg);


        dialog.show();
    }

    public static void Choose_Image(final Context context, final ImageView imageView) {
/*
android{
 packagingOptions {
            exclude 'META-INF/rxjava.properties'
        }
//two lines for pickimage
        versionName "1.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"

            //dependency
        ///////////////////pickimage
        implementation 'com.github.jrvansuita:PickImage:2.2.4'
        implementation 'com.nononsenseapps:filepicker:3.0.0'
        maven {
            url "https://jitpack.io"
            url 'https://maven.google.com'
        }


        in menifest
         <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.com.vansuita.pickimage.provider"
            android:exported="false"
            android:grantUriPermissions="true"
            tools:replace="android:authorities">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/picker_provider_paths" />
        </provider>

*/


        final PickImageDialog dialog = PickImageDialog.build(new PickSetup());
        dialog.setOnPickCancel(new IPickCancel() {
            @Override
            public void onCancelClick() {
                dialog.dismiss();
            }
        }).setOnPickResult(new IPickResult() {
            @Override
            public void onPickResult(PickResult r) {

                if (r.getError() == null) {
                    imageView.setImageBitmap(r.getBitmap());
                    imgFile1 = bitmapToFile(context, r.getBitmap());
                    String filename = imgFile1.getName();
                } else {
                    //TODO: do what you have to do with r.getError();
                    Toast.makeText(context, r.getError().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

        }).show((FragmentActivity) context);


    }

    public static void Toast(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
    }

    public static boolean LogE(Context context, String msg) {
        Log.e("MSG EE", msg);
        return true;
    }

    public static boolean LogV(Context context, String msg) {
        Log.e("MSG VV", msg);
        return true;
    }

    //convert bitmap to file
    public static File bitmapToFile(Context mContext, Bitmap bitmap) {
        try {
            String name = System.currentTimeMillis() + ".png";
            File file = new File(mContext.getCacheDir(), name);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            bitmap.compress(Bitmap.CompressFormat.PNG, 60, bos);


            byte[] bArr = bos.toByteArray();
            bos.flush();
            bos.close();


            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static File bitMapToFile(Context mContext, Bitmap bitmap_one) {
        try {
            String name_one = System.currentTimeMillis() + ".png";
            File file_one = new File(mContext.getCacheDir(), name_one);

            ByteArrayOutputStream bos_one = new ByteArrayOutputStream();
            bitmap_one.compress(Bitmap.CompressFormat.PNG, 60, bos_one);
            byte[] bArr = bos_one.toByteArray();
            bos_one.flush();
            bos_one.close();

            FileOutputStream fos = new FileOutputStream(file_one);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file_one;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static File bit_Map_To_File(Context mContext, Bitmap bitmap) {
        try {
            String name_two = System.currentTimeMillis() + ".png";
            File file_two = new File(mContext.getCacheDir(), name_two);

            ByteArrayOutputStream bos_two = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 60, bos_two);
            byte[] bArr = bos_two.toByteArray();
            bos_two.flush();
            bos_two.close();

            FileOutputStream fos = new FileOutputStream(file_two);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file_two;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void showOKMessageandBack(String message, final Context activity, final Class activityClass) {
        builder = new AlertDialog.Builder(activity);
        if (message.length() <= 0)
            builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                alert.hide();
                hideLoader();
                Intent intent = new Intent(activity, activityClass);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activity.startActivity(intent);
            }
        });
        alert = builder.create();
        alert.show();
    }

    public static void showLoader(Activity activity) {
        if (dialog == null) {
            dialog = new ProgressDialog(activity);
            dialog.setMessage("");
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);

        }
        dialog.show();
    }

    public static void hideLoader() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
            dialog = null;
        }
    }

    public static void showAlertDialog(final Context context, String title, String message) {

        final AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // setting Dialog title
        alertDialog.setTitle(title);

        // setting Dialog message
        alertDialog.setMessage(message);

        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertDialog.dismiss();
            }
        });

        alertDialog.show();

    }

    public static String Get_Device_ID(Context context) {
        String android_id = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);

        return android_id;
    }

    public static void call_fun(Context context, String phn_no) {

        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phn_no));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_PHONE_CALL);
            } else {
                context.startActivity(intent);
            }
        } else {
            context.startActivity(intent);
        }
    }

    private boolean isValidEmail(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }


}
