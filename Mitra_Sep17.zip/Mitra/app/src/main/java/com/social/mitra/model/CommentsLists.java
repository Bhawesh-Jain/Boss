package com.social.mitra.model;

public class CommentsLists {
          String  id,comments,created_date,user_id,user_name,user_image,like_counts;

    public CommentsLists(String id, String comments, String created_date, String user_id, String user_name, String user_image, String like_counts) {
        this.id = id;
        this.comments = comments;
        this.created_date = created_date;
        this.user_id = user_id;
        this.user_name = user_name;
        this.user_image = user_image;
        this.like_counts = like_counts;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getLike_counts() {
        return like_counts;
    }

    public void setLike_counts(String like_counts) {
        this.like_counts = like_counts;
    }
}
