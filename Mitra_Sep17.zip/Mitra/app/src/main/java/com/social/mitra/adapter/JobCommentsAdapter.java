package com.social.mitra.adapter;

import static android.content.ContentValues.TAG;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.USER_JOB_URL;
import static com.social.mitra.util.BaseUrl.like_unlike_community_comments;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.model.CommentsLists;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JobCommentsAdapter extends RecyclerView.Adapter<JobCommentsAdapter.MyViewHolder> {
    ArrayList<CommentsLists> commentsListsArrayList;
    Context context;

    Session session;
    String User_ID;
    String like_id;
    int likee = 0;

    public JobCommentsAdapter(ArrayList<CommentsLists> commentsListsArrayList, Context context) {
        this.commentsListsArrayList = commentsListsArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public JobCommentsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new JobCommentsAdapter.MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_job_comments,parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull JobCommentsAdapter.MyViewHolder holder, int position) {

        session = new Session(context);
        User_ID = session.getUser_Id();
        like_id = commentsListsArrayList.get(position).getId();
        Log.e(TAG, "++++++like_id: "+like_id);



        if (commentsListsArrayList.size()>0){
            CommentsLists commentsLists = commentsListsArrayList.get(position);

            Glide.with(context).load(USER_JOB_URL + commentsLists.getUser_image())
                    .into(holder.JOB_User_IMG_holder);

            holder.JOB_Commets_user_name.setText(commentsLists.getUser_name());
            holder.job_comments__.setText(commentsLists.getComments());
            holder.comments_counting.setText(commentsLists.getLike_counts());

            holder.comments_counting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Like_Unlike_Community_Comments(User_ID,like_id,holder.comments_counting,holder.job_LIKE_comments);
                    Toast.makeText(context, "comments Liked", Toast.LENGTH_SHORT).show();
                }
            });


        }

    }

    private void Like_Unlike_Community_Comments(String user_id, String like_id, TextView comments_counting, ImageView job_like_comments) {
        Log.e(TAG, "---job_comments_likeUnlike ");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + like_unlike_community_comments, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    //                    Layout_Progress.setVisibility(GONE);
                    Log.e(TAG, "++++++Like_Unlike_Community------     "+ response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {


                        if (likee == 0){
                            job_like_comments.setImageResource(R.drawable.like_heart_icon);
                            likee++;
                            comments_counting.setText(Integer.toString(likee));
                            Log.e(TAG, "===afterincrementlikee: "+likee);
                        }else if (likee == 1){
                            job_like_comments.setImageResource(R.drawable.love);
                            likee--;
                            comments_counting.setText(Integer.toString(likee));
                        }




                        /*clickcount=clickcount+1;
                        if (clickcount==1){
                            Log.e(TAG, "+++++clickcount: "+clickcount);
                            LIKE_POST.setImageResource(R.drawable.love);
                        }
                        else {
                            LIKE_POST.setImageResource(R.drawable.like_heart_icon);
                        }*/



                      /*  if (status.equalsIgnoreCase("0")){

                        }
                        else if(status.equalsIgnoreCase("0")){
                            LIKE_POST.setImageResource(R.drawable.love);
                        }*/
//                        LIKE_POST.setImageResource(like_un_like ? R.drawable.like_heart_icon : R.drawable.love);

                        /*LIKE_COUNT.setText(status);
                        Log.e(TAG, "-----mCounter: "+status);*/

                    } else {

//                        Layout_Progress.setVisibility(GONE);


                    }
                } catch (JSONException e) {
//                    Layout_Progress.setVisibility(GONE);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

//                Layout_Progress.setVisibility(GONE);

                Toast.makeText(context, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id",user_id);
                map.put("comment_id",like_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:Likes "+map );
                return map;
            }
        };

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    @Override
    public int getItemCount() {
        return commentsListsArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView job_LIKE_comments,JOB_User_IMG_holder;
        TextView comments_counting,TiMe_Comments_,job_comments__,JOB_Commets_user_name;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            job_LIKE_comments = itemView.findViewById(R.id.job_LIKE_comments);
            JOB_User_IMG_holder = itemView.findViewById(R.id.JOB_User_IMG_holder);
            comments_counting = itemView.findViewById(R.id.comments_counting);
            TiMe_Comments_ = itemView.findViewById(R.id.TiMe_Comments_);
            job_comments__ = itemView.findViewById(R.id.job_comments__);
            JOB_Commets_user_name = itemView.findViewById(R.id.JOB_Commets_user_name);


        }
    }
}
