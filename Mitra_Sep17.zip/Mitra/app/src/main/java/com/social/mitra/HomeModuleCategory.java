package com.social.mitra;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.adapter.SubCategoryAdapter;
import com.social.mitra.interfa.Sub_item_click;
import com.social.mitra.model.SubCategoryModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_subcategory;
import static com.social.mitra.util.BaseUrl.update_main_catsubcat;

public class HomeModuleCategory extends AppCompatActivity {
    private static final String TAG = "HomeModuleCategory";
    CardView btn_next;
    RecyclerView recycler_sub_category;
    Session session;
    String User_id, Cate_id, sUB_CATE_ID;
    ArrayList<SubCategoryModel> subCategoryModelArrayList = new ArrayList<>();
    SubCategoryAdapter subCategoryAdapter;
    ArrayList<String> SubCat_idlist = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bottom_sheet_list_layout);
        session = new Session(HomeModuleCategory.this);
        btn_next = findViewById(R.id.btn_next);
        Log.e(TAG, "onCreate: "  );
        recycler_sub_category = findViewById(R.id.recycler_sub_category);
        User_id = session.getUser_Id();

        Cate_id="0";

        Get_Sub_cateGory();
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Update_Main_CatSubcat(User_id,Cate_id,sUB_CATE_ID);
            }
        });


    }

    private void Update_Main_CatSubcat(String user_id, String cate_id, String sUB_cate_id) {

        Log.e(TAG, "***Update_Main_CatSubcat: ");
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + update_main_catsubcat, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, " update_main_catsubcat  Response: ><><><><>   " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        Log.e(TAG, "onResponse:HomeActivity ");
                        Intent intent = new Intent(HomeModuleCategory.this, HomeModuleActivity.class);
                        startActivity(intent);



                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(HomeModuleCategory.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("cat_id", cate_id);
                map.put("subcat_id", sUB_cate_id);
                Log.e(TAG, "getParams:UpdateCateSubonResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void Get_Sub_cateGory() {
        subCategoryModelArrayList.clear();


        ProgressDialog progressDialog = new ProgressDialog(HomeModuleCategory.this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_subcategory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);


                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {


                        progressDialog.dismiss();
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Sub_Cate_id = dataObj.getString("id");

                            String Sub_cate_name = dataObj.getString("name");

                            SubCategoryModel subCategoryModel = new SubCategoryModel(Sub_Cate_id, Sub_cate_name);

                            subCategoryModelArrayList.add(subCategoryModel);
                        }
                        subCategoryAdapter = new SubCategoryAdapter(HomeModuleCategory.this, subCategoryModelArrayList, new Sub_item_click() {

                            public void SubItemClick(SubCategoryModel item) {
                                item.getSub_cate_id();
                                Log.e(TAG, "SubItemClick: " + item.getSub_cate_id());

                                sUB_CATE_ID=item.getSub_cate_id();
                                if (!SubCat_idlist.contains(sUB_CATE_ID)) {
                                    SubCat_idlist.add(sUB_CATE_ID);
                                    sUB_CATE_ID = TextUtils.join(",", SubCat_idlist);

                                    System.out.println("subcatid******* id     " + sUB_CATE_ID);
                                }
                                btn_next.setBackgroundResource(R.drawable.btn_accept_new_bg);

                            }
                        });

                        LinearLayoutManager layoutManager = new LinearLayoutManager(HomeModuleCategory.this, LinearLayoutManager.VERTICAL, false);
                        recycler_sub_category.setLayoutManager(layoutManager);
                        recycler_sub_category.setAdapter(subCategoryAdapter);

                    } else {
                        Toast.makeText(HomeModuleCategory.this, "error1" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    Toast.makeText(HomeModuleCategory.this, "error2" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(HomeModuleCategory.this, "error3" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", session.getUser_Id());
                Log.e(TAG, "getParams:map =-=-=-=-=     "+map );
                return map;
            }
        };

        VolleySingleton.getInstance(HomeModuleCategory.this).addToRequestQueue(stringRequest);


    }
}
