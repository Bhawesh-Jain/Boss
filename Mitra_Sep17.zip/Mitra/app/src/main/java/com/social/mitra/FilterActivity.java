package com.social.mitra;

import static android.content.ContentValues.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_cities;
import static com.social.mitra.util.BaseUrl.get_main_category;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.core.motion.utils.Oscillator;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.adapter.CityListAdapter;
import com.social.mitra.adapter.DistanceRecyclerAdapter;
import com.social.mitra.adapter.ProfessionalAdapter;
import com.social.mitra.adapter.ProfessionalAdapterCategory;
import com.social.mitra.databinding.NewUiFilterActivityBinding;
import com.social.mitra.model.CityList;
import com.social.mitra.model.FilterModel;
import com.social.mitra.model.ProfessionalNameList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FilterActivity extends AppCompatActivity {

    private NewUiFilterActivityBinding binding;
    private final ArrayList<CityList> cityListArrayList = new ArrayList<>();
    private final ArrayList<ProfessionalNameList> professionalNameLists = new ArrayList<>();
    private final ArrayList<String> distanceNameLists = new ArrayList<>();
    private Session session;
    public static ArrayList<ProfessionalNameList> selectedProfession = new ArrayList<>();
    public static ArrayList<CityList> selectedCities = new ArrayList<>();
    private String MType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = NewUiFilterActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        session = new Session(this);

        if (getIntent() != null){
            MType = getIntent().getStringExtra("KeyType");
        }

        city_list_data();
        profession_list_data();
        distance_list_data();

        binding.cityTextview.setOnClickListener(v -> {
            binding.cityRecycle.setVisibility(View.VISIBLE);
            binding.professionRecycle.setVisibility(View.GONE);
            binding.distanceRecycle.setVisibility(View.GONE);
            binding.cityTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.selected_background));
            binding.professionTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ctextbackground));
            binding.distanceTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ctextbackground));
        });

        binding.professionTextview.setOnClickListener(v -> {
            binding.professionRecycle.setVisibility(View.VISIBLE);
            binding.cityRecycle.setVisibility(View.GONE);
            binding.distanceRecycle.setVisibility(View.GONE);
            binding.professionTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.selected_background));
            binding.cityTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ctextbackground));
            binding.distanceTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ctextbackground));
        });

        binding.distanceTextview.setOnClickListener(view -> {
            binding.professionRecycle.setVisibility(View.GONE);
            binding.cityRecycle.setVisibility(View.GONE);
            binding.distanceRecycle.setVisibility(View.VISIBLE);
            binding.professionTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ctextbackground));
            binding.cityTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ctextbackground));
            binding.distanceTextview.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.selected_background));
        });
        binding.resetTxt.setOnClickListener(view -> resetFilter());
        binding.icClose.setOnClickListener(view -> finish());
        binding.applyFilters.setOnClickListener(view -> applyFilters());
    }

    private void applyFilters() {
        FilterModel model = new FilterModel(selectedProfession, selectedCities);

        session.putObject("FilterData", model);

        selectedProfession.clear();
        selectedCities.clear();

        finish();
    }

    private void resetFilter() {
        binding.professionRecycle.setAdapter(new ProfessionalAdapter(getApplicationContext(), professionalNameLists));
        binding.cityRecycle.setAdapter(new CityListAdapter(getApplicationContext(), cityListArrayList));
        binding.distanceRecycle.setAdapter(new DistanceRecyclerAdapter(getApplicationContext(), distanceNameLists));
    }

    private void city_list_data() {
        Log.e(TAG, "City_list_data: ");
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "onResponse:City_list_data" + response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject json_data = jsonArray.getJSONObject(i);
                            String city_id = json_data.getString("id");
                            String city_name = json_data.getString("name");
                            String city_image = json_data.getString("image");

                            CityList cityList = new CityList(city_id, city_name);

                            cityListArrayList.add(cityList);
                        }
                        binding.cityRecycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        binding.cityRecycle.setAdapter(new CityListAdapter(getApplicationContext(), cityListArrayList));
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(FilterActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void profession_list_data() {
        Log.e(Oscillator.TAG, "***Get_Main_Category: ");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_main_category, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(Oscillator.TAG, "==onResponse:Get_Main_Category"+ response);
//                    progressDialog.dismiss();

                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Professional_ID = dataObj.getString("id");
                            String Profession_name = dataObj.getString("name");
                            String Profession_image = dataObj.getString("image");

                            ProfessionalNameList professionalNameList = new ProfessionalNameList(Profession_image,Profession_name,Professional_ID);

                            professionalNameLists.add(professionalNameList);
                        }

                        binding.professionRecycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        binding.professionRecycle.setAdapter(new ProfessionalAdapter(getApplicationContext(), professionalNameLists));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(FilterActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id",session.getUser_Id());
                map.put("type",MType);
                Log.e(Oscillator.TAG, "getParams:loginn onResponse "+map );
                return map;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void distance_list_data(){
        distanceNameLists.add("2 Km");
        distanceNameLists.add("5 Km");
        distanceNameLists.add("10 Km");
        distanceNameLists.add("15 Km");
        distanceNameLists.add("20 Km");
        distanceNameLists.add("40 Km");

        binding.distanceRecycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        binding.distanceRecycle.setAdapter(new DistanceRecyclerAdapter(getApplicationContext(), distanceNameLists));
    }
}