package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.interfa.MSubCateClick;
import com.social.mitra.model.MaterialSubCateList;

import java.util.ArrayList;

public class MSubCateAdapter extends RecyclerView.Adapter<MSubCateAdapter.MyViewHolder>{

    Context context;
    ArrayList<MaterialSubCateList>  materialSubCateLists;
    MSubCateClick listner;

    public MSubCateAdapter(Context context, ArrayList<MaterialSubCateList> materialSubCateLists, MSubCateClick listner) {
        this.context = context;
        this.materialSubCateLists = materialSubCateLists;
        this.listner = listner;
    }

    @NonNull
    @Override
    public MSubCateAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_material_subcate,parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MSubCateAdapter.MyViewHolder holder, int position) {
        if (materialSubCateLists.size()>0){

            MaterialSubCateList materialSubCateList  =  materialSubCateLists.get(position);

            holder.item_Material_subcate.setText(materialSubCateList.getMSubCateName());

            holder.item_Material_subcate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    holder.item_Material_subcate.setBackgroundResource(R.drawable.green_background);
                    listner.MSubClicked(materialSubCateList);
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return materialSubCateLists.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {


        TextView item_Material_subcate;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            item_Material_subcate = itemView.findViewById(R.id.item_Material_subcate);


        }

    }
}
