package com.social.mitra.adapter;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.Profession_icon;
import static com.social.mitra.util.BaseUrl.get_main_subcat;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.interfa.Item_Click_Pro_sub_cate;
import com.social.mitra.interfa.Profession_click;
import com.social.mitra.model.ProfessionalNameList;
import com.social.mitra.model.ProfessionalSubCateList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProfessionalAdapterCategory extends RecyclerView.Adapter<ProfessionalAdapterCategory.MyViewHolder> {
    public static ArrayList<String> subCatItems = new ArrayList<>();
    Context context;
    ArrayList<ProfessionalNameList> professionalNameListArrayList;
    Profession_click interFace_click;
    Session session;
    String Professional_Cate_id;
    String Professional_sub_cate_ID;
    int selectedPosition = -1;
    Boolean temporary = false;
    String cate_id,SubCate_id,SubCate_name;
    ArrayList<ProfessionalSubCateList> professionalSubCateListArrayList = new ArrayList<>();

    public ProfessionalAdapterCategory(Context context, ArrayList<ProfessionalNameList> professionalNameListArrayList, Profession_click interFace_click) {
        subCatItems.clear();
        this.context = context;
        this.professionalNameListArrayList = professionalNameListArrayList;
        this.interFace_click = interFace_click;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(
                R.layout.item_professioanal_category,
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        session = new Session(context);
        Professional_Cate_id = session.get_Profession_cate_id();
        Professional_sub_cate_ID = session.get_Profession_Subcate_id();

        Log.e(TAG, "====ContextProfessional_Cate_id: "+Professional_Cate_id);

        if (professionalNameListArrayList.size() > 0) {
            ProfessionalNameList professionalNameList = professionalNameListArrayList.get(position);

            Glide.with(context).load(Profession_icon +
                    professionalNameList.getProfession_image()).into(holder.Profession_image);

            holder.txt_category_list.setText(professionalNameList.getProfession_name());

//            holder.bind(professionalNameList,interFace_click);

            cate_id = professionalNameList.getProfession_Id();

            Log.e(TAG, "====cate_id_cate_id: "+cate_id);

            holder.txt_category_list.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.e(TAG, "===bind: ");
                    interFace_click.Profession_click(professionalNameList,professionalNameList);
                    Get_Main_Subcat(professionalNameList.getProfession_Id(),holder.professional_sub_cate_recycler);
                }
            });
        }
    }

    private void Get_Main_Subcat(String professional_cate_id,RecyclerView rc) {
        professionalSubCateListArrayList.clear();
        temporary = ! temporary;
        Log.e(TAG, "***Get_Main_Subcat: ");
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_main_subcat, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "==onResponse:Get_Main_Category"+ response);
                    progressDialog.dismiss();
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Professional_subCate_ID = dataObj.getString("id");

                            String Profession_SubCate_name = dataObj.getString("name");

                            ProfessionalSubCateList sub_cate_list = new ProfessionalSubCateList(Professional_subCate_ID,Profession_SubCate_name);

                            professionalSubCateListArrayList.add(sub_cate_list);
                        }

                        ProfesionSubCateAdapter profesionSubCateAdapter = new ProfesionSubCateAdapter(context, professionalSubCateListArrayList, new Item_Click_Pro_sub_cate() {
                            @Override
                            public void ItemSubCateClick(ProfessionalSubCateList subItem, ProfessionalSubCateList name) {
                                SubCate_id= subItem.getProfessional_sub_ID();
                                SubCate_name=name.getProfessional_sub_Name();
                                session.set_Profession_Sub_cate_id(subItem.getProfessional_sub_ID());
                                Log.e(TAG, "ItemSubCateClick:<<><><><><>   "+subItem.getProfessional_sub_ID() );
                                if (subCatItems.size() != 0){
                                    boolean flag = true;
                                    for (int i = 0; i<subCatItems.size();i++){
                                        if (subItem.getProfessional_sub_ID().equalsIgnoreCase(subCatItems.get(i)))
                                            flag = false;
                                    }
                                    if (flag)
                                        subCatItems.add(subItem.getProfessional_sub_ID());
                                }else subCatItems.add(subItem.getProfessional_sub_ID());

//                                session.setSubcate_Id(SubCate_id);
//                                        Toast.makeText(context, "Sub_Cate_ID" + subItem.getProfessional_sub_ID(), Toast.LENGTH_SHORT).show();
//                                        Toast.makeText(context, "Sub_Cate_ID" + SubCate_name, Toast.LENGTH_SHORT).show();
                                    }
                                });


                        LinearLayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
                        rc.setLayoutManager(layoutManager);
                        rc.setAdapter(profesionSubCateAdapter);
                        rc.setVisibility(View.VISIBLE);


                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(context, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("cat_id",professional_cate_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:***Get_Main_Subcat- Cat_id"+map );
                return map;
            }
        };

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);

    }


    @Override
    public int getItemCount() {
        return professionalNameListArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView Profession_image;
        TextView txt_category_list;
        RecyclerView professional_sub_cate_recycler;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            Profession_image = itemView.findViewById(R.id.Profession_image);
            txt_category_list = itemView.findViewById(R.id.txt_category_list);
            professional_sub_cate_recycler = itemView.findViewById(R.id.professional_sub_cate_recycler);
            professional_sub_cate_recycler.setVisibility(View.VISIBLE);

        }
    }
}




