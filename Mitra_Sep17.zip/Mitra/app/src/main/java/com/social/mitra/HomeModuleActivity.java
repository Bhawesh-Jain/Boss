package com.social.mitra;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.model.CityList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.R.layout.simple_spinner_item;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_cities;
import static com.social.mitra.util.BaseUrl.update_only_name;

public class HomeModuleActivity extends AppCompatActivity {
    private static final String TAG = "HomeModuleActivity";
    ImageView back_name_home;
    EditText Home_Name_;
    CardView Name_button;
    Session session;
    String name_u;
    String MType, cityid;
    ArrayList<CityList> cityListArrayList = new ArrayList<>();
    Spinner spincity;
    ArrayList<String> citys = new ArrayList<>();
    TextView txtprocedd;
    private boolean selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);
        citys.add("Select city");

        session = new Session(HomeModuleActivity.this);

        back_name_home = findViewById(R.id.back_name_home);
        Name_button = findViewById(R.id.Name_button);
        Home_Name_ = findViewById(R.id.Home_Name_);
        spincity = findViewById(R.id.spincity);
        txtprocedd = findViewById(R.id.txtprocedd);

        ArrayAdapter<String> ad = new ArrayAdapter<>(HomeModuleActivity.this, simple_spinner_item, citys);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spincity.setAdapter(ad);

        if (getIntent() != null) {
            MType = getIntent().getStringExtra("KeyType");
            Log.e(TAG, "----MType>>>" + MType);
        }

        back_name_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        spincity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (selected) {
                    cityid = cityListArrayList.get(position).getCityID();
                    String name = cityListArrayList.get(position).getCityName();
                    if (!name.equalsIgnoreCase("Select city")) {
                        checkBtn();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Home_Name_.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                checkBtn();
            }
        });

        Name_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Home_Name_.getText().toString().equals("")) {
                    Home_Name_.setFocusable(true);
                    Home_Name_.setError("Enter Your Full Name");
                } else {
                    name_u = Home_Name_.getText().toString();
                    Log.e(TAG, "name_u" + name_u);
                    session.setHomeUserName(name_u);
                    update_profile();
                }
            }
        });
        get_cities();
    }

    private void checkBtn() {
        if (spincity.getSelectedItem().toString().equalsIgnoreCase("Select city"))
            txtprocedd.setBackground(getResources().getDrawable(R.drawable.btn_accept_new_bg));
        else if (Home_Name_.getText().length() > 3)
            txtprocedd.setBackground(getResources().getDrawable(R.drawable.btn_accept_new_bg));
        else
            txtprocedd.setBackground(getResources().getDrawable(R.drawable.btn_whitebackground));
    }

    private void update_profile() {
        ProgressDialog progressDialog = new ProgressDialog(HomeModuleActivity.this);
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + update_only_name, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "get_event_question Response: " + response);
                    if (jsonObject.getString("result").equals("true")) {
                        Intent intent = new Intent(HomeModuleActivity.this, HomeActivity.class);
                        intent.putExtra("KeyType", MType);
                        startActivity(intent);
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", session.getUser_Id());
                map.put("name", name_u);
                map.put("city_id", cityid);
                Log.e(TAG, "update_profile  Response:  Params:    " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(HomeModuleActivity.this).addToRequestQueue(stringRequest);
    }

    private void get_cities() {
        cityListArrayList.clear();
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e("get_cities", "---get_cities>>" + jsonObject.toString());
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONArray countryArray = jsonObject.getJSONArray("data");

                        cityListArrayList.add(new CityList("0", "Select City"));
                        for (int i = 0; i < countryArray.length(); i++) {
                            JSONObject country_data = countryArray.getJSONObject(i);

                            String experience_id = country_data.getString("id");
                            String experience_name = country_data.getString("name");

                            CityList listOfExperience = new CityList(experience_id, experience_name);
                            cityListArrayList.add(listOfExperience);
                            citys.add(experience_name);
                        }
                        selected = true;
                        ArrayAdapter<String> ad = new ArrayAdapter<>(HomeModuleActivity.this, simple_spinner_item, citys);
                        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spincity.setAdapter(ad);
                        if (session.getcity_name() != null) {
                            int spinnerPosition = ad.getPosition(session.getcity_name());
                            spincity.setSelection(spinnerPosition);
                        }
                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
//                @Override
//                protected Map<String, String> getParams() throws AuthFailureError {
//
//                    Map<String, String> map = new HashMap<>();
//                    map.put("name", full_name_edt.getText().toString());
//                    map.put("mobile_email", email_edt.getText().toString());
//                    map.put("password", password.getText().toString());
//
//                    Log.e(TAG, "getParams: "+map);
//                    return map;
//                }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

}
