package com.social.mitra.adapter;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.interfa.Item_Click_Pro_sub_cate;
import com.social.mitra.model.ProfessionalSubCateList;
import com.social.mitra.sessionData.Session;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class ProfesionSubCateAdapter extends RecyclerView.Adapter<ProfesionSubCateAdapter.MyViewHolder> {

    Context context;
    ArrayList<ProfessionalSubCateList> professionalSubCateListArrayList;
    Session session;
    String Professional_Cate_id;
    Item_Click_Pro_sub_cate listner;
    int selectedPosition = -1;

    public ProfesionSubCateAdapter(Context context, ArrayList<ProfessionalSubCateList> professionalSubCateListArrayList,Item_Click_Pro_sub_cate listner) {
        this.context = context;
        this.professionalSubCateListArrayList = professionalSubCateListArrayList;
        this.listner = listner;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_professional_subcate, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        session = new Session(context);
        Professional_Cate_id = session.get_Profession_cate_id();

        Log.e(TAG, "====Professional_Cate_id: "+Professional_Cate_id);

        if (professionalSubCateListArrayList.size() > 0) {
            ProfessionalSubCateList professionalNameList = professionalSubCateListArrayList.get(position);

            holder.item_professional_subcate.setText(professionalNameList.getProfessional_sub_Name());


            holder.item_professional_subcate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    holder.item_professional_subcate.setBackgroundResource(R.drawable.green_background);
                    listner.ItemSubCateClick(professionalNameList,professionalNameList);
                }
            });

        }

    }

    @Override
    public int getItemCount() {
        return professionalSubCateListArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

       TextView item_professional_subcate;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            item_professional_subcate = itemView.findViewById(R.id.item_professional_subcate);

        }
    }
    }





