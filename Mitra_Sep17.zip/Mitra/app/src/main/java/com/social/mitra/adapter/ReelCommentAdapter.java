package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.model.ReelComment;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ReelCommentAdapter extends RecyclerView.Adapter<ReelCommentAdapter.ViewHolder> {
    private Context context;
    private ArrayList<ReelComment> reelComments = new ArrayList<>();

    public ReelCommentAdapter(Context context, ArrayList<ReelComment> reelComments) {
        this.context = context;
        this.reelComments = reelComments;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comments, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Glide.with(context).load(reelComments.get(position).getPath() + reelComments.get(position).getUser_image()).into(holder.COMMENT_USER_IMG);

        holder.COMMENT_TIME.setText(reelComments.get(position).getCreated_date());
        holder.TXT_COMMENT.setText(reelComments.get(position).getComment());
        holder.COMMENT_USER_NAME.setText(reelComments.get(position).getUser_name());
    }

    @Override
    public int getItemCount() {
        return reelComments.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView COMMENT_USER_IMG;
        TextView COMMENT_TIME, TXT_COMMENT, COMMENT_USER_NAME;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            COMMENT_USER_IMG = itemView.findViewById(R.id.COMMENT_USER_IMG);

            COMMENT_TIME = itemView.findViewById(R.id.COMMENT_TIME);
            TXT_COMMENT = itemView.findViewById(R.id.TXT_COMMENT);
            COMMENT_USER_NAME = itemView.findViewById(R.id.COMMENT_USER_NAME);
        }
    }
}
