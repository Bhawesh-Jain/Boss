package com.social.mitra.model;

/*

*/
public class ReelModel {

    private String id,
            user_id,
            file,
            image_2,
            image_3,
            image_4,
            image_5,
            image_6,
            image_7,
            image_8,
            image_9,
            image_10,
            description,
            image_text,
            textColor,
            type,
            created_date,
            updated_date,
            name,
            fname,
            lname,
            city_name,
            user_image,
            reel_path,
            user_path;

    private int like_count, i_liked, comment_count, i_followed;

    public ReelModel(String id, String user_id, String file, String image_2, String image_3, String image_4,
                     String image_5, String image_6, String image_7, String image_8, String image_9, String image_10,
                     String description, String image_text, String textColor, String type, String created_date,
                     String updated_date, String name, String fname, String lname, String city_name, String user_image,
                     int like_count, int i_liked, int comment_count, int i_followed, String user_path, String reel_path) {
        this.id = id;
        this.user_id = user_id;
        this.file = file;
        this.image_2 = image_2;
        this.image_3 = image_3;
        this.image_4 = image_4;
        this.image_5 = image_5;
        this.image_6 = image_6;
        this.image_7 = image_7;
        this.image_8 = image_8;
        this.image_9 = image_9;
        this.image_10 = image_10;
        this.description = description;
        this.image_text = image_text;
        this.textColor = textColor;
        this.type = type;
        this.created_date = created_date;
        this.updated_date = updated_date;
        this.name = name;
        this.fname = fname;
        this.lname = lname;
        this.city_name = city_name;
        this.user_image = user_image;
        this.like_count = like_count;
        this.i_liked = i_liked;
        this.comment_count = comment_count;
        this.reel_path = reel_path;
        this.user_path = user_path;
    }

    public int getI_followed() {
        return i_followed;
    }

    public void setI_followed(int i_followed) {
        this.i_followed = i_followed;
    }

    public String getImage_2() {
        return image_2;
    }

    public void setImage_2(String image_2) {
        this.image_2 = image_2;
    }

    public String getImage_3() {
        return image_3;
    }

    public void setImage_3(String image_3) {
        this.image_3 = image_3;
    }

    public String getImage_4() {
        return image_4;
    }

    public void setImage_4(String image_4) {
        this.image_4 = image_4;
    }

    public String getImage_5() {
        return image_5;
    }

    public void setImage_5(String image_5) {
        this.image_5 = image_5;
    }

    public String getImage_6() {
        return image_6;
    }

    public void setImage_6(String image_6) {
        this.image_6 = image_6;
    }

    public String getImage_7() {
        return image_7;
    }

    public void setImage_7(String image_7) {
        this.image_7 = image_7;
    }

    public String getImage_8() {
        return image_8;
    }

    public void setImage_8(String image_8) {
        this.image_8 = image_8;
    }

    public String getImage_9() {
        return image_9;
    }

    public void setImage_9(String image_9) {
        this.image_9 = image_9;
    }

    public String getImage_10() {
        return image_10;
    }

    public void setImage_10(String image_10) {
        this.image_10 = image_10;
    }

    public int getComment_count() {
        return comment_count;
    }

    public void setComment_count(int comment_count) {
        this.comment_count = comment_count;
    }

    public int getLike_count() {
        return like_count;
    }

    public void setLike_count(int like_count) {
        this.like_count = like_count;
    }

    public int getI_liked() {
        return i_liked;
    }

    public void setI_liked(int i_liked) {
        this.i_liked = i_liked;
    }

    public String getUser_path() {
        return user_path;
    }

    public void setUser_path(String user_path) {
        this.user_path = user_path;
    }

    public String getReel_path() {
        return reel_path;
    }

    public void setReel_path(String reel_path) {
        this.reel_path = reel_path;
    }

    public String getImage_text() {
        return image_text;
    }

    public void setImage_text(String image_text) {
        this.image_text = image_text;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTextColor() {
        return textColor;
    }

    public void setTextColor(String textColor) {
        this.textColor = textColor;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getUpdated_date() {
        return updated_date;
    }

    public void setUpdated_date(String updated_date) {
        this.updated_date = updated_date;
    }
}
