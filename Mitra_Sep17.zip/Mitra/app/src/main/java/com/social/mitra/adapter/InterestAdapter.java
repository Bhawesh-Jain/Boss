package com.social.mitra.adapter;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.interfa.Sub_item_click;
import com.social.mitra.model.SubCategoryModel;
import com.social.mitra.sessionData.Session;

import java.util.ArrayList;

public class InterestAdapter extends RecyclerView.Adapter<InterestAdapter.MyViewHolder> {

    Context context;
    ArrayList<SubCategoryModel> subCategoryModels;
    Sub_item_click listnree;
    boolean isSelectedAll;
    Session session;

    public InterestAdapter(Context context, ArrayList<SubCategoryModel> subCategoryModels, Sub_item_click listnree) {
        this.context = context;
        this.subCategoryModels = subCategoryModels;
        this.listnree = listnree;
    }

    @NonNull
    @Override
    public InterestAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new InterestAdapter.MyViewHolder(LayoutInflater.from(context).inflate(R.layout.bottom_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull InterestAdapter.MyViewHolder holder, int position) {

        session = new Session(context);
        if (subCategoryModels.size() > 0) {
            SubCategoryModel subCategoryModel = subCategoryModels.get(position);

            holder.check_txtt_.setText(subCategoryModel.getSub_cate_name());

            if (session.getChecked().contains(subCategoryModel.getSub_cate_id())) {

                holder.check__one_.setChecked(true);

            } else {
                holder.check__one_.setChecked(false);

            }

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    holder.bind(subCategoryModel, listnree);
                    Log.e("TAG", "onBindViewHolder: Check   clicked   ===" + session.getChecked());

                    // if ()
                    if (subCategoryModel.getSub_cate_name().contains("None of the Above")) {

                        session.setChecked(subCategoryModel.getSub_cate_id());
                        Log.e(TAG, "----chekkkkonClick: " + session.getChecked());


                    } else {
                        if (session.getChecked().contains(subCategoryModel.getSub_cate_id())) {
                            if (subCategoryModel.getSub_cate_name().contains("None of the Above")) {
                                session.setChecked(subCategoryModel.getSub_cate_id());


                            }
                            // session.setChecked();
                            holder.check__one_.setChecked(false);


                        } else {
                            session.setChecked(session.getChecked() + " " + subCategoryModel.getSub_cate_id());
                        }
                    }
                    notifyDataSetChanged();

                }
            });


        }
    }

    @Override
    public int getItemCount() {
        return subCategoryModels.size();
    }

    public void selectAll() {
        isSelectedAll = true;

    }

    public void unselectall() {
        isSelectedAll = false;

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView check_txtt_;
        LinearLayout check_layout_;
        CheckBox check__one_;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            check_txtt_ = itemView.findViewById(R.id.check_txtt_);
            check_layout_ = itemView.findViewById(R.id.check_layout_);
            check__one_ = itemView.findViewById(R.id.check__one_);
        }

        public void bind(SubCategoryModel subCategoryModel, Sub_item_click listnree) {

            check__one_.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if (b) {
                        if (session.getChecked().contains(subCategoryModel.getSub_cate_id())) {
                        } else {
                            session.setChecked(session.getChecked() + " " + subCategoryModel.getSub_cate_id());
                        }
                    }
                    if (subCategoryModel.getSub_cate_name().equalsIgnoreCase(
                            "All of the Above")) {
                        Log.e(TAG, "onCheckedChanged: ><<><><><><><><><>   ");
                        session.setChecked(subCategoryModel.getSub_cate_id());

                        listnree.SubItemClick(subCategoryModel);
//                          check__one_.setChecked(true);
//                          notifyDataSetChanged();
                    } else {
                        listnree.SubItemClick(subCategoryModel);

                    }
                }
            });
        }
    }
}
