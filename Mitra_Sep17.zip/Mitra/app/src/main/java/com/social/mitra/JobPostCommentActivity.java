package com.social.mitra;

import static android.content.ContentValues.TAG;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.USER_JOB_URL;
import static com.social.mitra.util.BaseUrl.comment_community;
import static com.social.mitra.util.BaseUrl.load_comments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.adapter.JobCommentsAdapter;
import com.social.mitra.model.CommentsLists;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JobPostCommentActivity extends AppCompatActivity {
    Session session;
    ArrayList<CommentsLists> commentsListsArrayList = new ArrayList<>();
    String Com_id,comments,User_id;
    RecyclerView job_comments_list;
    ImageView job_post_user_name,image_commenter;
    TextView job_username,job_Position,User_Location,JOB_DESC,btn_comment_post,edit_xtx_comments;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        session.setValue("firstTime", "true");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.job_comment_activity);

        job_comments_list = findViewById(R.id.job_comments_list);
        job_post_user_name = findViewById(R.id.job_post_user_name);
        job_username = findViewById(R.id.job_username);
        job_Position = findViewById(R.id.job_Position);
        User_Location = findViewById(R.id.User_Location);
        JOB_DESC = findViewById(R.id.JOB_DESC);
        btn_comment_post = findViewById(R.id.btn_comment_post);
        edit_xtx_comments = findViewById(R.id.edit_xtx_comments);
        image_commenter = findViewById(R.id.image_commenter);

        session = new Session(JobPostCommentActivity.this);
        User_id = session.getUser_Id();

        if (getIntent() != null) {
            Com_id = getIntent().getStringExtra("id");
        }

        Load_Comments(Com_id);

        btn_comment_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Comment_Community(Com_id,User_id);
                edit_xtx_comments.setText(" ");
            }
        });


    }

    private void Comment_Community(String com_id, String user_id) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        String COMMENT = edit_xtx_comments.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + comment_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")){
                        Load_Comments(Com_id);
                    } else {
                        progressDialog.dismiss();

                        Toast.makeText(JobPostCommentActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(JobPostCommentActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(JobPostCommentActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("community_id", com_id);
                map.put("user_id", user_id);
                map.put("comment", COMMENT);
                return map;
            }
        };
        VolleySingleton.getInstance(JobPostCommentActivity.this).addToRequestQueue(stringRequest);
    }

    private void Load_Comments(String com_id) {
        Log.e(TAG, "Com_id_Load_Comments: "+com_id);
        commentsListsArrayList.clear();

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + load_comments, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();

                    Log.e(TAG, "onResponse: Load_Comments------     "+ response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONObject data = jsonObject.getJSONObject("datass");

                        String User_id = data.getString("id");
                        String description = data.getString("description");
                        String community_image = data.getString("community_image");
                        String user_id = data.getString("user_id");
                        String user_name = data.getString("user_name");
                        String user_image = data.getString("user_image");
                        Log.e(TAG, "----onResponse: " + description);
                        job_username.setText(user_name);
                        User_Location.setText("indore");
                        job_Position.setText("1 hr");
                        JOB_DESC.setText(description);
                        Glide.with(JobPostCommentActivity.this).load(USER_JOB_URL + user_image)
                                .into(job_post_user_name);

                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject dataObj = jsonArray.getJSONObject(i);

                                String _ID = dataObj.getString("id");
                                comments = dataObj.getString("comments");
                                Log.e(TAG, "=====comments: " + comments);

                                String created_date = dataObj.getString("created_date");
                                String _user_id = dataObj.getString("user_id");
                                String _user_name = dataObj.getString("user_name");
                                String _user_image = dataObj.getString("user_image");
                                String _like_counts = dataObj.getString("like_counts");

                                Log.e(TAG, "++++_user_name: " + _user_name);
                                CommentsLists commentsList = new CommentsLists(_ID, comments, created_date, _user_id, _user_name, _user_image, _like_counts);
                                commentsListsArrayList.add(commentsList);
                            }
                            JobCommentsAdapter jobCommentsAdapter = new JobCommentsAdapter(commentsListsArrayList, JobPostCommentActivity.this);
                            LinearLayoutManager layoutManager = new LinearLayoutManager(JobPostCommentActivity.this, LinearLayoutManager.VERTICAL, false);
                            job_comments_list.setLayoutManager(layoutManager);
                            job_comments_list.setAdapter(jobCommentsAdapter);
                        }
                    }
                    else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();


                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Toast.makeText(JobPostCommentActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("community_id",com_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:loginn onResponse "+map );
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}
