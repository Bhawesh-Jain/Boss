package com.social.mitra.activity;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.IMAGE_URL;
import static com.social.mitra.util.BaseUrl.followUnfollow;
import static com.social.mitra.util.BaseUrl.get_single_profile;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.AboutFragment;
import com.social.mitra.R;
import com.social.mitra.fragments.MyJobsFragment;
import com.social.mitra.fragments.PostsFragment;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class VisitSingleProfileActivity extends AppCompatActivity {

    private CircleImageView userprofile_img;
    private ImageView imgcall;
    private Session session;
    private final VisitSingleProfileActivity activity = VisitSingleProfileActivity.this;
    private TextView tv_dr_list, tv_dr_map, tv_dr_sup;
    private TextView txt_name, txt_usercat, txt_city, txt_usrtype, txtusrexp, company_type1, txtfolowing, txtfollowers, txtabout;
    private String id, phone_number;
    private TextView txtlet, share;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit_single_profile);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        txtlet = findViewById(R.id.txtlet);
        ImageView back_img = findViewById(R.id.back_img);
        userprofile_img = findViewById(R.id.userprofile_img);
        txt_city = findViewById(R.id.txt_city);
        RelativeLayout my_followers_lay = findViewById(R.id.my_followers_lay);
        RelativeLayout referencing_lay = findViewById(R.id.referencing_lay);
        txt_usrtype = findViewById(R.id.txt_usrtype);
        RelativeLayout following_lay = findViewById(R.id.following_lay);
        RelativeLayout reference_lay = findViewById(R.id.reference_lay);
        ImageView whatsapp = findViewById(R.id.imgwhatsapp);
        txt_name = findViewById(R.id.txt_name);
        txt_usercat = findViewById(R.id.txt_usercat);
        txtusrexp = findViewById(R.id.txtusrexp);
        company_type1 = findViewById(R.id.company_type1);
        txtfolowing = findViewById(R.id.txtfolowing);
        txtfollowers = findViewById(R.id.txtfollowers);
        txtabout = findViewById(R.id.txtabout);
        imgcall = findViewById(R.id.imgcall);
        session = new Session(this);

        tv_dr_list = findViewById(R.id.tv_dr_list);
        tv_dr_map = findViewById(R.id.tv_dr_map);
        tv_dr_sup = findViewById(R.id.tv_dr_sup);

        if (getIntent() != null) {
            id = getIntent().getStringExtra("id");
            Log.e(TAG, "onCreate: id><><<>><>><>     " + id);
        }

        imgcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone_number));
                if (ActivityCompat.checkSelfPermission(VisitSingleProfileActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions((Activity) VisitSingleProfileActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE}, 10);
                } else {
                    try {
                        startActivity(intentDial);  //call activity and make phone call
                    } catch (android.content.ActivityNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String contact = "+91 " + phone_number; // use country code with your phone number
                String url = "https://api.whatsapp.com/send?phone=" + contact;
                try {
                    PackageManager pm = getPackageManager();
                    pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } catch (PackageManager.NameNotFoundException e) {
                    Toast.makeText(VisitSingleProfileActivity.this, "Whatsapp app not installed in your phone", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        company_type1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                followUnfollow(session.getUser_Id(), id);
            }
        });

        txtfolowing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VisitSingleProfileActivity.this, AllFollowingActivity.class));
            }
        });

        txtfollowers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VisitSingleProfileActivity.this, AllFollowersActivity.class));
            }
        });

        reference_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VisitSingleProfileActivity.this, ReferenceActivity.class));
            }
        });

        referencing_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VisitSingleProfileActivity.this, ReferencingActivity.class));
            }
        });

        getProfile(id);

        FragmentTransaction ft = VisitSingleProfileActivity.this.getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frame_layout, new PostsFragment("other", id));
        ft.commit();

        tv_dr_list.setBackgroundResource(R.drawable.selection_bottom_line_bg);
        tv_dr_map.setBackgroundResource(R.drawable.edittext_bottom_line);
        tv_dr_sup.setBackgroundResource(R.drawable.edittext_bottom_line);

        tv_dr_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_layout, new PostsFragment("other", id));
                ft.commit();

                tv_dr_list.setBackgroundResource(R.drawable.selection_bottom_line_bg);
                tv_dr_map.setBackgroundResource(R.drawable.edittext_bottom_line);
                tv_dr_sup.setBackgroundResource(R.drawable.edittext_bottom_line);
            }
        });

        tv_dr_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_layout, new MyJobsFragment("other", id));
                ft.commit();

                tv_dr_map.setBackgroundResource(R.drawable.selection_bottom_line_bg);
                tv_dr_list.setBackgroundResource(R.drawable.edittext_bottom_line);
                tv_dr_sup.setBackgroundResource(R.drawable.edittext_bottom_line);
            }
        });

        tv_dr_sup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_layout, new AboutFragment(id));
                ft.commit();

                tv_dr_sup.setBackgroundResource(R.drawable.selection_bottom_line_bg);
                tv_dr_list.setBackgroundResource(R.drawable.edittext_bottom_line);
                tv_dr_map.setBackgroundResource(R.drawable.edittext_bottom_line);
            }
        });
    }

    private void getProfile(String user_id) {
        ProgressDialog progressDialog = new ProgressDialog(activity);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_single_profile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e("Profile Fragment ", "get profile: " + jsonObject);

                    if (jsonObject.getString("result").equals("true")) {
                        progressDialog.dismiss();
                        JSONObject data = jsonObject.getJSONObject("data");

                        String id = data.getString("id");
                        String name = data.getString("name");
                        String email = data.getString("email");
                        phone_number = data.getString("mobile");
                        String type = data.getString("type");
                        String company = data.getString("company");
                        String experience = data.getString("experience");
                        String image = data.getString("image");
                        String city_name = data.getString("city_name");
                        String total_following = data.getString("total_following");
                        String total_followers = data.getString("total_followers");
                        String about = data.getString("about");
                        String is_follows = data.getString("is_follows");
                        String mobile_hidden = data.getString("mobile_hidden");

                        String myChar = "X";
                        if (!name.equalsIgnoreCase(""))
                            myChar = Character.toString(name.charAt(0));

                        txtlet.setText(myChar);

                        txtabout.setText(about);
                        if (mobile_hidden.equalsIgnoreCase("0")) {
                            imgcall.setVisibility(View.VISIBLE);
                        } else {
                            imgcall.setVisibility(View.GONE);
                        }
                        txt_name.setText(name);
                        txtfolowing.setText(total_following);
                        txtfollowers.setText(total_followers);
                        if (is_follows.equalsIgnoreCase("1"))
                            company_type1.setText("Following");
                        else company_type1.setText("Follow");

                        if (city_name != null && !city_name.isEmpty() && !city_name.equals("null") && !city_name.equals("0")) {
                            txt_city.setText(city_name);
                        } else {
                            txt_city.setVisibility(View.GONE);
                        }

                        if (!image.equalsIgnoreCase("")) {
                            Glide.with(activity).load(IMAGE_URL + image)
                                    .placeholder(R.drawable.user).into(userprofile_img);
                            txtlet.setVisibility(View.GONE);
                            userprofile_img.setVisibility(View.VISIBLE);
                        }
                        if (experience.equalsIgnoreCase(""))
                            experience = "1 Year";
                        if (type.equalsIgnoreCase("service_provider")) {
                            Log.e(TAG, "onResponse:company ><><><><      " + company);
                            txtusrexp.setVisibility(View.VISIBLE);
                            txtusrexp.setText(experience);
                            txt_usercat.setText("Service provider");
                            if (company.length() != 0)
                            txt_usrtype.setText(company);
                        } else if (type.equalsIgnoreCase("material_supplier")) {
                            txtusrexp.setVisibility(View.VISIBLE);
                            txtusrexp.setText(experience);
                            txt_usercat.setText("Material Supplier");
                            if (company.length() != 0)
                                txt_usrtype.setText(company);
                        } else {
                            txt_usrtype.setVisibility(View.GONE);
                            txt_usrtype.setText("Self employed");
                            txtusrexp.setVisibility(View.GONE);
                            txt_usercat.setText("Home owner");
                        }
                    } else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, error -> progressDialog.dismiss()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("own_id", session.getUser_Id());

                Log.e(TAG, "getParams: GetProfile-->" + map);
                return map;
            }
        };
        VolleySingleton.getInstance(activity).addToRequestQueue(stringRequest);
    }

    private void followUnfollow(String user_id, String Id) {
        ProgressDialog progressDialog = new ProgressDialog(VisitSingleProfileActivity.this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + followUnfollow, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "followUnfollow Response: " + response);
                    if (jsonObject.getString("result").equals("true")) {
                        if (jsonObject.getString("msg").equals("Followed")) {
                            company_type1.setText("Following");
                        } else {
                            company_type1.setText("Follow");
                        }
                        getProfile(id);
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                }
            }
        }, error -> progressDialog.dismiss()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("to_user_id", Id);
                Log.e(TAG, "followUnfollow Response:  Params: " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(VisitSingleProfileActivity.this).addToRequestQueue(stringRequest);
    }
}