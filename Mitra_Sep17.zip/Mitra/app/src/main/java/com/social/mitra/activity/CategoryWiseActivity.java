package com.social.mitra.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.social.mitra.R;

public class CategoryWiseActivity extends AppCompatActivity {

    TextView agriculture, texttile, spices, furiture, tech, medicine, life_style, food;
    ImageView back_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_wise);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        back_img = findViewById(R.id.back_img);
        agriculture = findViewById(R.id.agriculture);
        texttile = findViewById(R.id.texttile);
        spices = findViewById(R.id.spices);
        furiture = findViewById(R.id.furiture);
        tech = findViewById(R.id.tech);
        medicine = findViewById(R.id.medicine);
        life_style = findViewById(R.id.life_style);
        food = findViewById(R.id.food);

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        agriculture.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Agriculture"));

            }
        });
        texttile.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Textile & Garment"));

            }
        });
        spices.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Spices"));

            }
        });
        furiture.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Furniture"));

            }
        });
        tech.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Technology"));

            }
        });
        medicine.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Medicine & equipment"));

            }
        });
        life_style.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Lifestyle Product"));

            }
        });
        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CategoryWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Category  Food & Beverage"));

            }
        });

    }
}