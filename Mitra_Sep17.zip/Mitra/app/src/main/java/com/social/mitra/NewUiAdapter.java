package com.social.mitra;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.databinding.ItemListBinding;
import com.social.mitra.model.CityList;

import java.util.ArrayList;

public class NewUiAdapter extends RecyclerView.Adapter<NewUiAdapter.ViewHolder> {
    public static String time = "";
    Context context;
    ItemListBinding binding;
    ArrayList<CityList> cityLists;

    public NewUiAdapter(Context mContext, ArrayList<CityList> cityList) {
        this.context = mContext;
        this.cityLists = cityList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = ItemListBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder();

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (cityLists.get(position) != null){
            holder.txt.setText(cityLists.get(position).getCityName());
        }
    }

    @Override
    public int getItemCount() {
        return cityLists.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt;
        public ViewHolder() {
            super(binding.getRoot());

            txt = binding.textsView;
        }
    }

}