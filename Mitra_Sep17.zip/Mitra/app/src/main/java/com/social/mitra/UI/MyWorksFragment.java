package com.social.mitra.UI;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.social.mitra.R;
import com.social.mitra.adapter.MyWorksViewpager;
import com.social.mitra.sessionData.Session;


public class MyWorksFragment extends Fragment {
    View root;
    Session session;
    String[] name = new String[]{"Work", "Discussion"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_my_works, container, false);
        session = new Session(getActivity());

        ViewPager2 viewPager2 = root.findViewById(R.id.view_pager);
        TabLayout tabLayout = root.findViewById(R.id.tab_lay);

        try {
            viewPager2.setAdapter(new MyWorksViewpager(requireActivity()));

            new TabLayoutMediator(tabLayout, viewPager2, ((tab, position) -> tab.setText(name[position]))).attach();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return root;
    }
}