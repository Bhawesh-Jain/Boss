package com.social.mitra.fragments;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_all_categories_users;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.FilterActivity;
import com.social.mitra.R;
import com.social.mitra.adapter.Professionalcat_postsAdapter;
import com.social.mitra.model.FilterModel;
import com.social.mitra.model.MainCatmodel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import soup.neumorphism.NeumorphCardView;

public class ProfessionalFragment extends Fragment {
    private static final String TAG = "ProfessionalFragment";
    LinearLayout AG_profiledetails;
    View root;
    Session session;
    NeumorphCardView filter;
    RecyclerView rv;
    FilterModel model = null;

    ArrayList<MainCatmodel> mainCatModels = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (session.getFilerModel("FilterData") != null) {
            model = session.getFilerModel("FilterData");
            session.putObject("FilterData", null);
        }
        get_all_categories_users();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_professional, container, false);
        filter = root.findViewById(R.id.filter);
        session = new Session(getActivity());
        rv = root.findViewById(R.id.rv);

        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FilterActivity.class);
                intent.putExtra("KeyType", "service_provider");
                startActivity(intent);
            }
        });

        get_all_categories_users();

        return root;
    }


    private void get_all_categories_users() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_all_categories_users, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, " get_all_categories_users: " + response);
                    mainCatModels.clear();
                    if (jsonObject.getString("result").equals("true")) {

                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObject = jsonArray.getJSONObject(i);
                            JSONArray sub_cats_list = dataObject.getJSONArray("users");
                            MainCatmodel allCommunityModel = new MainCatmodel(
                                    dataObject.getString("id"),
                                    dataObject.getString("name"),
                                    dataObject.getString("is_user"), sub_cats_list);
                            mainCatModels.add(allCommunityModel);
                        }
                        setProfessionalAdapter();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("type", "service_provider");
                Log.e(TAG, "  Params: " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    private void setProfessionalAdapter() {
        Professionalcat_postsAdapter rviewsAdapter = new Professionalcat_postsAdapter(getActivity(), mainCatModels, model);
        RecyclerView.LayoutManager mLayoutManger = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(mLayoutManger);
        rv.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));
        rv.setItemViewCacheSize(mainCatModels.size());

        rv.setAdapter(rviewsAdapter);
        rviewsAdapter.notifyDataSetChanged();
        Log.e(TAG, "setProfessionalAdapter: AdapterSet");
    }
}