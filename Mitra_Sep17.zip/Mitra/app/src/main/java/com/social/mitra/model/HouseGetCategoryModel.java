package com.social.mitra.model;

public class HouseGetCategoryModel {

    String category_id,cate_image,cate_name,cate_desc;

    public HouseGetCategoryModel(String category_id, String cate_image, String cate_name, String cate_desc) {
        this.category_id = category_id;
        this.cate_image = cate_image;
        this.cate_name = cate_name;
        this.cate_desc = cate_desc;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCate_image() {
        return cate_image;
    }

    public void setCate_image(String cate_image) {
        this.cate_image = cate_image;
    }

    public String getCate_name() {
        return cate_name;
    }

    public void setCate_name(String cate_name) {
        this.cate_name = cate_name;
    }

    public String getCate_desc() {
        return cate_desc;
    }

    public void setCate_desc(String cate_desc) {
        this.cate_desc = cate_desc;
    }
}
