package com.social.mitra.interfa;

import com.social.mitra.model.ProfessionalNameList;

public interface Profession_click {
    void Profession_click(ProfessionalNameList item,ProfessionalNameList itemName);
}
