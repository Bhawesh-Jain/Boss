package com.social.mitra.interfa;

import com.social.mitra.model.ListOfState;

public interface StateInterface {

    void StateInterface(ListOfState listOfState);
}
