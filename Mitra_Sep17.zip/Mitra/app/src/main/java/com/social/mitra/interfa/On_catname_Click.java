package com.social.mitra.interfa;

public interface On_catname_Click {

        void onname(String value);

}
