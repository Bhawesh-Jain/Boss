package com.social.mitra.model;

public class ModelCity {
    String image,cityname;

    public ModelCity(String image, String cityname) {
        this.image = image;
        this.cityname = cityname;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }
}
