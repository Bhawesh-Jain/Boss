package com.social.mitra.activity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.social.mitra.HomeModuleActivity;
import com.social.mitra.HomeModuleCategory;
import com.social.mitra.MaterialProfessionalCateListActivity;
import com.social.mitra.MaterialProfileCreationActivity;
import com.social.mitra.ProfessionalCategoryList;
import com.social.mitra.ProfileCreationActivity;
import com.social.mitra.R;
import com.social.mitra.SelectProfiletypesActivity;
import com.social.mitra.WelcomeSliderActivity;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_form_status;

public class SplashActivity extends AppCompatActivity {

    private static final String TAG = "SplashActivity";
    private static final int SPLASH_SCREEN_TIME_OUT = 1000;
    Session session;
    String TYPE = "";
    String User_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);


        session = new Session(this);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                requestStoragePermission();


             }

        }, SPLASH_SCREEN_TIME_OUT);

    }

    private void requestStoragePermission() {
        Log.e(TAG, "requestStoragePermission: ");

        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {


                            if (session.isLoggedIn()) {
                                Log.e(TAG, "---session.isLoggedIn(): " + session.isLoggedIn());
                                User_id = session.getUser_Id();
                                Get_Form_Status(User_id);

                               /* Intent i = new Intent(SplashActivity.this, HomeActivity.class);
                                startActivity(i);
                                overridePendingTransition(R.anim.enter, R.anim.exit);
                                finish();*/

                            } else {
                                Log.e("Splash ", "run: Login");
                                Intent i = new Intent(SplashActivity.this, WelcomeSliderActivity.class);
                                startActivity(i);
                                overridePendingTransition(R.anim.enter, R.anim.exit);
                                finish();
                            }

                            /* else if (User_id.equalsIgnoreCase(User_id)){

                                Get_Form_Status(User_id);
                            }*/




                            /*  if(session.isLoggedIn())
                                 {
                                Log.e(TAG, "---session.isLoggedIn(): "+session.isLoggedIn());
                                Intent i = new Intent(SplashActivity.this, HomeActivity.class);
                                startActivity(i);
                                overridePendingTransition(R.anim.enter, R.anim.exit);
                                finish();
                                 }else {
                                Log.e("Splash ", "run: Login");
                                Intent i = new Intent(SplashActivity.this, WelcomeSliderActivity.class);
                                startActivity(i);
                                overridePendingTransition(R.anim.enter, R.anim.exit);
                                finish();
                            }   */

                        } else {
                            showSettingsDialog();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            Log.e("TAG", "isAnyPermissionPermanentlyDenied: ");
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Error occurred! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    private void Get_Form_Status(String user_id) {

        Log.e(TAG, "***Get_Form_Status:");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_form_status, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);


                    Log.e(TAG, "onResponse: "  );

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String _id = data.getString("id");
                        String form_status = data.getString("form_status");
                        String TYPE = data.getString("type");


                        if (TYPE.equalsIgnoreCase("home_owner")) {

                            Log.e(TAG, "onResponse: home_owner form_status  "+form_status);

                            if (form_status.equalsIgnoreCase("0")) {
                                Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("2")) {


                                Intent intent = new Intent(SplashActivity.this, HomeModuleCategory.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("3")) {

                                Intent intent = new Intent(SplashActivity.this, HomeModuleActivity.class);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("4")) {

                                Intent intent = new Intent(SplashActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();


                            } else {
                                Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();
                            }


                        } else if (TYPE.equalsIgnoreCase("service_provider")) {
//                                 cate_status.equalsIgnoreCase("1")
//                                 ProfileCreationActivity
//                                 ProfessionalCategoryList
//                                 pro_status.equalsIgnoreCase("1")

                            if (form_status.equalsIgnoreCase("0")) {
                                Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("2")) {


                                Intent intent = new Intent(SplashActivity.this, ProfessionalCategoryList.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("3")) {

                                Intent intent = new Intent(SplashActivity.this, ProfileCreationActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("4")) {

                                Intent intent = new Intent(SplashActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();
                            } else {
                                Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", TYPE);

                                startActivity(intent);
                                finish();
                            }

                        } else if (TYPE.equalsIgnoreCase("material_supplier")) {
//                                 HomeActivity
//                                 MaterialProfessionalCateListActivity
//                                 MaterialProfileCreationActivity


                            if (form_status.equalsIgnoreCase("0")) {
                                Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", TYPE);
                                startActivity(intent);
                                finish();

                            }
                            else if (form_status.equalsIgnoreCase("2")) {


                                Intent intent = new Intent(SplashActivity.this, MaterialProfessionalCateListActivity.class);
                                intent.putExtra("KeyType", TYPE);
                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("3")) {

                                Intent intent = new Intent(SplashActivity.this, MaterialProfileCreationActivity.class);
                                intent.putExtra("KeyType", TYPE);
                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("4")) {

                                Intent intent = new Intent(SplashActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", TYPE);
                                startActivity(intent);
                                finish();

                            } else {

                                Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", TYPE);
                                startActivity(intent);
                                finish();

                            }

                        } else {


                            Intent intent = new Intent(SplashActivity.this, SelectProfiletypesActivity.class);
                            intent.putExtra("KeyType", TYPE);

                            startActivity(intent);
                            finish();
                        }


                    }
                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {


            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(ActivityLogin.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:loginn onResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(SplashActivity.this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);
            }
        });
        builder.show();


    }

    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }


}