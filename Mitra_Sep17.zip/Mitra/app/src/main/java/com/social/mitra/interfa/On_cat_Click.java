package com.social.mitra.interfa;

public interface On_cat_Click {

        void onClick(String value);

}
