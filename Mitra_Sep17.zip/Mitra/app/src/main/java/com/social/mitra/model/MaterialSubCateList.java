package com.social.mitra.model;

public class MaterialSubCateList {
    String MSubCateId, MSubCateName;

    public MaterialSubCateList(String MSubCateId, String MSubCateName) {
        this.MSubCateId = MSubCateId;
        this.MSubCateName = MSubCateName;
    }

    public String getMSubCateId() {
        return MSubCateId;
    }

    public void setMSubCateId(String MSubCateId) {
        this.MSubCateId = MSubCateId;
    }

    public String getMSubCateName() {
        return MSubCateName;
    }

    public void setMSubCateName(String MSubCateName) {
        this.MSubCateName = MSubCateName;
    }
}
