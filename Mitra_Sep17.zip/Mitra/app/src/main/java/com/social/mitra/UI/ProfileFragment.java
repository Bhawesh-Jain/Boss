package com.social.mitra.UI;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.IMAGE_URL;
import static com.social.mitra.util.BaseUrl.get_profile;
import static com.social.mitra.util.BaseUrl.get_promotion_banner;
import static com.social.mitra.util.BaseUrl.logout;
import static com.social.mitra.util.Utils.getRandomColor;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.tabs.TabLayout;
import com.social.mitra.AboutFragment;
import com.social.mitra.R;
import com.social.mitra.ViewMyProfileActivity;
import com.social.mitra.activity.AllFollowersActivity;
import com.social.mitra.activity.AllFollowingActivity;
import com.social.mitra.activity.EditProfileActivity;
import com.social.mitra.activity.ReferenceActivity;
import com.social.mitra.adapter.ProfilePostAdapter;
import com.social.mitra.adapter.PromotionalAdapter;
import com.social.mitra.fragments.MyJobsFragment;
import com.social.mitra.fragments.PostsFragment;
import com.social.mitra.model.ProfilePostModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class ProfileFragment extends Fragment {

    ProfilePostAdapter profilePostAdapter;
    ArrayList<ProfilePostModel> profilePostModels = new ArrayList<>();
    TextView edit_Profile_tv, user_name, total_followers;
    RecyclerView image_video_list;
    RelativeLayout my_followers_lay, referencing_lay, reference_lay, following_lay;
    TabLayout top_tab_layout;
    int tabCount;
    String[] Top_TABS = {"Post", "Saved", "About"};
    ViewPager profile_pager;
    LinearLayout setting_button;
    ViewPagerAdapter viewPagerAdapter;
    TextView viewprofile;
    TextView shareprofile;
    TextView location_name;
    TextView home_self_emplyed, txtlet, about_business_tv;
    ImageView demo;
    String User_id, MOBILE;

    Session session;

    TextView NAME, Type_user;
    ImageView User_profile_typee;
    String PROFILE_STATUS;
    String city_name;
    String Experience;
    TextView Experience__;
    TextView totalfollowing, totalfollowers;
    RecyclerView promotional_recyclerview;
    CardView txtlet_cv;


    private int[] layouts;

    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_profile, container, false);
        session = new Session(getActivity());

        promotional_recyclerview = root.findViewById(R.id.promotional_recyclerview);
        totalfollowers = root.findViewById(R.id.total_followers);
        totalfollowing = root.findViewById(R.id.totalfollowing);
        image_video_list = root.findViewById(R.id.image_video_list);
        edit_Profile_tv = root.findViewById(R.id.edit_Profile_tv);
        my_followers_lay = root.findViewById(R.id.my_followers_lay);
        user_name = root.findViewById(R.id.user_name);
        about_business_tv = root.findViewById(R.id.about_business_tv);

        txtlet_cv = root.findViewById(R.id.txtlet_cv);

        txtlet_cv.setCardBackgroundColor(getRandomColor());
//        setting = root.findViewById(R.id.setting);

        referencing_lay = root.findViewById(R.id.referencing_lay);
        following_lay = root.findViewById(R.id.following_lay);
        reference_lay = root.findViewById(R.id.reference_lay);
        User_profile_typee = root.findViewById(R.id.User_profile_typee);
        NAME = root.findViewById(R.id.NAME);
        location_name = root.findViewById(R.id.location_name);
        home_self_emplyed = root.findViewById(R.id.home_self_emplyed);
        txtlet = root.findViewById(R.id.txtlet);

        Type_user = root.findViewById(R.id.Type_user);
        Experience__ = root.findViewById(R.id.Experience__);

        setting_button = root.findViewById(R.id.setting_button);

        demo = root.findViewById(R.id.demo);

        // tab and viewpager
        profile_pager = root.findViewById(R.id.profile_pager);
        top_tab_layout = root.findViewById(R.id.top_tab_layout);
//        user_setting = root.findViewById(R.id.user_setting);

        viewprofile = root.findViewById(R.id.viewprofile);


        ArrayList<String> list = new ArrayList<>();
        list.add("");
        list.add("");
        list.add("");
        list.add("");
        PromotionalAdapter adapter = new PromotionalAdapter(list, getContext());
        promotional_recyclerview.setAdapter(adapter);
        promotional_recyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false));


        shareprofile = root.findViewById(R.id.shareprofile);

        User_id = session.getUser_Id();
        Log.e(TAG, "User_id_ProfileFragment_onCreateView: " + User_id);
        MOBILE = session.getMobile();
        Log.e(TAG, "---MOBILE_ProfileFragment_onCreateView: " + MOBILE);
        PROFILE_STATUS = session.getProfile_status();
        Log.e(TAG, "---PROFILE_STATUS_ProfileFragment_onCreateView: " + MOBILE);

        Experience = session.getEX_Name();

        Get_Profile(User_id);

        setting_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e(TAG, "--MOBILE_ProfileFragment_onCreateView: " + MOBILE);
                Log.e(TAG, "+++++setting_button_onClick: ");

                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getActivity(), R.style.BottomSheetDialog);

                bottomSheetDialog.setContentView(R.layout.select_companytype_bottomsheet);
                bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                bottomSheetDialog.setCanceledOnTouchOutside(true);

                ImageView close_img = bottomSheetDialog.findViewById(R.id.close_img);
                TextView select_type = bottomSheetDialog.findViewById(R.id.select_type);
                TextView AG_viewprofile = bottomSheetDialog.findViewById(R.id.AG_viewprofile);
                TextView Logout_app = bottomSheetDialog.findViewById(R.id.Logout_app);

                Logout_app.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new AlertDialog.Builder(getActivity())
                                .setTitle("Logout")
                                .setMessage("Do you want log out")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();

                                        LogOutApp(User_id);
                                        Log.e(TAG, "session_user_id: " + session.getUser_Id());
                                    }
                                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                }).show();
                    }
                });
                close_img.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        bottomSheetDialog.dismiss();
                    }
                });
                bottomSheetDialog.show();
            }
        });

        shareprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my app at: https://play.google.com/store/apps/details?id=");
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });
        intiTab();

        layouts = new int[]{
                R.layout.fragment_news,
                R.layout.fragment_share,
                R.layout.fragment_gallery,
        };

        viewPagerAdapter = new ViewPagerAdapter(
                getChildFragmentManager());
        profile_pager.setAdapter(viewPagerAdapter);

        // It is used to join TabLayout with ViewPager.
        top_tab_layout.setupWithViewPager(profile_pager);
        tabCount = top_tab_layout.getTabCount();
        top_tab_layout.setSelected(true);

        viewprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getContext().startActivity(new Intent(getActivity(), ViewMyProfileActivity.class));
            }
        });

        edit_Profile_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().startActivity(new Intent(getActivity(), EditProfileActivity.class));
            }
        });

        reference_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().startActivity(new Intent(getActivity(), ReferenceActivity.class));
            }
        });

        following_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().startActivity(new Intent(getActivity(), AllFollowingActivity.class));
            }
        });

        my_followers_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().startActivity(new Intent(getActivity(), AllFollowersActivity.class));
            }
        });

        return root;
    }

    private void Get_Profile(String user_id) {
        Log.e(TAG, "ProfileFragment_Get_Profile: ");
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, "onResponse: *****GetProfile-ProfileFragment--->      " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String User_id = data.getString("id");
                        String name__ = data.getString("name");
                        String First_name = data.getString("fname");
                        String Last_name = data.getString("lname");
                        String Mobile_ = data.getString("mobile");
                        String TYPE = data.getString("type");
                        String IMAGGE = data.getString("image");
                        String company = data.getString("company");
                        city_name = data.getString("city_name");
                        String location = data.getString("location");
                        String exprience = data.getString("experience");
                        String about = data.getString("bio");


                        totalfollowers.setText(data.getString("total_followers"));
                        totalfollowing.setText(data.getString("total_following"));
                        if (about != null && !about.isEmpty() && !about.equals("null") && !about.equals("0")) {
                            about_business_tv.setText("About : " + about);
                        }

                        Log.e(TAG, "onResponse: " + IMAGE_URL + IMAGGE);

                        String mychar = "";
                        if (!name__.equalsIgnoreCase(""))
                            mychar = Character.toString(name__.charAt(0));
                        txtlet.setText(mychar.toUpperCase());

                        if (!IMAGGE.isEmpty() && !IMAGGE.equals("null") && !IMAGGE.equals("0")) {
                            Glide.with(getActivity()).load(IMAGE_URL + IMAGGE).placeholder(R.drawable.user)
                                    .into(User_profile_typee);
                            txtlet.setVisibility(View.GONE);
                            User_profile_typee.setVisibility(View.VISIBLE);
                            txtlet_cv.setVisibility(View.GONE);
                        } else {
                            User_profile_typee.setVisibility(View.GONE);
                            txtlet_cv.setVisibility(View.VISIBLE);
                            txtlet.setVisibility(View.VISIBLE);
                            txtlet.setText(mychar);
                        }

                        if (exprience.equalsIgnoreCase(""))
                            exprience = "1 Year";
                        String exp = exprience;
                        Log.e(TAG, "onResponse: TYPE  " + TYPE);

                        if (TYPE.equalsIgnoreCase("service_provider")) {
                            Log.e(TAG, "onResponse:company ><><><><      " + company);
                            NAME.setText(name__);
                            Experience__.setVisibility(View.VISIBLE);
                            Experience__.setText(exp);
                            Type_user.setVisibility(View.VISIBLE);
                            Type_user.setText("Service Provider");
                            home_self_emplyed.setText(company);
                        } else if (TYPE.equalsIgnoreCase("material_supplier")) {
                            NAME.setText(name__);
                            Experience__.setVisibility(View.VISIBLE);
                            Experience__.setText(exp);
                            Type_user.setText("Material Supplier");
                            home_self_emplyed.setText(company);
                            Type_user.setVisibility(View.VISIBLE);
                        } else {
                            NAME.setText(name__);
                            home_self_emplyed.setVisibility(View.VISIBLE);
                            home_self_emplyed.setText("Self employed");
                            Experience__.setVisibility(View.GONE);
                            Type_user.setText("Home owner");
                            Type_user.setVisibility(View.VISIBLE);
                        }


                        if (!city_name.equalsIgnoreCase(""))
                            location_name.setText(city_name);
                        else location_name.setText(location);

//                        Bundle simple_bundle=new Bundle();
//                        simple_bundle.putString("MOBILE",user_mobile);
//                        simple_bundle.putString("ID",User_id);
//                        simple_bundle.putString("OTP",user_otp);
                    } else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();

                    progressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "--getParams:ProfileFragment " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }

    private void Get_Promotional() {
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_promotion_banner, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, "onResponse: *****GetPromotional--->      " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                    } else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, error -> progressDialog.dismiss());
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    private void LogOutApp(String user_id) {
        Log.e(TAG, "LogOutApp: ");
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + logout, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e("-----Sign Up Acti  ", "-----logout: >>" + response);
                    if (jsonObject.getString("result").equals("true")) {
                        progressDialog.dismiss();
                        session.logout();

                    } else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                Log.e(TAG, "getParams: " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    private void setImageVideo() {
        profilePostModels.clear();

        for (int i = 0; i < 15; i++) {
            ProfilePostModel profilePostModel = new ProfilePostModel();

            profilePostModel.setImage(R.drawable.nature);
            profilePostModels.add(profilePostModel);
        }
        profilePostAdapter = new ProfilePostAdapter(getActivity(), profilePostModels);
        image_video_list.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        image_video_list.setAdapter(profilePostAdapter);
    }

    private void intiTab() {
        if (top_tab_layout != null) {
            for (int i = 0; i < Top_TABS.length; i++) {

                top_tab_layout.addTab(top_tab_layout.newTab());
                TabLayout.Tab tab = top_tab_layout.getTabAt(i);
                if (tab != null)
                    tab.setText(Top_TABS[i]);
            }
        }
    }

    public class ViewPagerAdapter
            extends FragmentPagerAdapter {

        public ViewPagerAdapter(
                @NonNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;
            if (position == 0)
                fragment = new PostsFragment();
            else if (position == 1)
                fragment = new MyJobsFragment();
            else if (position == 2)
                fragment = new AboutFragment();

            return fragment;
        }

        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            String title = null;
            if (position == 0)
                title = "Posts";
            else if (position == 1)
                title = "My Jobs";
            else if (position == 2)
                title = "About";
            return title;
        }
    }


/*intiTab
    OnBackPressedCallback onBackPressedCallback=new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {


        }
    };*/
}