package com.social.mitra.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TermAndConditionActivity extends AppCompatActivity {
    ImageView back_img;
    Session session;
    TextView tv_desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_and_condition);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        back_img = findViewById(R.id.back_img);
        tv_desc = findViewById(R.id.tv_desc);
        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        session = new Session(this);

        tv_desc.setText("1). Everyone like to eat different types of " +
                "rice recipes with different taste." +
                " Here, we will tell you ... \n\n2). Everyone like " +
                "to eat different types of rice recipes with " +
                "different taste. Here, we will tell you ...\n\n3).Everyone like to eat different types of rice recipes with different taste. Here, we will tell you ... \n\n4).Everyone like to eat different types of rice recipes with different taste. Here, we will tell you ... ");

    }


    private void getTermCondition(){

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if(jsonObject.getString("result").equals("true")){

                        progressDialog.dismiss();
                    }else {
                        progressDialog.dismiss();

                        Toast.makeText(TermAndConditionActivity.this, ""+jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    progressDialog.dismiss();

                    Toast.makeText(TermAndConditionActivity.this, ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Toast.makeText(TermAndConditionActivity.this, ""+error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String > map = new HashMap<>();
                map.put("user_id",session.getUser_Id());
                return map;

            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }

}