package com.social.mitra.model;

import org.json.JSONArray;

public class MainCatmodel {
    String id,
            name,
            is_user;
    JSONArray jsonArray;
    boolean isToAdd = false;


    public MainCatmodel(String id, String name, String is_user, JSONArray jsonArray) {
        this.id = id;
        this.name = name;
        this.is_user = is_user;
        this.jsonArray = jsonArray;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIs_user() {
        return is_user;
    }

    public void setIs_user(String is_user) {
        this.is_user = is_user;
    }

    public JSONArray getJsonArray() {
        return jsonArray;
    }

    public void setJsonArray(JSONArray jsonArray) {
        this.jsonArray = jsonArray;
    }

    public boolean isToAdd() {
        return isToAdd;
    }

    public void setToAdd(boolean toAdd) {
        isToAdd = toAdd;
    }
}