package com.social.mitra.model;

public class JobDataList {

    boolean deleted = false;
    String id,user_id, name, user_image, required, description, community_image, created_date, ago_time, liked, like_count, comment_count,city_name,user_type,is_phone,post_user_category,user_mobile, user_path;

    public JobDataList(String id, String user_id, String name, String user_image, String required, String description, String community_image, String created_date, String ago_time, String liked, String like_count, String comment_count, String city_name, String user_type, String is_phone, String post_user_category, String user_mobile) {
        this.id = id;
        this.user_id = user_id;
        this.name = name;
        this.user_image = user_image;
        this.required = required;
        this.description = description;
        this.community_image = community_image;
        this.created_date = created_date;
        this.ago_time = ago_time;
        this.liked = liked;
        this.like_count = like_count;
        this.comment_count = comment_count;
        this.city_name = city_name;
        this.user_type = user_type;
        this.is_phone = is_phone;
        this.post_user_category = post_user_category;
        this.user_mobile = user_mobile;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getUser_path() {
        return user_path;
    }

    public void setUser_path(String user_path) {
        this.user_path = user_path;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getRequired() {
        return required;
    }

    public void setRequired(String required) {
        this.required = required;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCommunity_image() {
        return community_image;
    }

    public void setCommunity_image(String community_image) {
        this.community_image = community_image;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getAgo_time() {
        return ago_time + " ago";
    }

    public void setAgo_time(String ago_time) {
        this.ago_time = ago_time;
    }

    public String getLiked() {
        return liked;
    }

    public void setLiked(String liked) {
        this.liked = liked;
    }

    public String getLike_count() {
        return like_count;
    }

    public void setLike_count(String like_count) {
        this.like_count = like_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getIs_phone() {
        return is_phone;
    }

    public void setIs_phone(String is_phone) {
        this.is_phone = is_phone;
    }

    public String getPost_user_category() {
        return post_user_category;
    }

    public void setPost_user_category(String post_user_category) {
        this.post_user_category = post_user_category;
    }

    public String getUser_mobile() {
        return user_mobile;
    }

    public void setUser_mobile(String user_mobile) {
        this.user_mobile = user_mobile;
    }
}