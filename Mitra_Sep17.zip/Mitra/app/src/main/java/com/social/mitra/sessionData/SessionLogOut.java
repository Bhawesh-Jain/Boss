package com.social.mitra.sessionData;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionLogOut {

    private static final String UserData = "UserData";
    private static final String Profile_STATUS = "Profile_Status";
    public static final String User_Id = "user_id";
    public static final String LOCATIONNM = "locationnm";
    public static final String MOBILE = "Mobile";
    private static final String IS_LOGGEDIN = "isLoggedIn";
    private static final String TYPESELELCTED = "TypeSelected";
    private Context _context;


    private static SharedPreferences userData ;
    private SharedPreferences.Editor editor ;

    public SessionLogOut(Context context)
    {
        this._context = context;
        userData = _context.getSharedPreferences(UserData, Context.MODE_PRIVATE);
        editor = userData.edit();
        editor.apply();

    }



    public void setTypeSelect(boolean TypeSelected) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putBoolean(TYPESELELCTED, TypeSelected);
        editor.commit();
    }

    public boolean IsTypeSelect() {
        return userData.getBoolean(TYPESELELCTED, false);
    }



    public  void setLocName(String loc_name) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(LOCATIONNM,loc_name);
        editor.commit();
    }
    public  String getLocName() {

        return userData.getString(LOCATIONNM, "");
    }


    public  void setUser_Id( String user_id) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(User_Id, user_id);
        editor.commit();
    }

    public  String getUser_Id() {

        return userData.getString(User_Id, "");
    }



    public  void setProfile_status( String profile_status) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Profile_STATUS, profile_status);
        editor.commit();
    }

    public  String getProfile_status() {

        return userData.getString(Profile_STATUS, "");
    }


    public  void setMobilePre( String Mobile) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(MOBILE, Mobile);
        editor.commit();
    }

    public  String getMobilePre() {
        return userData.getString(MOBILE, "");
    }


    public void setLoginSec(boolean isLoggedIn) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putBoolean(IS_LOGGEDIN, isLoggedIn);
        editor.commit();
    }

    public boolean isLoggedInSec() {
        return userData.getBoolean(IS_LOGGEDIN, false);
    }




}
