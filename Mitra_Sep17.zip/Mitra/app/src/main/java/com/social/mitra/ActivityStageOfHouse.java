package com.social.mitra;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_category;
import static com.social.mitra.util.BaseUrl.get_subcategory;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.adapter.GetCategoryAdapter;
import com.social.mitra.adapter.SubCategoryAdapter;
import com.social.mitra.interfa.Category_interface;
import com.social.mitra.interfa.Sub_item_click;
import com.social.mitra.model.HouseGetCategoryModel;
import com.social.mitra.model.SubCategoryModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ActivityStageOfHouse extends AppCompatActivity {
    private static final String TAG = "ActivityStageOfHouse";
    TextView skip_btn;
    ImageView house_back;
    RecyclerView recycler_get_category;
    GetCategoryAdapter getCategoryAdapter;
    SubCategoryAdapter subCategoryAdapter;
    String user_id;
    ArrayList<HouseGetCategoryModel> getCategoryModels = new ArrayList<>();
    ArrayList<SubCategoryModel> subCategoryModels = new ArrayList<>();
    //    ArrayList<CheckBox> array = new ArrayList<>();
    ArrayList<Integer> list_sub_id = new ArrayList<>();
    Session session;
    String cate_id;
    String User_ID;
    String VERIFY_PROFILE = " ";
    String verify = "0";
    String form_status = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stage_of_house);
        session = new Session(ActivityStageOfHouse.this);


        recycler_get_category = findViewById(R.id.recycler_get_category);

        skip_btn = findViewById(R.id.skip_btn);
        house_back = findViewById(R.id.house_back);

        User_ID = session.getUser_Id();
        Log.e(TAG, "---user_id_ActivityStageOfHouse: "+User_ID);

        if (getIntent() != null) {
            VERIFY_PROFILE = getIntent().getStringExtra("status_key");
            form_status = getIntent().getStringExtra("form_status");
            Log.e(TAG, "----pro_status"+VERIFY_PROFILE);
            Log.e(TAG, "----form_status"+form_status);
        }


//        VERIFY_PROFILE = session.getProfile_status();
//        Log.e(TAG, "---VERIFY_PROFILE_ActivityStageOfHouse: "+VERIFY_PROFILE);




        house_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        skip_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityStageOfHouse.this, ActivityVerifyProfile.class);
                intent.putExtra(user_id, "ID");
                startActivity(intent);
            }
        });

        Get_category();
    }

    private void Get_category() {

        Log.e(TAG, "Get_category: ");
        ProgressDialog progressDialog = new ProgressDialog(ActivityStageOfHouse.this);
        progressDialog.show();
        getCategoryModels.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_category, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "--Get_category_onResponse: " + jsonObject);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        progressDialog.dismiss();

                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Cate_id = dataObj.getString("id");
                            Log.e(TAG, "----Cate_id_onResponse: "+Cate_id);




                            String cate_name = dataObj.getString("name");
                            String cate_desc = dataObj.getString("description");
                            String cate_image = dataObj.getString("image");
                            HouseGetCategoryModel houseGetCategoryModel = new HouseGetCategoryModel(Cate_id, cate_image, cate_name, cate_desc);

                            getCategoryModels.add(houseGetCategoryModel);

                        }

                        getCategoryAdapter = new GetCategoryAdapter(ActivityStageOfHouse.this, getCategoryModels, new Category_interface() {
                            @Override
                            public void onItemClick(HouseGetCategoryModel item) {
                                item.getCategory_id();
//                                session.setcate_Id(item.getCategory_id());
                                Toast.makeText(ActivityStageOfHouse.this, "Item Clicked", Toast.LENGTH_LONG).show();
//                                GetSub_cate(item.getCategory_id());
                            }
                        });
                        LinearLayoutManager layoutManager = new LinearLayoutManager(ActivityStageOfHouse.this, LinearLayoutManager.VERTICAL, false);

                        recycler_get_category.setLayoutManager(layoutManager);
                        recycler_get_category.setAdapter(getCategoryAdapter);

                    } else {
                        Toast.makeText(ActivityStageOfHouse.this, "error1" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    Toast.makeText(ActivityStageOfHouse.this, "error2" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(ActivityStageOfHouse.this, "error3" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {


//                @Override
//                protected Map<String, String> getParams() throws AuthFailureError {
//
//                    Map<String, String> map = new HashMap<>();
//                    map.put("user_id", id);
//
//
//                    return map;
//                }
        };

        VolleySingleton.getInstance(ActivityStageOfHouse.this).addToRequestQueue(stringRequest);

    }

    private void GetSub_cate(String category_id) {
        subCategoryModels.clear();
        Log.e(TAG, "Get_Sub_Category: ");
        ProgressDialog progressDialog = new ProgressDialog(ActivityStageOfHouse.this);
        progressDialog.show();
        getCategoryModels.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_subcategory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);


                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(ActivityStageOfHouse.this);
                        View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.bottom_sheet_list_layout, null);
                        mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        mBottomSheetDialog.setContentView(sheetView);
                        RecyclerView recycler_sub_category;
                        CardView btn_next;
                        recycler_sub_category = mBottomSheetDialog.findViewById(R.id.recycler_sub_category);
                        btn_next = mBottomSheetDialog.findViewById(R.id.btn_next);

                        progressDialog.dismiss();
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Sub_Cate_id = dataObj.getString("id");

                            String Sub_cate_name = dataObj.getString("name");

                            SubCategoryModel subCategoryModel = new SubCategoryModel(Sub_Cate_id, Sub_cate_name);

                            subCategoryModels.add(subCategoryModel);
                        }
                       subCategoryAdapter = new SubCategoryAdapter(ActivityStageOfHouse.this, subCategoryModels, new Sub_item_click() {
                           @Override
                           public void SubItemClick(SubCategoryModel item) {
                               item.getSub_cate_id();
                               Log.e(TAG, "SubItemClick:******   "+item.getSub_cate_id());
                               session.setSubcate_Id( item.getSub_cate_id());

                               btn_next.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View view) {
                                       Log.e(TAG, "--btn_nextonClick: ");
                                       if (verify.equalsIgnoreCase(VERIFY_PROFILE)) {
                                           Intent intent = new Intent(ActivityStageOfHouse.this, ActivityVerifyProfile.class);
                                           intent.putExtra("status_key",VERIFY_PROFILE);
                                           intent.putExtra("form_status",form_status);
                                           startActivity(intent);
                                       }else {

                                           Intent intent = new Intent(ActivityStageOfHouse.this, HomeActivity.class);
                                           intent.putExtra("status_key",VERIFY_PROFILE);
                                           intent.putExtra("form_status",form_status);
                                           startActivity(intent);

                                       }
                                   }
                               });
//                               for (int i=0;i<item.getSub_cate_id().length();i++){
//                                   if (subCategoryModels.contains(item.getSub_cate_id())){
//
//                                   }else {
//                                       list_sub_id.add(Integer.valueOf(item.getSub_cate_id()));
//                                       StringBuilder str = new StringBuilder();
//                                       // Traversing the ArrayList
//                                       for (Integer eachstring : list_sub_id) {
//                                           // Each element in ArrayList is appended
//                                           // followed by comma
//                                           str.append(eachstring).append(",");
//                                           Log.e(TAG, "stronItemsSelected: " + str);
//
//                                           // StringBuffer to String conversion
////                                           commaseparatedclassid = str.toStr
//
// ing();
//                                           // getSubjectList(commaseparatedclassid);
//                                           Log.e(TAG, "else-=-=-=-= : " + Integer.parseInt(String.valueOf(item.getSub_cate_id())));
//                                       }
//                                   }
//                               }
                           }
                       });

                        LinearLayoutManager layoutManager = new LinearLayoutManager(ActivityStageOfHouse.this, LinearLayoutManager.VERTICAL, false);
                        recycler_sub_category.setLayoutManager(layoutManager);
                        recycler_sub_category.setAdapter(subCategoryAdapter);
                        mBottomSheetDialog.show();

                    } else {
                        Toast.makeText(ActivityStageOfHouse.this, "error1" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    Toast.makeText(ActivityStageOfHouse.this, "error2" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(ActivityStageOfHouse.this, "error3" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("category_id", category_id);

                return map;
            }
        };

        VolleySingleton.getInstance(ActivityStageOfHouse.this).addToRequestQueue(stringRequest);


    }
}


//    @Override
//    public void Sub_item_click(String id, String data) {
//        if (id.equalsIgnoreCase("1")){
//            Log.e(TAG, "Sub_item_click: "+data );
//            StringBuilder builder = new StringBuilder();
//            builder.append(data);
//        }
//
//
//    }
//}





