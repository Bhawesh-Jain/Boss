package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.Target;
import com.social.mitra.R;
import com.social.mitra.model.DesignModel;

import java.util.ArrayList;

public class DesignAdapter extends RecyclerView.Adapter<DesignAdapter.ViewHolder> {
    private final ArrayList<DesignModel> designModels;
    private final Context context;
    private final String path;

    public DesignAdapter(ArrayList<DesignModel> designModels, Context context, String path) {
        this.designModels = designModels;
        this.context = context;
        this.path = path;
    }

    @NonNull
    @Override
    public DesignAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.design_list_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull DesignAdapter.ViewHolder holder, int position) {
        if (!designModels.get(position).getFile().equalsIgnoreCase(""))
        Glide.with(context)
                .load(path + designModels.get(position).getFile())
                .placeholder(R.drawable.loading)
                .override(Target.SIZE_ORIGINAL)
                .into(holder.design_img);
    }

    @Override
    public int getItemCount() {
        return designModels.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView design_img;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            design_img = itemView.findViewById(R.id.design_img);
        }
    }
}