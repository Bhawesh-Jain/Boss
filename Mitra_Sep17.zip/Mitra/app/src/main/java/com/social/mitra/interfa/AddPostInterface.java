package com.social.mitra.interfa;

public interface AddPostInterface {

    void onHashtagClick(String tag);

    void onCateClick(String id);
}
