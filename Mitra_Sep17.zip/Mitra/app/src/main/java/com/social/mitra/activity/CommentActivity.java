package com.social.mitra.activity;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.comment_on_reel;
import static com.social.mitra.util.BaseUrl.load_reel_comments;
import static com.social.mitra.util.Utils.getRandomColor;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.adapter.ReelCommentAdapter;
import com.social.mitra.databinding.ActivityCommentBinding;
import com.social.mitra.model.ReelComment;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CommentActivity extends AppCompatActivity {

    private final String TAG = CommentActivity.class.getSimpleName();
    private ActivityCommentBinding binding;
    private String reel_id = "";
    private ArrayList<ReelComment> comments = new ArrayList<>();
    private Session session;

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData(reel_id);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        session = new Session(this);

        if (getIntent() != null)
            reel_id = getIntent().getStringExtra("reel_id");


        binding.commentPost.setOnClickListener(view -> addComment());

        binding.backImg.setOnClickListener(view -> onBackPressed());
    }

    private void addComment() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + comment_on_reel, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.d(TAG, "addComment() onResponse called with: response = [" + response + "]");
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true"))
                        loadComments(reel_id);
                    else {
                        Toast.makeText(getApplicationContext(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Log.e(TAG, "likeReel: error", error)) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("comment", binding.commentEdt.getText().toString().trim());
                map.put("reel_id", reel_id);
                map.put("user_id", session.getUser_Id());

                return map;
            }
        };
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    private void loadUserData(String reelId) {
        Log.d(TAG, "loadComments() called with: reelId = [" + reelId + "]");
        ProgressDialog progressDialog = new ProgressDialog(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + load_reel_comments, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    Log.d(TAG, "loadComments() onResponse called with: response = [" + response + "]");
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONObject userData = jsonObject.getJSONObject("data_1");

                        String path = jsonObject.getString("user_path");
                        String id = userData.getString("id");
                        String user_id = userData.getString("user_id");
                        String file = userData.getString("file");
                        String description = userData.getString("description");
                        String image_text = userData.getString("image_text");
                        String type = userData.getString("type");
                        String created_date = userData.getString("created_date");
                        String updated_date = userData.getString("updated_date");
                        String user_name = userData.getString("user_name");
                        String user_image = userData.getString("user_image");

                        binding.tvDescription.setText(description);
                        binding.username.setText(user_name);
                        binding.PostUserImageCard.setCardBackgroundColor(getRandomColor());

                        String myChar = Character.toString(user_name.charAt(0));
                        if (user_image.equalsIgnoreCase(""))
                        binding.PostUserImageTxt.setText(myChar.toUpperCase());
                        else {
                            Glide.with(getApplicationContext()).load(path + user_image).into(binding.PostUserImage);
                            binding.PostUserImageCard.setVisibility(View.GONE);
                        }

                        JSONArray data = jsonObject.getJSONArray("data");

                        comments.clear();
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject commentData = data.getJSONObject(i);

                            String c_id = commentData.getString("id");
                            String c_user_id = commentData.getString("user_id");
                            String c_reel_id = commentData.getString("reel_id");
                            String c_comment = commentData.getString("comment");
                            String c_created_date = commentData.getString("created_date");
                            String c_user_name = commentData.getString("user_name");
                            String c_user_image = commentData.getString("user_image");

                            ReelComment comment = new ReelComment(
                                    c_id,
                                    c_user_id,
                                    c_reel_id,
                                    c_comment,
                                    c_created_date,
                                    c_user_name,
                                    c_user_image,
                                    path
                            );
                            comments.add(comment);
                        }
                        binding.commentsRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        binding.commentsRecyclerView.setAdapter(new ReelCommentAdapter(getApplicationContext(), comments));
                    } else {
                        Toast.makeText(getApplicationContext(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> {
            Log.e(TAG, "likeReel: error", error);
            progressDialog.dismiss();
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("reel_id", reelId);

                return map;
            }
        };
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    private void loadComments(String reelId) {
        Log.d(TAG, "loadComments() called with: reelId = [" + reelId + "]");
        ProgressDialog progressDialog = new ProgressDialog(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + load_reel_comments, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    Log.d(TAG, "loadComments() onResponse called with: response = [" + response + "]");
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONArray data = jsonObject.getJSONArray("data");

                        String path = jsonObject.getString("user_path");

                        comments.clear();
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject commentData = data.getJSONObject(i);

                            String c_id = commentData.getString("id");
                            String c_user_id = commentData.getString("user_id");
                            String c_reel_id = commentData.getString("reel_id");
                            String c_comment = commentData.getString("comment");
                            String c_created_date = commentData.getString("created_date");
                            String c_user_name = commentData.getString("user_name");
                            String c_user_image = commentData.getString("user_image");

                            ReelComment comment = new ReelComment(
                                    c_id,
                                    c_user_id,
                                    c_reel_id,
                                    c_comment,
                                    c_created_date,
                                    c_user_name,
                                    c_user_image,
                                    path
                            );
                            comments.add(comment);
                        }
                        binding.commentsRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        binding.commentsRecyclerView.setAdapter(new ReelCommentAdapter(getApplicationContext(), comments));
                    } else {
                        Toast.makeText(getApplicationContext(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> {
            Log.e(TAG, "likeReel: error", error);
            progressDialog.dismiss();
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("reel_id", reelId);

                return map;
            }
        };
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }
}