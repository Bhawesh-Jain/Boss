package com.social.mitra.adapter;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.IMAGE_URL;
import static com.social.mitra.util.BaseUrl.followUnfollow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.model.FollowersListModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FollowersListAdapter extends RecyclerView.Adapter<FollowersListAdapter.MyViewHolder> {

    Context context;
    ArrayList<FollowersListModel> followersListModels;
    Session session;

    public FollowersListAdapter(Context context, ArrayList<FollowersListModel> followersListModels) {
        this.context = context;
        this.followersListModels = followersListModels;
        session = new Session(context);
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {

        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.followers_list_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NotNull FollowersListAdapter.MyViewHolder holder, int position) {
        if (followersListModels.size() > 0) {
            holder.txtname.setText(followersListModels.get(position).getName());
            Glide.with(context).load(IMAGE_URL + followersListModels.get(position).getImage()).placeholder(R.drawable.loading).into(holder.user_img).onLoadFailed(context.getResources().getDrawable(R.drawable.person_user));

            holder.unfollow_tv.setOnClickListener(view -> dialog(followersListModels.get(position).getName(), followersListModels.get(position).getId(), holder.unfollow_tv));
        }
    }

    private void dialog(String name, String id, TextView btn) {
        if (btn.getText().toString().equalsIgnoreCase("Following"))
            new AlertDialog.Builder(context)
                    .setTitle("Unfollow")
                    .setMessage("Confirm to Unfollow " + name)
                    .setPositiveButton("Confirm", (dialogInterface, i) -> {
                        followUnfollow(session.getUser_Id(), id, btn);
                        dialogInterface.dismiss();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        else
            new AlertDialog.Builder(context)
                    .setTitle("Follow")
                    .setMessage("Confirm to Follow " + name)
                    .setPositiveButton("Confirm", (dialogInterface, i) -> {
                        followUnfollow(session.getUser_Id(), id, btn);
                        dialogInterface.dismiss();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
    }

    private void followUnfollow(String user_id, String Id, TextView btn) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + followUnfollow, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equals("true")) {
                        if (jsonObject.getString("msg").equals("Followed")) {
                            btn.setText("Following");
                        } else {
                            btn.setText("Follow");
                        }
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                }
            }
        }, error -> progressDialog.dismiss()) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("to_user_id", Id);
                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    @Override
    public int getItemCount() {
        return followersListModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtname, unfollow_tv;
        ImageView user_img;

        public MyViewHolder(@NonNull @NotNull View itemView) {

            super(itemView);
            txtname = itemView.findViewById(R.id.txtname);
            unfollow_tv = itemView.findViewById(R.id.unfollow_tv);
            user_img = itemView.findViewById(R.id.user_img);
        }
    }

}
