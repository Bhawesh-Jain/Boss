package com.social.mitra;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.login;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.hbb20.CountryCodePicker;
import com.social.mitra.activity.OtpVerificationActivity;
import com.social.mitra.gps.GPSTracker;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ActivityLogin extends AppCompatActivity {


    private static final String TAG = "Login ";
    private static final int REQUEST_LOCATION = 1;
    private static final int MY_PERMISSION_ACCESS_COURSE_LOCATION = 12;
    TextView Login_user, txtprivacy;
    LinearLayout Signupss;
    TextView AG_FORGOTPASSWORD, AG_SIGNUP;
    EditText login_mobile_edt, login_password_edt;
    Session session;
    String mobile;
    String store_mobile;
    String token = "";
    String country_code = "";
    CountryCodePicker ccp;
    SessionLogOut sessionLogOut;
    String MOBILE_PRE;
    Boolean temp = false;
    Boolean temp_one = false;
    String Profile_status = "0";
    String Pro_status;
    String user_otp;
    String Verify_Profile;
    RelativeLayout Layout_Progress;
    GPSTracker gps;


    LocationManager locationManager;
    String latitude, longitude;
    private String fcm_id = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                fcm_id = instanceIdResult.getToken();
                // send it to server

                Log.e("refresh_tokentoken", fcm_id);

            }
        });


        gps = new GPSTracker(ActivityLogin.this);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);


        session = new Session(this);
        sessionLogOut = new SessionLogOut(this);

        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{
                            android.Manifest.permission.ACCESS_COARSE_LOCATION},
                    GPSTracker.MY_PERMISSION_ACCESS_COURSE_LOCATION);
        } else {
            if (Build.VERSION.SDK_INT >= 23 &&
                    ContextCompat.checkSelfPermission(getApplicationContext(),
                            android.Manifest.permission.ACCESS_FINE_LOCATION) !=
                            PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(getApplicationContext(),
                            android.Manifest.permission.ACCESS_COARSE_LOCATION) !=
                            PackageManager.PERMISSION_GRANTED) {
                return;
            }

        }
        gps = new GPSTracker(this);

        try {
            if (gps != null) {
                if (gps.canGetLocation()) {
                    Log.e(TAG, "onCreate: " + gps.getLocation().getLongitude());


                } else {
                    OnGPS();
                }
            }
        } catch (Exception e) {

        }



      /*  ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);


        if (ContextCompat.checkSelfPermission( ActivityLogin.this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION ) !=
                PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions( ActivityLogin.this,
                    new String[] {android.Manifest.permission.
                            ACCESS_COARSE_LOCATION},
                    ActivityLogin.MY_PERMISSION_ACCESS_COURSE_LOCATION);
        }

        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
         location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (gpsTracker.canGetLocation()){
            getlatlong();

        }
        else{
            OnGPS();
        }
*/


        Login_user = findViewById(R.id.Login_user);
        txtprivacy = findViewById(R.id.txtprivacy);
//        ccp = findViewById(R.id.select_cc);
        login_mobile_edt = findViewById(R.id.login_mobile_edt);

        Layout_Progress = findViewById(R.id.Layout_Progress);

        store_mobile = session.getMobile();
        MOBILE_PRE = sessionLogOut.getMobilePre();
        Pro_status = sessionLogOut.getProfile_status();


        Log.e(TAG, "--store_mobile_onCreate: " + store_mobile);

        if (sessionLogOut.isLoggedInSec()) {
            temp = !temp;
            temp_one = !temp_one;
            try {
                final BottomSheetDialog mbottomSheetDialog = new BottomSheetDialog(ActivityLogin.this);

                mbottomSheetDialog.setContentView(R.layout.login_bottom);
                mbottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                mbottomSheetDialog.setCanceledOnTouchOutside(true);


                TextView previous_mobile_number, txt_another_number, user_name_profile, user_mobile_number, user_mail, icon_arrow, icon_arrow_sec;
                LinearLayout user_previous_details, use_pre_num_btn;
                icon_arrow = mbottomSheetDialog.findViewById(R.id.icon_arrow);
                icon_arrow_sec = mbottomSheetDialog.findViewById(R.id.icon_arrow_sec);
                previous_mobile_number = mbottomSheetDialog.findViewById(R.id.previous_mobile_number);
                user_mobile_number = mbottomSheetDialog.findViewById(R.id.user_mobile_number);
                user_previous_details = mbottomSheetDialog.findViewById(R.id.user_previous_details);
                txt_another_number = mbottomSheetDialog.findViewById(R.id.txt_another_number);
                use_pre_num_btn = mbottomSheetDialog.findViewById(R.id.use_pre_num_btn);
                user_previous_details.setVisibility(GONE);
                icon_arrow_sec.setVisibility(GONE);

                previous_mobile_number.setText(MOBILE_PRE);
                user_mobile_number.setText(MOBILE_PRE);


                icon_arrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        user_previous_details.setVisibility(VISIBLE);
                        icon_arrow_sec.setVisibility(VISIBLE);
                        icon_arrow.setVisibility(GONE);

                    }
                });

                icon_arrow_sec.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        icon_arrow.setVisibility(VISIBLE);
                        icon_arrow_sec.setVisibility(GONE);
                        user_previous_details.setVisibility(GONE);
                    }
                });

                use_pre_num_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
//                    Intent intent = new Intent(ActivityLogin.this, OtpVerificationActivity.class);
//                    startActivity(intent);
                        login_User(MOBILE_PRE);
                        mbottomSheetDialog.dismiss();

                    }
                });

                txt_another_number.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mbottomSheetDialog.dismiss();
                    }
                });
                mbottomSheetDialog.show();

            } catch (Exception e) {

                Log.e(TAG, "onCreate: " + e.toString());

            }
        }


//        mobile = login_mobile_edt.getText().toString();
//        if (mobile.length() < 10 && mobile.length() > 10) {
//        if (login_mobile_edt.getText().toString().equals("")) {
//                login_mobile_edt.setFocusable(true);
//                login_mobile_edt.setError("Enter Your Register Mobile Number");
//            }
//        }else {
//
//            login_successfull();
//
//        }
//        login_mobile_edt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
//        login_mobile_edt.setKeyListener(DigitsKeyListener.getInstance("0123456789"));

        login_mobile_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Log.e(TAG, "beforeTextChanged: ");

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.e(TAG, "onTextChanged: ");

            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.e(TAG, "afterTextChanged: ");
                if (login_mobile_edt.getText().toString().length() > 9) {
                    Login_user.setBackgroundResource(R.drawable.btn_accept_new_bg);

                }

            }
        });
        login_mobile_edt.setInputType(InputType.TYPE_CLASS_NUMBER);
        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        login_mobile_edt.setFilters(FilterArray);

        Login_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mobile = login_mobile_edt.getText().toString();
                if (mobile.isEmpty() || login_mobile_edt.getText().toString().toString().length() < 10 || mobile.length() > 10) {
                    login_mobile_edt.setFocusable(true);
                    login_mobile_edt.setError("Enter Your Correct Mobile Number");
                } else {

                    loginUser(mobile);

                }
            }
        });

        String text = "<font color=#757575>By continuing, you agree to the </font> <font color=#ff0000>terms </font><font color=#757575>and </font> <font color=#ff0000>privacy policy </font><font color=#757575>of Construction Mitra</font>";


//        ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
//            @Override
//            public void onCountrySelected() {
//
//                country_code = ccp.getSelectedCountryCode();
//                Toast.makeText(ActivityLogin.this, "" + country_code, Toast.LENGTH_SHORT).show();
//            }
//        });ff0000

        txtprivacy.setText(Html.fromHtml(text));

    }

    private void loginUser(String mobile) {

        Layout_Progress.setVisibility(VISIBLE);
        Log.e(TAG, "***loginUser: ");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + login, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Layout_Progress.setVisibility(GONE);
                    Log.e(TAG, "====First_onResponse:login-----" + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String User_id = data.getString("id");
                        user_otp = data.getString("otp");
                        String user_mobile = data.getString("mobile");
                        String USER_TYPE = data.getString("type");


                        Log.e(TAG, "idonResponse: " + User_id);
                        Log.e(TAG, "OTPonResponse: " + user_otp);
                        Log.e(TAG, "--ser_mobileOTPonResponse: " + user_mobile);
                        Log.e(TAG, "--USER_TYPEOTPonResponse: " + USER_TYPE);
                        String Form_Status = data.getString("form_status");
                        String Verify_Profile = data.getString("verify_profile");
                        Log.e(TAG, "--Verify_Profile: " + Verify_Profile);
                        Log.e(TAG, "--Form_Status: " + Form_Status);

                        session.setMobile(user_mobile);
                        sessionLogOut.setMobilePre(user_mobile);
                        sessionLogOut.setProfile_status(Verify_Profile);


                        Intent intent = new Intent(ActivityLogin.this, OtpVerificationActivity.class);
                        intent.putExtra("ID", User_id);
                        intent.putExtra("OTP", user_otp);
                        intent.putExtra("MOBILE", user_mobile);
                        intent.putExtra("status_key", Verify_Profile);
                        intent.putExtra("form_status", Form_Status);

                        startActivity(intent);
                        finish();
                    } else {
                        Layout_Progress.setVisibility(GONE);
                    }
                } catch (JSONException e) {
                    Layout_Progress.setVisibility(GONE);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {


            @Override
            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
                Layout_Progress.setVisibility(GONE);

//                    Toast.makeText(ActivityLogin.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("mobile", mobile);
                map.put("fcm_id", fcm_id);
                Log.e(TAG, "getParams:loginn onResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


//        Toast.makeText(ActivityLocation.this, gpsTracker.getLocation().toString(), Toast.LENGTH_SHORT).show();

           /* }else {
                Log.e(TAG, "getLocation:  not getting  gps.canGetLocation()" );
            }
        }catch (Exception e){

        }*/


    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ActivityLogin.this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private void login_User(String mobile_pre) {
        Layout_Progress.setVisibility(VISIBLE);
        Log.e(TAG, "***login_User: ");
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + login, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

//                    progressDialog.dismiss();
                    Log.e(TAG, "==onResponse:login_User" + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String User_id = data.getString("id");
                        user_otp = data.getString("otp");
                        String user_mobile = data.getString("mobile");
                        String USER_TYPE = data.getString("type");


                        Log.e(TAG, "idonResponse: " + User_id);
                        Log.e(TAG, "OTPonResponse: " + user_otp);
                        Log.e(TAG, "--ser_mobileOTPonResponse: " + user_mobile);
                        Log.e(TAG, "--USER_TYPEOTPonResponse: " + USER_TYPE);
                        String Form_Status = data.getString("form_status");
                        Verify_Profile = data.getString("verify_profile");
                        Log.e(TAG, "--Verify_Profile: " + Verify_Profile);
                        Log.e(TAG, "--Form_Status: " + Form_Status);


                        session.setMobile(user_mobile);
                        sessionLogOut.setMobilePre(user_mobile);

                        Intent intent = new Intent(ActivityLogin.this, OtpVerificationActivity.class);
                        intent.putExtra("ID", User_id);
                        intent.putExtra("OTP", user_otp);
                        intent.putExtra("PreMobNum", MOBILE_PRE);
                        intent.putExtra("KeyType", USER_TYPE);
                        intent.putExtra("PRO_key", Verify_Profile);
                        intent.putExtra("form_status", Form_Status);
                        startActivity(intent);
                        finish();


                    } else {
                        Layout_Progress.setVisibility(GONE);
//                        progressDialog.dismiss();


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Layout_Progress.setVisibility(GONE);
//                    progressDialog.dismiss();


                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Layout_Progress.setVisibility(GONE);
//                progressDialog.dismiss();

                Toast.makeText(ActivityLogin.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("mobile", mobile_pre);
                map.put("fcm_id", fcm_id);
                Log.e(TAG, "getParams:loginn onResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }


    private boolean emailValid(String email) {

        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();

    }


}
