package com.social.mitra.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.social.mitra.R;
import com.social.mitra.activity.SinglePostDetailsActivity;
import com.social.mitra.model.ProfilePostModel;
import com.social.mitra.util.BaseUrl;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class ProfilePostAdapter extends RecyclerView.Adapter<ProfilePostAdapter.MyViewHolder> {

    Context context;
    ArrayList<ProfilePostModel> profilePostModels;

    public ProfilePostAdapter(Context context, ArrayList<ProfilePostModel> profilePostModels) {
        this.context = context;
        this.profilePostModels = profilePostModels;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.image_video_lay, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ProfilePostAdapter.MyViewHolder holder, int position) {

        ProfilePostModel profilePostModel = profilePostModels.get(position);


        if (profilePostModels.size() > 0) {

            if (!profilePostModel.getPost_image().equals("")) {


                Glide.with(context).load(BaseUrl.Post_image_Url + profilePostModel.getPost_image())
                        .placeholder(R.drawable.dhaniya_img).into(holder.image_img);



            } else if (!profilePostModel.getPost_video().equals("")) {

                RequestOptions requestOptions = new RequestOptions();
                Glide.with(context)
                        .load(BaseUrl.Post_Video_Url + profilePostModel.getPost_video())
                        .apply(requestOptions)
                        .centerCrop()
                        .thumbnail(Glide.with(context).load(BaseUrl.Post_Video_Url + profilePostModel.getPost_video()))
                        .into(holder.image_img);
            }

            holder.image_img.setImageResource(profilePostModel.getImage());


            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(context, SinglePostDetailsActivity.class);
                    intent.putExtra("post_id",profilePostModel.getPost_id());
                    context.startActivity(intent);

                }
            });


        }


    }

    @Override
    public int getItemCount() {
        return profilePostModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView image_img;

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            image_img = itemView.findViewById(R.id.image_img);
        }
    }
}
