package com.social.mitra.firebase;

public class Config {


    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String CHANNEL_NAME = "mitra";

    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;
    public static final String SHARED_PREF = "ah_firebase";
}