package com.social.mitra.activity.homePage;

public interface HomeInterface {

    void setWorkTab();
}
