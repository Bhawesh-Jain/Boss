package com.social.mitra.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.jarvanmo.exoplayerview.ui.ExoVideoView;
import com.makeramen.roundedimageview.RoundedImageView;
import com.social.mitra.R;
import com.social.mitra.sessionData.Session;

import de.hdodenhof.circleimageview.CircleImageView;


public class SinglePostDetailsActivity extends AppCompatActivity {

    static int flag = 0;
    static int like = 0;
    Session session;
    ImageView bookmark, like_img, back_img, comment_img, refre_img,
            report_abuse_img;

    TextView user_text_message, user_name, post_date_time, total_refers, total_likes, user_position;
    String post_img = "", post_video = "", text_message = "",
            username = "", post_id = "", image = "", user_id = "";
    ExoVideoView videoView;
    CardView card_video;
    RoundedImageView post_image;

    LinearLayout refer_user_lay;
    CircleImageView user_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_post_details);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        comment_img = findViewById(R.id.comment_img);
        session = new Session(this);

        like_img = findViewById(R.id.delete_img);
        refer_user_lay = findViewById(R.id.refer_user_lay);
        user_position = findViewById(R.id.user_position);
        total_likes = findViewById(R.id.total_likes);
        total_refers = findViewById(R.id.total_refers);
        post_date_time = findViewById(R.id.post_date_time);
        user_name = findViewById(R.id.user_name);

        videoView = findViewById(R.id.videoView);
        user_image = findViewById(R.id.user_image);
        user_text_message = findViewById(R.id.user_text_message);
        card_video = findViewById(R.id.card_video);
        post_image = findViewById(R.id.post_image);
        back_img = findViewById(R.id.back_img);
        bookmark = findViewById(R.id.bookmark_img);
        refre_img = findViewById(R.id.reference_img);
        report_abuse_img = findViewById(R.id.report_abuse_img);


        if (getIntent() != null) {

            post_id = getIntent().getStringExtra("post_id");

//            getPostDetails(post_id);
//            postLikeCount(post_id);
        }
        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (flag == 0) {

                    flag = 1;
                    bookmark.setImageResource(R.drawable.fill_bookmark);

                } else {

                    flag = 0;
                    bookmark.setImageResource(R.drawable.empty_bookmark);

                }

            }
        });




        like_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


//                postLikeDislike();
              /*  if (like == 0) {
                    like++;
                    like_img.setImageResource(R.drawable.fill_heart);
                } else {
                    like = 0;
                    like_img.setImageResource(R.drawable.empty_heart);
                }*/

            }
        });


        comment_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(SinglePostDetailsActivity.this, PostCommentActivity.class));

            }
        });


        refre_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                new AlertDialog.Builder(SinglePostDetailsActivity.this)
                        .setTitle("Reference Add")
                        .setMessage("I do refer his/her business")
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
//                        postRefer(session.getUser_Id(), user_id);


                    }
                }).show();



            }
        });


        report_abuse_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BottomSheetDialog bottomSheet = new BottomSheetDialog(SinglePostDetailsActivity.this, R.style.BottomSheetDialog);
                bottomSheet.setContentView(R.layout.report_abuse_lay);
                bottomSheet.setCancelable(true);
                bottomSheet.setCanceledOnTouchOutside(true);
                bottomSheet.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


                bottomSheet.show();
            }
        });


    }

//    private void postLikeDislike() {
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + like_unlike_ios, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//                        String status = jsonObject.getString("status");
//
//
//                        if (status.equals("1")) {
//                            postLikeCount(post_id);
//                            like_img.setImageResource(R.drawable.heart_blue);
//
//                        } else if (status.equals("0")) {
//                            postLikeCount(post_id);
//                            like_img.setImageResource(R.drawable.empty_heart);
//                        }
//
//
//                    }
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    Toast.makeText(SinglePostDetailsActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                Toast.makeText(SinglePostDetailsActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> map = new HashMap<>();
//
//                map.put("user_id", session.getUser_Id());
//                map.put("post_id", post_id);
//
//
//                return map;
//            }
//        };
//
//        VolleySingleton.getInstance(SinglePostDetailsActivity.this).addToRequestQueue(stringRequest);
//
//    }


//    private void getPostDetails(String post_id) {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_single_post, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//
//                        progressDialog.dismiss();
//
//                        JSONObject Data = jsonObject.getJSONObject("Data");
//
//
//                        user_id = Data.getString("user_id");
//                        post_img = Data.getString("post_img");
//                        post_video = Data.getString("post_video");
//                        text_message = Data.getString("text_message");
//                        username = Data.getString("username");
//
//                        String post_id = Data.getString("post_id");
//
//                        image = Data.getString("image");
//
//
//                        Glide.with(SinglePostDetailsActivity.this)
//                                .load(User_image_Url + image).placeholder(R.drawable.user).into(user_image);
//
//                        user_name.setText(username + "");
//
//                        if (!text_message.equals("")) {
//                            user_text_message.setVisibility(View.VISIBLE);
//                            user_text_message.setText(text_message);
//
//                        } else {
//
//                            user_text_message.setVisibility(View.GONE);
//                        }
//
//                        Log.e(" SinglePost ", "onResponse: post Img" + post_img + "  " + post_video);
//                        if (!post_video.equals("")) {
//
//                            card_video.setVisibility(View.VISIBLE);
//                            post_image.setVisibility(View.GONE);
//
//                            SimpleMediaSource mediaSource = new SimpleMediaSource(Post_Video_Url + post_video);
//
//                            videoView.hideController();
//                            videoView.setControllerAutoShow(false);
//                            videoView.setUseController(false);
//                            videoView.changeWidgetVisibility(R.id.exo_player_controller_back, View.INVISIBLE);
//
//                            videoView.play(mediaSource);
//
//
//                        } else if (!post_img.equals("")) {
//
//                            post_image.setVisibility(View.VISIBLE);
//                            card_video.setVisibility(View.GONE);
//
//                            Glide.with(SinglePostDetailsActivity.this)
//                                    .load(Post_image_Url + post_img).into(post_image);
//
//                        }
//
//
//                    } else {
//
//                        progressDialog.dismiss();
//
//                        Toast.makeText(SinglePostDetailsActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//
//                    }
//                } catch (JSONException e) {
//                    progressDialog.dismiss();
//
//                    Toast.makeText(SinglePostDetailsActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//
//                Toast.makeText(SinglePostDetailsActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> map = new HashMap<>();
//
//                map.put("post_id", post_id);
//                return map;
//
//            }
//        };
//
//        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
//
//    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (card_video.getVisibility() == View.VISIBLE) {

            videoView.stop();

        }

    }


//    private void postLikeCount(String post_id) {
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + count_like, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                Log.e("Post ", "onResponse: " + response.toString());
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//
//                        total_likes.setText(jsonObject.getString("total_like"));
//                    } else {
//
//                        total_likes.setText(jsonObject.getString("total_like"));
//
//                    }
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    Toast.makeText(SinglePostDetailsActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                Toast.makeText(SinglePostDetailsActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> map = new HashMap<>();
//
//                map.put("user_id", session.getUser_Id());
//                map.put("post_id", post_id);
//
//                return map;
//            }
//        };
//
//        VolleySingleton.getInstance(SinglePostDetailsActivity.this).addToRequestQueue(stringRequest);
//    }





//    private void postRefer(String my_id, String user_id) {
//
//        ProgressDialog progressDialog = new ProgressDialog(SinglePostDetailsActivity.this);
//        progressDialog.show();
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + References_unRef, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if(jsonObject.getString("result").equals("true")){
//
//                        progressDialog.dismiss();
//                        String status = jsonObject.getString("status");
//
//                        if(status.equals("1")){
//                            refre_img.setImageResource(R.drawable.refre_blue);
//                        }else {
//                            refre_img.setImageResource(R.drawable.refre_empty);
//                        }
//                    }else {
//                        progressDialog.dismiss();
//
//                    }
//
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//
//                    Toast.makeText(SinglePostDetailsActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                }
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//
//                Toast.makeText(SinglePostDetailsActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> map = new HashMap<>();
//                map.put("user_id", my_id);
//                map.put("to_user_id", user_id);
//
//                return map;
//            }
//        };
//
//        VolleySingleton.getInstance(SinglePostDetailsActivity.this).addToRequestQueue(stringRequest);
//    }

}