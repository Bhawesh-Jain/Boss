package com.social.mitra.model;

public class NotificationModel {
    String id, msg, sender_image, path;

    public NotificationModel(String id, String msg, String sender_image, String path) {
        this.id = id;
        this.msg = msg;
        this.sender_image = sender_image;
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getSender_image() {
        return sender_image;
    }

    public void setSender_image(String sender_image) {
        this.sender_image = sender_image;
    }
}
