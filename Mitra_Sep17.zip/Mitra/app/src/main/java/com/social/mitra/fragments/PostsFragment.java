package com.social.mitra.fragments;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_my_reels;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.social.mitra.R;
import com.social.mitra.activity.AddPostActivity;
import com.social.mitra.adapter.PostAdapter;
import com.social.mitra.model.JobDataList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class PostsFragment extends Fragment {

    private static final String TAG = "PostsFragment";
    Session session;
    View root;
    TextView btn_post_, txtnopost;
    ArrayList<String> fileArrayList = new ArrayList<>();
    RecyclerView rv_posts;
    String _liked;
    String _like_count;
    String _comment_count;
    String Community_id;
    LinearLayout llnopost;
    String other = "", id = "";

    public PostsFragment(String other) {
        this.other = other;
    }

    public PostsFragment(String other, String id) {
        this.other = other;
        this.id = id;
    }

    public PostsFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_posts, container, false);
        session = new Session(getActivity());
        btn_post_ = root.findViewById(R.id.btn_post_);
        txtnopost = root.findViewById(R.id.txtnopost);
        rv_posts = root.findViewById(R.id.rv_posts);
        llnopost = root.findViewById(R.id.llnopost);
        Log.e(TAG, "onCreateView:session.getName() " + session.getName());
        txtnopost.setText("User has not posted anything. Please revisit profile after sometime.");

        if (other.equalsIgnoreCase("other")) {
            btn_post_.setVisibility(View.GONE);
        }

        btn_post_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog();
                /*BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getActivity());

                bottomSheetDialog.setContentView(R.layout.bottom_sheet_post);
                bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                bottomSheetDialog.setCanceledOnTouchOutside(true);

                TextView For_Continue, For_Cancel;
                For_Continue = bottomSheetDialog.findViewById(R.id.For_Continue);
                For_Cancel = bottomSheetDialog.findViewById(R.id.For_Cancel);

                For_Cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new AlertDialog.Builder(getActivity())
                                .setTitle("Create post")
                                .setMessage("Homeowners can't create post.")
                                .setPositiveButton("Contact US", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                }).show();
                    }
                });

                bottomSheetDialog.show();*/
            }
        });
        if (id.equalsIgnoreCase(""))
            get_Community(session.getUser_Id());
        else get_Community(id);

        return root;

    }

    void dialog() {
        Dialog dialogView = new Dialog(getContext());
        dialogView.setContentView(R.layout.dialog_addpost);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView text, photo, video;

        text = dialogView.findViewById(R.id.text_add_post);
        photo = dialogView.findViewById(R.id.photo_add_post);
        video = dialogView.findViewById(R.id.video_add_post);

        if (text != null)
            text.setOnClickListener(view -> {
                startActivity(new Intent(getActivity(), AddPostActivity.class).putExtra("mode", "text"));
                dialogView.dismiss();
            });
        if (photo != null)
            photo.setOnClickListener(view -> {
                startActivity(new Intent(getActivity(), AddPostActivity.class).putExtra("mode", "image"));
                dialogView.dismiss();
            });
        if (video != null)
            video.setOnClickListener(view -> {
                startActivity(new Intent(getActivity(), AddPostActivity.class).putExtra("mode", "video"));
                dialogView.dismiss();
            });
        dialogView.show();

    }

    private void get_Community(String user_id) {
        Log.e(TAG, "***_Get_Community: ");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_my_reels, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "onResponse: " + response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        llnopost.setVisibility(View.GONE);
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        String path = jsonObject.getString("path");
                        fileArrayList.clear();
                        for (int i = 0; i<jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);
                            if (dataObj.getString("type").equalsIgnoreCase("image")) {
                                fileArrayList.add(dataObj.getString("file"));
                                if (!dataObj.getString("image_2").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_2"));
                                if (!dataObj.getString("image_3").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_3"));
                                if (!dataObj.getString("image_4").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_4"));
                                if (!dataObj.getString("image_5").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_5"));
                                if (!dataObj.getString("image_6").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_6"));
                                if (!dataObj.getString("image_7").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_7"));
                                if (!dataObj.getString("image_8").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_8"));
                                if (!dataObj.getString("image_9").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_9"));
                                if (!dataObj.getString("image_10").equalsIgnoreCase("")) fileArrayList.add(dataObj.getString("image_10"));
                            }
                        }
                        rv_posts.setLayoutManager(new GridLayoutManager(getContext(), 2));
                        rv_posts.setAdapter(new PostAdapter(getContext(), fileArrayList, path));
                    } else {
                        if (jsonObject.getString("result").equalsIgnoreCase("false")) {
                            llnopost.setVisibility(View.VISIBLE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(getActivity(), "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);

                return map;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);


    }


}