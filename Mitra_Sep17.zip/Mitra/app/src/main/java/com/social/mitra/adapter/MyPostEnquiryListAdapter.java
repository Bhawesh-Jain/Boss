package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.model.MyPostEnquiryListModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class MyPostEnquiryListAdapter extends RecyclerView.Adapter<MyPostEnquiryListAdapter.MyViewHolder> {

    Context context;
    ArrayList<MyPostEnquiryListModel> myPostEnquiryListModels;

    public MyPostEnquiryListAdapter(Context context, ArrayList<MyPostEnquiryListModel> myPostEnquiryListModels) {
        this.context = context;
        this.myPostEnquiryListModels = myPostEnquiryListModels;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {

        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.my_post_enquiry_list_layout,parent,false));

    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MyPostEnquiryListAdapter.MyViewHolder holder, int position) {

        if(myPostEnquiryListModels.size()>0){

        }else {

        }
    }

    @Override
    public int getItemCount() {
        return myPostEnquiryListModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
        }
    }
}
