package com.social.mitra.activity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.adapter.ImageViewPager;


public class ImageFragment extends Fragment {
    String link;

    public ImageFragment(String link) {
        this.link = link;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_image, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ImageView fullImage = view.findViewById(R.id.full_screen_image);

        Glide.with(getContext()).load(link).into(fullImage);
    }
}