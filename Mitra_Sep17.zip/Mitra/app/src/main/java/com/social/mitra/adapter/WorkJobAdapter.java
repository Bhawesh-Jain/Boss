package com.social.mitra.adapter;

import static android.content.ContentValues.TAG;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.USER_JOB_URL;
import static com.social.mitra.util.BaseUrl.like_unlike_community;
import static com.social.mitra.util.BaseUrl.report_community_post;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.activity.PostCommentActivity;
import com.social.mitra.activity.VisitSingleProfileActivity;
import com.social.mitra.model.JobDataList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class WorkJobAdapter extends RecyclerView.Adapter<WorkJobAdapter.MyViewHolder> {

    static int ref = 0;
    private final int mCounter = 0;
    ArrayList<JobDataList> jobDataListArrayList;
    Context context;
    Session session;
    String User_ID, COM_ID;
    Boolean like_un_like = false;
    String status = "Liked successfully";
    String status_1 = "Unliked successfully";
    String like;
    String un_like;
    String comment_id;
    String community_path;
    String like_count_;
    String comment_count;
    int likee = 0;

    public WorkJobAdapter(ArrayList<JobDataList> jobDataListArrayList, Context context, String community_path) {
        this.jobDataListArrayList = jobDataListArrayList;
        this.context = context;
        this.community_path = community_path;
    }

    @NonNull
    @Override
    public WorkJobAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_joblist, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull WorkJobAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        session = new Session(context);
        User_ID = session.getUser_Id();
        like_count_ = jobDataListArrayList.get(position).getLike_count();
        like = jobDataListArrayList.get(position).getLiked();
        un_like = jobDataListArrayList.get(position).getLike_count();
        comment_count = jobDataListArrayList.get(position).getComment_count();

        holder.LIKE_COUNT.setText(like_count_);
        JobDataList jobDataList = jobDataListArrayList.get(position);

        holder._USER_NAME_.setText(jobDataList.getName());
        holder.REQ_TYPE.setText(jobDataList.getRequired());
        holder._USER_DESC_.setText(jobDataList.getDescription());
        holder.COMMENT_COUNT__.setText(jobDataList.getComment_count());

        if (jobDataList.getCity_name().equalsIgnoreCase("Select city")) {
            holder.LOC__.setText("");
        } else {
            holder.LOC__.setText(jobDataList.getCity_name());
        }

        holder.txttimeago.setText(jobDataList.getAgo_time());

        if (jobDataList.getPost_user_category() != null && !jobDataList.getPost_user_category().isEmpty() && !jobDataList.getPost_user_category().equals("null") && !jobDataList.getPost_user_category().equals("0")) {
            holder.TIME_AGO.setText(jobDataList.getPost_user_category());
        } else {
            holder.TIME_AGO.setText("Home owner");
        }

        holder.comment_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (jobDataList.getIs_phone().equalsIgnoreCase("yes")) {
                    Log.e(TAG, "onClick:id-=-=--=- " + jobDataListArrayList.get(position).getId());
                    Intent intent = new Intent(context, PostCommentActivity.class);
                    intent.putExtra("id", jobDataListArrayList.get(position).getId());
                    context.startActivity(intent);
                }
            }
        });

        if (jobDataList.getLiked().equals("0")) {
            holder.LIKE_POST.setImageResource(R.drawable.love);
        } else if (jobDataList.getLiked().equals("1")) {
            holder.LIKE_POST.setImageResource(R.drawable.like_heart_icon);
        }
        Log.e(TAG, "Proimage<><><<>   : " + USER_JOB_URL + jobDataList.getUser_image());

        String myChar = "X";
        if (!jobDataList.getName().equalsIgnoreCase(""))
            myChar = Character.toString(jobDataList.getName().charAt(0));

        holder.txtlet.setText(myChar.toUpperCase(Locale.ROOT));
        if (!jobDataList.getUser_image().equalsIgnoreCase(""))
            Glide.with(context).load(USER_JOB_URL + jobDataList.getUser_image())
                    .placeholder(R.drawable.user)
                    .into(holder._IMAGE_);
        else holder.txtlet.setVisibility(VISIBLE);

        if (jobDataList.getCommunity_image() != null && !jobDataList.getCommunity_image().isEmpty() && !jobDataList.getCommunity_image().equals("null") && !jobDataList.getCommunity_image().equals("0")) {
            holder.Image_C.setVisibility(VISIBLE);
            Log.e(TAG, "onBindViewHolder:community_path + jobDataList.getCommunity_image() " + community_path + jobDataList.getCommunity_image());
            Glide.with(context).load(community_path + jobDataList.getCommunity_image())
                    .into(holder.IMG_SHOW_POST);
        } else {
            holder.Image_C.setVisibility(GONE);
        }

        holder.like_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Like_Unlike_Community(User_ID, jobDataListArrayList.get(position).getId(), holder.LIKE_POST, holder.LIKE_COUNT, jobDataList);
            }
        });

        holder._IMAGE_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, VisitSingleProfileActivity.class);
                intent.putExtra("id", jobDataListArrayList.get(position).getUser_id());
                context.startActivity(intent);
            }
        });

        holder.IMG_SHOW_POST.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.image_dialoge);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

                ImageView imgpop = dialog.findViewById(R.id.imgpop);
                Log.e(TAG, "onClick:image><>>>  " + community_path + jobDataList.getCommunity_image());
                Glide.with(context).load(community_path + jobDataList.getCommunity_image())
                        .into(imgpop);
            }
        });

        holder.call_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (jobDataList.getLiked().equals("1")) {
                    if (jobDataList.getUser_mobile().equalsIgnoreCase("no")) {
                        Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent intentDial = new Intent
                                (Intent.ACTION_DIAL, Uri.parse("tel:" + jobDataList.getUser_mobile()));

                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions((Activity) context,
                                    new String[]{Manifest.permission.CALL_PHONE},   //request specific permission from user
                                    10);
                        } else {
                            try {
                                context.startActivity(intentDial);  //call activity and make phone call
                            } catch (android.content.ActivityNotFoundException ex) {
                                Toast.makeText(context, "yourActivity is not founded", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                } else
                    Toast.makeText(context, "Please show interest for using direct call button", Toast.LENGTH_SHORT).show();
            }
        });

        holder.share_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BitmapDrawable drawable = (BitmapDrawable) context.getResources().getDrawable(R.drawable.mitra_logo);
                Bitmap bitmap = drawable.getBitmap();
                String bitmapPath = MediaStore.Images.Media.insertImage(context.getContentResolver(), bitmap, "", "");
                Uri uri = Uri.parse(bitmapPath);

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/png");
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.putExtra(Intent.EXTRA_TEXT, "Mitra\n" + jobDataList.getDescription() + "\n" + "https://play.google.com/store/apps/details?id=");
                context.startActivity(Intent.createChooser(intent, "share"));
            }
        });

        holder.report_abuse_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog(jobDataListArrayList.get(position).getId(), session.getUser_Id());
            }
        });
        if (jobDataList.getUser_image() != null && !jobDataList.getUser_image().isEmpty() && !jobDataList.getUser_image().equals("null") && !jobDataList.getUser_image().equals("0")) {

        }
    }

    private void Like_Unlike_Community(String user_id, String id, ImageView like_post, TextView like_counts, JobDataList jobDataList) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + like_unlike_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Like_Unlike_CommunityonResponse:=-=-=-=      " + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONObject DATA = jsonObject.getJSONObject("data");
                        String liked = DATA.getString("liked");
                        String like_count = DATA.getString("like_count");
                        jobDataList.setLiked(liked);
                        if (liked.equalsIgnoreCase("0")) {
                            Log.e(TAG, "---like: " + like);

                            like_post.setImageResource(R.drawable.love);
                            like_counts.setText("" + like_count);
                        } else if (liked.equalsIgnoreCase("1")) {
                            Log.e(TAG, "++++like: " + like);

                            like_post.setImageResource(R.drawable.like_heart_icon);
                            like_counts.setText("" + like_count);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(context, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("community_id", id);

                Log.e(TAG, "getParams:Likes " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    @Override
    public int getItemCount() {
        return jobDataListArrayList.size();
    }

    private void dialog(String community_id, String user_id) {
        Dialog dialogView = new Dialog(context);
        dialogView.setContentView(R.layout.dialog_postoptions);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView report_post, promotional_post, spam_post;

        report_post = dialogView.findViewById(R.id.report_post);
        promotional_post = dialogView.findViewById(R.id.promotional_post);
        spam_post = dialogView.findViewById(R.id.spam_post);

        report_post.setOnClickListener(view -> {
            reportPost(report_post.getText().toString(), community_id, user_id);
            dialogView.dismiss();
        });
        promotional_post.setOnClickListener(view -> {
            reportPost(promotional_post.getText().toString(), community_id, user_id);
            dialogView.dismiss();
        });
        spam_post.setOnClickListener(view -> {
            reportPost(spam_post.getText().toString(), community_id, user_id);
            dialogView.dismiss();
        });
        dialogView.show();
    }

    private void reportPost(String type, String community_id, String user_id) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + report_community_post, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.d(TAG, "reportPost onResponse() called with: response = [" + response + "]");
                    Toast.makeText(context, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
//                    Layout_Progress.setVisibility(GONE);
                    e.printStackTrace();
                }
            }
        }, error -> Log.e(TAG, "reportPost: ", error)) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", user_id);
                map.put("community_id", community_id);
                map.put("report", type);

                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        CardView Image_C;
        ImageView _IMAGE_, LIKE_POST, IMG_COMMENT, IMG_FOR_CALL, SHARE_APP, IMG_SHOW_POST, report_abuse_img;
        TextView _USER_NAME_, REQ_TYPE, _USER_DESC_, TIME_AGO, LIKE_COUNT, LOC__, COMMENT_COUNT__, txttimeago, txtlet;
        ConstraintLayout like_lay, call_lay, share_lay, comment_lay;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            _IMAGE_ = itemView.findViewById(R.id._IMAGE_);
            _USER_NAME_ = itemView.findViewById(R.id._USER_NAME_);
            REQ_TYPE = itemView.findViewById(R.id.REQ_TYPE);
            _USER_DESC_ = itemView.findViewById(R.id.desc_edt);
            txtlet = itemView.findViewById(R.id.txtlet);
            TIME_AGO = itemView.findViewById(R.id.TIME_AGO);
            LIKE_POST = itemView.findViewById(R.id.ic_like);
            LIKE_COUNT = itemView.findViewById(R.id.like_count_tv);
            LOC__ = itemView.findViewById(R.id.LOC__);
            COMMENT_COUNT__ = itemView.findViewById(R.id.comment_count_tv);
            IMG_COMMENT = itemView.findViewById(R.id.ic_comment);
            IMG_FOR_CALL = itemView.findViewById(R.id.ic_call);
            SHARE_APP = itemView.findViewById(R.id.ic_share);
            IMG_SHOW_POST = itemView.findViewById(R.id.IMG_SHOW_POST);
            Image_C = itemView.findViewById(R.id.Image_C);
            txttimeago = itemView.findViewById(R.id.txttimeago);
            report_abuse_img = itemView.findViewById(R.id.report_abuse_img);

            like_lay = itemView.findViewById(R.id.like_lay);
            call_lay = itemView.findViewById(R.id.call_lay);
            comment_lay = itemView.findViewById(R.id.comment_lay);
            share_lay = itemView.findViewById(R.id.share_lay);
        }
    }
}
