package com.social.mitra;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class CitySelection extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_city);



    }
}
