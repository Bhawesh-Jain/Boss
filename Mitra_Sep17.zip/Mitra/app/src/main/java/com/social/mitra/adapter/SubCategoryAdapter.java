package com.social.mitra.adapter;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.interfa.Sub_item_click;
import com.social.mitra.model.SubCategoryModel;
import com.social.mitra.sessionData.Session;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class SubCategoryAdapter extends RecyclerView.Adapter<SubCategoryAdapter.MyViewHolder> {

    Context context;
    ArrayList<SubCategoryModel> subCategoryModels;
    Sub_item_click interface_listner;

boolean isSelectedAll;
    Session session;

    public SubCategoryAdapter(Context context, ArrayList<SubCategoryModel> subCategoryModels, Sub_item_click interface_listner) {
        this.context = context;
        this.subCategoryModels = subCategoryModels;
        this.interface_listner = interface_listner;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.bottom_sheet,
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        if (subCategoryModels.size() > 0) {
            SubCategoryModel subCategoryModel = subCategoryModels.get(position);
            session = new Session(context);
            holder.sub_item_name.setText(subCategoryModel.getSub_cate_name());









            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    holder.bind(subCategoryModel,interface_listner);


                   // if ()
                    if (subCategoryModel.getSub_cate_name().contains("None of the Above")){

                        session.setChecked(subCategoryModel.getSub_cate_id());



                    }else {
                        if (session.getChecked().contains(subCategoryModel.getSub_cate_id())) {
                            if (subCategoryModel.getSub_cate_name().contains("None of the Above")) {
                                session.setChecked(subCategoryModel.getSub_cate_id());


                            }
                            // session.setChecked();
                            holder.check_one_one.setChecked(false);


                        } else {

                            session.setChecked(session.getChecked() + " " + subCategoryModel.getSub_cate_id());
                        }
                    }
                    notifyDataSetChanged();

                }
            });


holder.check_one_one.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Log.e(TAG, "onCheckedChanged: <><<>>><><><><>>>    " );
        interface_listner.SubItemClick(subCategoryModel);


     }
});




        }
    }


    @Override
    public int getItemCount() {
        return subCategoryModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView sub_item_name;
        CheckBox check_one_one;
        LinearLayout layout_check_one;


        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            sub_item_name = itemView.findViewById(R.id.sub_item_name);
            check_one_one = itemView.findViewById(R.id.check_one_one);
            layout_check_one = itemView.findViewById(R.id.layout_check_one);
            check_one_one.setChecked(false);

        }




    }


    public void selectAll(){
        isSelectedAll=true;
        notifyDataSetChanged();
    }
    public void unselectall(){
        isSelectedAll=false;
        notifyDataSetChanged();
    }


}

//            holder.check_one_one.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    int pass = 4;
//                    int passs = 0;
//                    int passs1 = 1;
//                    int passs2 = 2;
//                    int passs3 = 3;
//                    String value = "21";
//                    Integer pos_one = (Integer) holder.check_one_one.getTag();
//
//
//                    Log.e(TAG, "--ID_position: "+subCategoryModel.getSub_cate_id());
//                    Log.e(TAG, "check_box_position: "+pos_one);
//
//
//
//
//                }
//            });


//                holder.check_one_one.setTag(i);
//                holder.bind(subCategoryModel, interface_listner);
//                holder.check_one_one.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                    @Override
//                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                        int tag = (Integer) holder.check_one_one.getTag();
//                        Log.e(TAG, "===tag1: "+tag);
//                        int temp_v = tag;
//                        Log.e(TAG, "===temp_var1: "+temp_v);
//                        int tag_one = (Integer) holder.check_one_one.getTag();
//                        Log.e(TAG, "===tag2: "+tag_one);
//                        int temp_va = tag_one;
//                        Log.e(TAG, "===temp_var2: "+temp_va);
//                        int tag_two = (Integer) holder.check_one_one.getTag();
//                        Log.e(TAG, "===tag3: "+tag_two);
//                        int temp_var = tag_two;
//                        Log.e(TAG, "===temp_var3: "+temp_var);
//                        int tag_theee = (Integer) holder.check_one_one.getTag();
//                        Log.e(TAG, "===tag4: "+tag_theee);
//                        int temp_vari = tag_two;
//                        Log.e(TAG, "===temp_var4: "+temp_vari);
//                        int tag_four = (Integer) holder.check_one_one.getTag();
//                        Log.e(TAG, "===tag5: "+tag_four);
//                        int temp_varia = tag_two;
//                        Log.e(TAG, "===temp_var5: "+temp_varia);
//
//
//                });
//            }
//
//


//        holder.layout_house_stages.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//
//                            holder.layout_house_stages.setBackgroundResource(R.drawable.list_border);
//                            holder.layout_image_icon.setBackgroundResource(R.drawable.list_border);
//                            final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(context);
//                            View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.bottom_sheet, null);
//                            mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//
//
//                            mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//                            mBottomSheetDialog.setContentView(sheetView);
//
//                            CheckBox check_one_one, check_two_two, check_three_three, check_four_four, check_five_five;
//                            RecyclerView recycler_sub_category;
//                            check_one_one = mBottomSheetDialog.findViewById(R.id.check_one_one);
//                            recycler_sub_category = mBottomSheetDialog.findViewById(R.id.recycler_sub_category);
//                            check_two_two = mBottomSheetDialog.findViewById(R.id.check_two_two);
//                            check_three_three = mBottomSheetDialog.findViewById(R.id.check_three_three);
//                            check_four_four = mBottomSheetDialog.findViewById(R.id.check_four_four);
//                            check_five_five = mBottomSheetDialog.findViewById(R.id.check_five_five);
//
//
//                            CardView nextt_button = mBottomSheetDialog.findViewById(R.id.nextt_button);
//
//                            check_one_one.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//
//                                        }
//                                    });
//                                }
//                            });
//                            check_two_two.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//                                        }
//                                    });
//                                }
//                            });
//
//                            check_three_three.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//                                        }
//                                    });
//                                }
//                            });
//                            check_four_four.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//                                        }
//                                    });
//                                }
//                            });
//
//                            check_five_five.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    check_one_one.setChecked(false);
//                                    check_two_two.setChecked(false);
//                                    check_three_three.setChecked(false);
//                                    check_four_four.setChecked(false);
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
////                                finish();
//                                        }
//                                    });
//                                }
//                            });
//
//                            mBottomSheetDialog.show();
//
//                        }
//
//
//                });
//        notifyDataSetChanged();