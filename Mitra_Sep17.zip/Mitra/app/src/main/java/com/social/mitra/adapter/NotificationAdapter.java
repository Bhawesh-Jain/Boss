package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.model.NotificationModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.MyViewHolder> {

    Context context;
    ArrayList<NotificationModel> notificationModels;

    public NotificationAdapter(Context context, ArrayList<NotificationModel> notificationModels) {
        this.context = context;
        this.notificationModels = notificationModels;
    }

    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.notification_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull NotificationAdapter.MyViewHolder holder, int position) {
        NotificationModel currentModel = notificationModels.get(position);

        holder.user_msg.setText(currentModel.getMsg());
        Glide.with(context).load(currentModel.getPath() + currentModel.getSender_image()).into(holder.user_img).onLoadFailed(context.getResources().getDrawable(R.drawable.person_user));
    }

    @Override
    public int getItemCount() {
        return notificationModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        CircleImageView user_img;
        TextView user_msg;

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            user_msg = itemView.findViewById(R.id.user_msg);
            user_img = itemView.findViewById(R.id.user_img);
        }
    }
}
