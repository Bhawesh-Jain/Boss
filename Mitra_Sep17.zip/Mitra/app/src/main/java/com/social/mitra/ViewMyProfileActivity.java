package com.social.mitra;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

public class ViewMyProfileActivity extends AppCompatActivity {
    TextView tvR, tvPython, tvCPP ;
    PieChart pieChart;
    ProgressBar pb, pb2;
    TextView AG_viewprofile;
    ImageView AG_back;
    int counter = 0;
    Spinner spinner4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_profile);

        AG_viewprofile=findViewById(R.id.AG_viewprofile);

        AG_back = findViewById(R.id.AG_back);

        spinner4 = findViewById(R.id.spinner4);

        tvR = findViewById(R.id.tvR);
        tvPython = findViewById(R.id.tvPython);
        tvCPP = findViewById(R.id.tvCPP);

        pieChart = findViewById(R.id.piechart);
        setData();
        pb = findViewById(R.id.pb);
        pb2 = findViewById(R.id.pb2);
        pb.setProgress(80);
        pb2.setProgress(30);


        Spinner mySpinner =  (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(ViewMyProfileActivity.this, android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.backup));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);



        AG_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });



    }






    private void setData()
    {

        // Set the percentage of language used
        tvR.setText(Integer.toString(30));
        tvPython.setText(Integer.toString(20));
        tvCPP.setText(Integer.toString(50));



        // Set the data and color to the pie chart

        pieChart.addPieSlice(
                new PieModel(
                        "R",
                        Integer.parseInt(tvR.getText().toString()),
                        Color.parseColor("#FFA726")));
        pieChart.addPieSlice(
                new PieModel(
                        "Python",
                        Integer.parseInt(tvPython.getText().toString()),
                        Color.parseColor("#66BB6A")));
        pieChart.addPieSlice(
                new PieModel(
                        "C++",
                        Integer.parseInt(tvCPP.getText().toString()),
                        Color.parseColor("#EF5350")));


        // To animate the pie

        pieChart.startAnimation();

    }

/*

        public void prog()
        {
            pb = findViewById(R.id.pb);
            final Timer t = new Timer();
            TimerTask tt = new TimerTask() {
                @Override
                public void run() {
                    counter ++ ;
                    pb.setProgress(80);


                }
            };
            t.schedule(tt,
                    0,
                    100);
        }

*/




}