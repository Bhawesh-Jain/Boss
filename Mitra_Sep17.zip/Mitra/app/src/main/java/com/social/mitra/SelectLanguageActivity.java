package com.social.mitra;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
        import android.os.Bundle;
        import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.social.mitra.sessionData.Session;

public class SelectLanguageActivity extends AppCompatActivity {
    TextView messageView;
    LinearLayout btnHindi, btnEnglish;
    Context context;
    Resources resources;
    LinearLayout langlinear;
    TextView lang_continue;
    String isSelect = "";
    Session session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_language);
        session = new Session(this);

        context= getApplicationContext();
        // referencing the text and button views
        messageView = (TextView) findViewById(R.id.textView);
        btnHindi = findViewById(R.id.btnHindi);
        btnEnglish = findViewById(R.id.btnEnglish);

       /* langlinear = findViewById(R.id.langlinear);*/

        lang_continue = findViewById(R.id.lang_continue);

        lang_continue.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (isSelect.equalsIgnoreCase("")) {

                    Toast.makeText(SelectLanguageActivity.this, "Please select your language", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(SelectLanguageActivity.this, ActivityLogin.class);
                    startActivity(intent);

                }
            }
        });

        // setting up on click listener event over the button
        // in order to change the language with the help of


        // LocaleHelper class
        btnEnglish.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                session.setValue(Session.language, Session.english);
                context = LocaleHelper.setLocale(SelectLanguageActivity.this, "en");
                resources = context.getResources();
                btnEnglish.setBackgroundResource(R.drawable.background_selectonlang);
                btnHindi.setBackgroundResource(R.drawable.hindibackground);
                isSelect = "Hindi";


            }
        });

        btnHindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                session.setValue(Session.language, Session.hindi);
                context = LocaleHelper.setLocale(SelectLanguageActivity.this, "hi");
                resources = context.getResources();
                //messageView.setText("language");
                btnHindi.setBackgroundResource(R.drawable.background_selectonlang);
                btnEnglish.setBackgroundResource(R.drawable.engbackground);
                isSelect = "English";
            }
        });

    }
}