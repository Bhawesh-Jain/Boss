package com.social.mitra.activity;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.IMAGE_URL;
import static com.social.mitra.util.BaseUrl.get_cities;
import static com.social.mitra.util.BaseUrl.get_profile;
import static com.social.mitra.util.BaseUrl.update_profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.adapter.SelectCompanyTypeAdapter;
import com.social.mitra.model.CityList;
import com.social.mitra.model.CompanyTypeModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;
import com.social.mitra.util.VolleySingleton;
import com.vansuita.pickimage.bean.PickResult;
import com.vansuita.pickimage.bundle.PickSetup;
import com.vansuita.pickimage.dialog.PickImageDialog;
import com.vansuita.pickimage.listeners.IPickCancel;
import com.vansuita.pickimage.listeners.IPickResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class EditProfileActivity extends AppCompatActivity {

    public static final int RESULT_GALLERY = 0;
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    ImageView back_img, User_edit_PROFILE;
    TextView type_company_tv, position_tv, icon_location;
    File imgFile;
    LinearLayout ll_business;
    CheckBox chknoshow;
    String city_name;
    Spinner update_prof_spinnner, position_spinner, company_type_spinner;
    CircleImageView select_image, edit_profile_image;
    String[] profession_type = {"Select Profession", "Exporter", "Supplier", "Importer", "Buyer", "Broker", "International Buying Agent", "Logistics", "CHA", "ShippingAgent",
            "ShippingLines", "Warehouse", "Cold Storage", "Inspection", "Insurance", "Investor", "Entrepreneur", "Start Up", "Co Founder", "Executive", "Other"};
    TextView EXPERIENCE_FIELD, txtjobtype;
    String profession = "";
    EditText EDIT_FULL_NAME, company_edt, EMAIL_EDIT, BIO_EDIT;
    TextView MOBILE_EDIT;
    String[] position_type = {"1 years", "2 years", "3 years", "4 years", "5+ years", "10+ years", "10+ years"};
    String[] company_type = {"Type Of Company", "Exporter", "Supplier", "Importer", "Buyer", "Broker", "International Buying Agent", "Logistics", "CHA", "ShippingAgent",
            "ShippingLines", "Warehouse", "Cold Storage", "Inspection", "Insurance", "Investor", "Manufacturer", "Producer", "Farmer", "Trader", "Freight Forwarder", "Financier", "Other"};
    ArrayAdapter<String> professionArrayAdapter;
    ArrayAdapter<String> positionArrayAdapter;
    ArrayAdapter<String> companyArrayAdapter;
    Session session;
    String position_selected = "Position";
    String company_type_selected = "Type Of Company";
    String City_name = "", no_on_profile = "";
    EditText user_name_, user_email_, user_mobile_, user_bio_, edtaditionlnumbr;
    RecyclerView select_company_type;
    ArrayList<CompanyTypeModel> companyTypeModels = new ArrayList<>();
    SelectCompanyTypeAdapter selectCompanyTypeAdapter;
    CardView btn_Edit_Profile;
    String user_id;
    File IMAGE_EDIT = null;
    String Cate_id = "";
    String Sub_Cate_id = "";
    SessionLogOut sessionLogOut;
    String PreMobile;
    Spinner spincity;

    ArrayList<CityList> cityLists = new ArrayList<>();
    ArrayAdapter<String> spinnermnthArrayAdapter;
    ArrayList<String> monthlist = new ArrayList<>();
    private String city_name1 = "";


    public static File bitmapToFile(Context mContext, Bitmap bitmap) {
        try {
            String name = System.currentTimeMillis() + ".png";
            File file = new File(mContext.getCacheDir(), name);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 60, bos);
            byte[] bArr = bos.toByteArray();
            bos.flush();
            bos.close();

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        back_img = findViewById(R.id.back_img);
        spincity = findViewById(R.id.spincity);
        chknoshow = findViewById(R.id.chknoshow);

        ll_business = findViewById(R.id.ll_business);
        select_image = findViewById(R.id.select_image);
        User_edit_PROFILE = findViewById(R.id.User_edit_PROFILE);
        position_spinner = findViewById(R.id.position_spinner);
        update_prof_spinnner = findViewById(R.id.update_prof_spinnner);
        BIO_EDIT = findViewById(R.id.BIO_EDIT);
        company_edt = findViewById(R.id.company_edt);
        EDIT_FULL_NAME = findViewById(R.id.EDIT_FULL_NAME);
        edtaditionlnumbr = findViewById(R.id.edtaditionlnumbr);

        EMAIL_EDIT = findViewById(R.id.EMAIL_EDIT);
        MOBILE_EDIT = findViewById(R.id.MOBILE_EDIT);
        icon_location = findViewById(R.id.icon_location);
        btn_Edit_Profile = findViewById(R.id.btn_Edit_Profile);
        EXPERIENCE_FIELD = findViewById(R.id.EXPERIENCE_FIELD);
        txtjobtype = findViewById(R.id.txtjobtype);

        session = new Session(this);
        sessionLogOut = new SessionLogOut(this);

        user_id = session.getUser_Id();

        Sub_Cate_id = session.getSubcate_Id();
        Log.e(TAG, "--Cate_id_onCreate: " + Cate_id);
        Log.e(TAG, "--Sub_Cate_id_onCreate: " + Sub_Cate_id);

        professionArrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, profession_type);
        update_prof_spinnner.setAdapter(professionArrayAdapter);

        positionArrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, position_type);
        position_spinner.setAdapter(positionArrayAdapter);

        companyArrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, company_type);

        chknoshow.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    no_on_profile = "1";
                }
            }
        });
        Get_Profile(0);
        get_cities();

        spincity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                City_name = spincity.getSelectedItem().toString();
                City_name = cityLists.get(position).getCityID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        select_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             /*
                AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(
                        EditProfileActivity.this);
                myAlertDialog.setTitle("Upload Pictures Option");
                myAlertDialog.setMessage("How do you want to set your picture?");

                myAlertDialog.setPositiveButton("Camera",
                        new DialogInterface.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.M)
                            public void onClick(DialogInterface arg0, int arg1) {
                                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                    requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                                } else {
                                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                                    startActivityForResult(cameraIntent, CAMERA_REQUEST);

                                }
                            }
                        });

                myAlertDialog.setNegativeButton("Gallery",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface arg0, int arg1) {

                                Intent galleryIntent = new Intent(
                                        Intent.ACTION_PICK,
                                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                startActivityForResult(galleryIntent, RESULT_GALLERY);

                            }
                        });
                myAlertDialog.show();*/

                final PickImageDialog dialog = PickImageDialog.build(new PickSetup());
                dialog.setOnPickCancel(new IPickCancel() {
                    @Override
                    public void onCancelClick() {
                        dialog.dismiss();
                    }
                }).setOnPickResult(new IPickResult() {
                    @Override
                    public void onPickResult(PickResult r) {
                        if (r.getError() == null) {
                            User_edit_PROFILE.setImageBitmap(r.getBitmap());
                            Log.e("Imagepath", r.getPath());
                            IMAGE_EDIT = bitmapToFile(EditProfileActivity.this, r.getBitmap());
                            Log.e("imgFile", "" + IMAGE_EDIT);
                            String filename = IMAGE_EDIT.getName();
                            Log.e("filweName = ", filename);

                            updateProfileImage();
                        } else {
                            //TODO: do what you have to do with r.getError();
                            Toast.makeText(EditProfileActivity.this, r.getError().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                }).show(EditProfileActivity.this);

            }
        });


        update_prof_spinnner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                profession = profession_type[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        btn_Edit_Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Update_Profile(user_id);

               /* if (EDIT_FULL_NAME.getText().toString().equals("")) {
                    EDIT_FULL_NAME.setFocusable(true);
                    EDIT_FULL_NAME.setError("Enter Your Full Name");
                } else if (EMAIL_EDIT.getText().toString().equals("")) {
                    EMAIL_EDIT.setFocusable(true);
                    EMAIL_EDIT.setError("Enter Your Email");
                } else if (BIO_EDIT.getText().toString().equals("")) {
                    BIO_EDIT.setFocusable(true);
                    BIO_EDIT.setError("Enter Your Email");
                } else {
                    Update_Profile(user_id);
                }*/
            }
        });
    }

    private void Update_Profile(String user_id) {

        Log.e("TAG", "Update_profile: ");

        ProgressDialog progressDialog = new ProgressDialog(this);

        String FULL_NAME = EDIT_FULL_NAME.getText().toString();

        String Email_Edit = EMAIL_EDIT.getText().toString();
        String Bio_Edit = BIO_EDIT.getText().toString();
        Log.e(TAG, "Update_Profile: Bio_Edit ><>" + Bio_Edit);
        Log.e(TAG, "Update_Profile: user_id ><>" + user_id);
        Log.e(TAG, "Update_Profile: FULL_NAME ><>" + FULL_NAME);
        Log.e(TAG, "Update_Profile: Cate_id ><>" + Cate_id);
        Log.e(TAG, "Update_Profile: Sub_Cate_id ><>" + Sub_Cate_id);
        Log.e(TAG, "Update_Profile: Bio_Edit ><>" + Bio_Edit);
        Log.e(TAG, "Update_Profile: City_name ><>" + City_name);
        Log.e(TAG, "Update_Profile: Email_Edit ><>" + Email_Edit);

        AndroidNetworking.upload(Base_Url + update_profile)
                .addMultipartParameter("user_id", user_id)
                .addMultipartParameter("name", FULL_NAME)
                .addMultipartParameter("fname", FULL_NAME)
                .addMultipartParameter("about", Bio_Edit)
                .addMultipartParameter("city_id", City_name)
                .addMultipartParameter("email", Email_Edit)
                .addMultipartParameter("company", company_edt.getText().toString())
                .addMultipartParameter("additional_mobile", edtaditionlnumbr.getText().toString())
                .addMultipartParameter("no_on_profile", no_on_profile)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("---rrrProfile", "UpdateProfileActivityuAPIresponse" + jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);
                            progressDialog.dismiss();
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");
                            if (result.equalsIgnoreCase("true")) {
                                Log.e(TAG, "---Intent_onResponse: ");

                                Intent intent = new Intent(EditProfileActivity.this, HomeActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(EditProfileActivity.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        progressDialog.dismiss();

                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void updateProfileImage() {
        Log.e(TAG, "updateProfileimage:user_id  " + session.getUser_Id());
        Log.e(TAG, "updateProfileimage:image    " + IMAGE_EDIT);

        AndroidNetworking.upload(Base_Url + update_profile)
                .addMultipartParameter("user_id", session.getUser_Id())

                .addMultipartFile("image", IMAGE_EDIT)
                //.setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        Log.e(TAG, "image  onResponse: " + jsonObject.toString());
                        try {
                            // JSONObject obj = new JSONObject(response);
                            String result = jsonObject.getString("result");
                            if (result.equalsIgnoreCase("true")) {
                                Toast.makeText(EditProfileActivity.this, "Update successfully", Toast.LENGTH_SHORT).show();
                                JSONObject jsonObject1 = jsonObject.getJSONObject("data");

                                String id = jsonObject1.getString("id");
                                String name = jsonObject1.getString("name");
                                String mobile = jsonObject1.getString("mobile");
                                String email = jsonObject1.getString("email");
                                String address = jsonObject1.getString("address");
                                String image = jsonObject1.getString("image");

                                Get_Profile(1);


                                Intent intent = new Intent(EditProfileActivity.this, HomeActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(EditProfileActivity.this, "Fail, please try again", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                    }
                });
    }

    private void Get_Profile(int i) {
        ProgressDialog progressDialog = new ProgressDialog(EditProfileActivity.this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, "onResponse:  Get_Profile     " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {


                        JSONObject data = jsonObject.getJSONObject("data");
                        if (i == 1) {
                            Glide.with(EditProfileActivity.this).load(IMAGE_URL + data.getString("image")).placeholder(R.drawable.user)
                                    .into(User_edit_PROFILE);
                        } else {
                            String User_id = data.getString("id");
                            String name__ = data.getString("name");
                            String First_name = data.getString("fname");
                            String Last_name = data.getString("lname");
                            String Mobile_ = data.getString("mobile");
                            String additional_mobile = data.getString("additional_mobile");
                            String TYPE = data.getString("type");
                            String company = data.getString("company");
                            String IMAGGE = data.getString("image");
                            String email = data.getString("email");
                            String category_name = data.getString("category_name");
                            String exp = data.getString("experience");
                            String about = data.getString("bio");
                            city_name1 = data.getString("city_name");
                            city_name = data.getString("location");


                            Log.e(TAG, "city_name: " + city_name);
                            Log.e(TAG, "First_name: " + First_name);
                            Log.e(TAG, "Last_name: " + Last_name);
                            Log.e(TAG, "Mobile_: " + Mobile_);
                            Log.e(TAG, "TYPE: " + TYPE);
                            Log.e(TAG, "IMAGGE: " + IMAGGE);

                            BIO_EDIT.setText(about);


                            Log.e(TAG, "onResponse: " + IMAGE_URL + IMAGGE);
                            EXPERIENCE_FIELD.setText(exp);
                            try {
                                if (spinnermnthArrayAdapter != null && !city_name1.equalsIgnoreCase("")) {
                                    int spinnerPosition = spinnermnthArrayAdapter.getPosition(city_name1);
                                    spincity.setSelection(spinnerPosition);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            if (!company.equalsIgnoreCase(""))
                                company_edt.setText(company);

                            if (First_name != null && !First_name.isEmpty() && !First_name.equals("null") && !First_name.equals("0")) {
                                EDIT_FULL_NAME.setText("" + First_name + " " + Last_name);

                            } else {
                                EDIT_FULL_NAME.setText(name__);
                            }
                            MOBILE_EDIT.setText("" + Mobile_);

                            edtaditionlnumbr.setText(additional_mobile);

                            if (TYPE.equalsIgnoreCase("home_owner")) {
                                ll_business.setVisibility(View.GONE);
                                EXPERIENCE_FIELD.setVisibility(View.GONE);
                            }

                            Glide.with(EditProfileActivity.this).load(IMAGE_URL + IMAGGE).placeholder(R.drawable.user)
                                    .into(User_edit_PROFILE);

                            EMAIL_EDIT.setText(email);
                            txtjobtype.setText(category_name);


                            if (TYPE.equalsIgnoreCase("home_owner")) {
                                BIO_EDIT.setHint("I am a Proud Home Owner");
                            } else {
                                BIO_EDIT.setHint("About your Profession");
                            }
                        }
                    } else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", session.getUser_Id());
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "--getParams:ProfileFragment " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void get_cities() {
        cityLists.clear();
        monthlist.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse:get_months---    " + response);
                        try {
                            JSONObject obj = new JSONObject(response);

                            String result = obj.getString("result");
                            if (result.equalsIgnoreCase("true")) {
                                monthlist.add("Select city");

                                JSONArray jsonArray = obj.getJSONArray("data");

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                                    String plan_id = jsonObject1.getString("id");
                                    String special = jsonObject1.getString("name");

                                    CityList allCommunityModel = new CityList(plan_id, special);
                                    monthlist.add(special);
                                    cityLists.add(allCommunityModel);
                                }
                                cityLists.add(0, new CityList("", "Select city"));

                                spinnermnthArrayAdapter = new ArrayAdapter<>
                                        (EditProfileActivity.this, android.R.layout.simple_spinner_item, monthlist); //selected item will look like a spinner set from XML
                                spinnermnthArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                spincity.setAdapter(spinnermnthArrayAdapter);
                                if (!city_name1.equalsIgnoreCase("")) {
                                    int spinnerPosition = spinnermnthArrayAdapter.getPosition(city_name1);
                                    spincity.setSelection(spinnerPosition);
                                }
                                Log.e(TAG, "onResponse:city_name <><<>><>><><     " + city_name);
//                                if (city_name != null) {
//                                    int spinnerPosition = spinnermnthArrayAdapter.getPosition(city_name);
//                                    spincity.setSelection(spinnerPosition);
//                                }
                            }  // Toast.makeText(AddcartActivity.this, "No item available", Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}