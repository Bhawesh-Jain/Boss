package com.social.mitra.model;

public class ProfessionalNameList {

    String Profession_image,Profession_name,Profession_Id;

    public ProfessionalNameList(String profession_image, String profession_name, String profession_Id) {
        Profession_image = profession_image;
        Profession_name = profession_name;
        Profession_Id = profession_Id;
    }

    public String getProfession_image() {
        return Profession_image;
    }

    public void setProfession_image(String profession_image) {
        Profession_image = profession_image;
    }

    public String getProfession_name() {
        return Profession_name;
    }

    public void setProfession_name(String profession_name) {
        Profession_name = profession_name;
    }

    public String getProfession_Id() {
        return Profession_Id;
    }

    public void setProfession_Id(String profession_Id) {
        Profession_Id = profession_Id;
    }
}
