package com.social.mitra.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.social.mitra.R;
import com.social.mitra.sessionData.Session;


public class ContactUsActivity extends AppCompatActivity {

    ImageView back_img;
    EditText your_title_edt,your_discription_edt;
    Button submit_contact_us;
    Session session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactus);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        back_img = findViewById(R.id.back_img);
        your_title_edt = findViewById(R.id.your_title_edt);
        your_discription_edt = findViewById(R.id.your_discription_edt);
        submit_contact_us = findViewById(R.id.submit_contact_us);

        session = new Session(this);
        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        submit_contact_us.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(your_title_edt.getText().toString().equals(""))
                {
                    your_title_edt.setError("Enter Title");
                    your_title_edt.setFocusable(true);
                }else {

                    if(your_discription_edt.getText().toString().equals(""))
                    {
                        your_discription_edt.setError("Enter Discription");
                        your_discription_edt.setFocusable(true);
                    }else {

                     /*   Intent intent =new Intent(ContactUsActivity.this, HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);

                        finish();*/
//                        postContactUs();
                    }
                }
            }
        });

    }

//    private void postContactUs(){
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url+Contact_us, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if(jsonObject.getString("result").equals("true")){
//
//
//                        progressDialog.dismiss();
//                        Toast.makeText(ContactUsActivity.this, "Send Detail Successfully", Toast.LENGTH_SHORT).show();
//
//                        Intent intent =new Intent(ContactUsActivity.this, HomeActivity.class);
//                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                        startActivity(intent);
//
//                        finish();
//
//
//                    }else {
//                        progressDialog.dismiss();
//                        Toast.makeText(ContactUsActivity.this, ""+jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//                    }
//                } catch (JSONException e) {
//                    progressDialog.dismiss();
//                    Toast.makeText(ContactUsActivity.this, ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                progressDialog.dismiss();
//                Toast.makeText(ContactUsActivity.this, ""+error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }){
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String,String > map = new HashMap<>();
//                map.put("user_id",session.getUser_Id());
//                map.put("title",your_title_edt.getText().toString());
//                map.put("description",your_discription_edt.getText().toString());
//                return map;
//
//            }
//        };
//
//        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
//
//    }


}