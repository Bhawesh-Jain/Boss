package com.social.mitra;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.add_community;
import static com.social.mitra.util.BaseUrl.get_main_category;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.social.mitra.adapter.PopupListAdapter;
import com.social.mitra.interfa.On_Click;
import com.social.mitra.interfa.On_catname_Click;
import com.social.mitra.model.ProfessionalNameList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivityNewPost extends AppCompatActivity implements On_Click, On_catname_Click {
    private static final int CAMERA_REQUEST = 1;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    private static final int CAMERA_REQUEST_FOR_VISITING_CARD = 2;
    private final String TAG = "NEw Post";
    ImageView back_img, selected_image;
    CardView card_view;
    RelativeLayout select_image;
    TextView requirement_btn, Discussion_btn, title;
    TextView Post_BUTTON_;
    EditText add_title_edt, add_title_edt_diss;
    File imgFile = null;
    File videofile = null;
    Uri fileUri;
    String video_path = "";
    Session session;
    LinearLayout middle_linear_layout, linear_onee, linear_discussion;
    ImageView back_from_post;
    String USER_ID;
    CardView Card_press_for_photo, card_required;
    ImageView IMG_FOR_POST, IMAGE_REQ;
    String Cate_name = "";
    File ImageREQFile = null, IMAGE_DISFile = null;
    String PType = "requirement";
    LinearLayout llcat;
    RelativeLayout FloatinGJob_List_Progress;
    ArrayList<ProfessionalNameList> professionalNameListArrayList = new ArrayList<>();
    ArrayList<String> ProcATE = new ArrayList<>();
    String ItemDesc = "";
    TextView txt_;

    public static File bitmapToFile(Context mContext, Bitmap bitmap) {
        try {
            String name = System.currentTimeMillis() + ".png";
            File file = new File(mContext.getCacheDir(), name);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 60, bos);
            byte[] bArr = bos.toByteArray();
            bos.flush();
            bos.close();

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_post);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);


        session = new com.social.mitra.sessionData.Session(this);
        back_img = findViewById(R.id.back_img);
        select_image = findViewById(R.id.select_image);
        selected_image = findViewById(R.id.selected_image);
        card_view = findViewById(R.id.card_view);
        FloatinGJob_List_Progress = findViewById(R.id.FloatinGJob_List_Progress);
        title = findViewById(R.id.title);
        add_title_edt = findViewById(R.id.add_title_edt);
        linear_onee = findViewById(R.id.linear_onee);
        IMG_FOR_POST = findViewById(R.id.IMG_FOR_POST);
        Card_press_for_photo = findViewById(R.id.Card_press_for_photo);
//        spinner_pro_cate = findViewById(R.id.spinner_pro_cate);
        Post_BUTTON_ = findViewById(R.id.Post_BUTTON_);
        Discussion_btn = findViewById(R.id.Discussion_btn);
        card_required = findViewById(R.id.card_required);
        IMAGE_REQ = findViewById(R.id.IMAGE_REQ);
        add_title_edt_diss = findViewById(R.id.add_title_edt_diss);
        llcat = findViewById(R.id.llcat);
        txt_ = findViewById(R.id.txt_);


        requirement_btn = findViewById(R.id.requirement_btn);
        back_from_post = findViewById(R.id.back_from_post);

        linear_discussion = findViewById(R.id.linear_discussion);

//        linear_onee.setVisibility(GONE);
        linear_discussion.setVisibility(GONE);


        USER_ID = session.getUser_Id();

        linear_onee.setVisibility(VISIBLE);
//        share_btn_req.setVisibility(VISIBLE);

        Log.e(TAG, "USER_ID: " + USER_ID);


        back_from_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        llcat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dilog();
            }
        });

        _Get_Main_Category(USER_ID);


        add_title_edt_diss.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                checkBtnStatus();
            }
        });

        add_title_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                checkBtnStatus();
            }
        });

/*
        spinner_pro_cate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Cate_name = professionalNameListArrayList.get(i).getProfession_Id();
                Log.e(ContentValues.TAG, "===Cate_name__onItemSelected: " + Cate_name);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
*/

//        mySpinner.setVisibility(GONE);card_required

        Card_press_for_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(ActivityNewPost.this)
                        .crop()
                        .compress(200)            //Final image size will be less than 1 MB(Optional)
                        .start(2);
            }
        });

        card_required.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(ActivityNewPost.this)
                        .crop()
                        .compress(200)            //Final image size will be less than 1 MB(Optional)
                        .start(1);
            }
        });


        requirement_btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                PType = "requirement";
                txt_.setVisibility(VISIBLE);
                checkBtnStatus();
                title.setText("Post Your Work Requirement");
                requirement_btn.setBackgroundResource(R.drawable.yellow_backgroud);
                Discussion_btn.setBackgroundResource(R.drawable.borderrr);
                llcat.setVisibility(VISIBLE);
                linear_onee.setVisibility(VISIBLE);
                linear_discussion.setVisibility(GONE);
            }
        });

        Discussion_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PType = "discussion";
                txt_.setVisibility(GONE);
                checkBtnStatus();
                linear_onee.setVisibility(GONE);
                title.setText("Ask your queries from Community");
                Discussion_btn.setBackgroundResource(R.drawable.yellow_backgroud);
                requirement_btn.setBackgroundResource(R.drawable.borderrr);
                linear_discussion.setVisibility(VISIBLE);

                llcat.setVisibility(GONE);


            }
        });


        Post_BUTTON_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.e(TAG, "share_btn_req: " + PType);
                ItemDesc = add_title_edt.getText().toString();
                if (PType.equalsIgnoreCase("requirement")) {
                    if (isValidReq()) {
                        Add_Community_req(USER_ID, PType, Cate_name, ImageREQFile);
                    }

                } else {
                    ItemDesc = add_title_edt_diss.getText().toString();
                    if (!ItemDesc.equalsIgnoreCase(""))
                        Add_Community_disc(USER_ID, PType, IMAGE_DISFile);
                    else add_title_edt_diss.setError("Please write something");
                }
            }
        });

        ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {

                            // There are no request codes
                            Intent data = result.getData();
                            fileUri = data.getData();

//                            video_path = getPath(fileUri);

                            videofile = new File(video_path);

                            Log.e(TAG, "onActivityResult: " + videofile.getPath());

                            imgFile = null;

                            MediaPlayer mp = MediaPlayer.create(ActivityNewPost.this, Uri.parse(String.valueOf(fileUri)));

                            int duration = mp.getDuration() / 1000;
                            mp.release();
                            if (duration <= 15) {
                                card_view.setVisibility(VISIBLE);
                                Glide.with(ActivityNewPost.this)
                                        .load(fileUri.toString())
                                        .centerCrop()
                                        .placeholder(R.drawable.mygallery)
//                                    .crossFade()
                                        .into(selected_image);
                            } else {
                                Toast.makeText(ActivityNewPost.this, "Please Select Vidoe Duration 15 Second Only", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });


    }

    private void checkBtnStatus() {
        if (PType.equalsIgnoreCase("requirement")) {
            if (!Cate_name.equalsIgnoreCase("") && !add_title_edt.getText().toString().equalsIgnoreCase(""))
                Post_BUTTON_.setBackgroundResource(R.drawable.btn_accept_blue_bg);
            else
                Post_BUTTON_.setBackgroundResource(R.drawable.btn_whitebackground);
        } else if (PType.equalsIgnoreCase("discussion")) {
            if (!add_title_edt_diss.getText().toString().equalsIgnoreCase(""))
                Post_BUTTON_.setBackgroundResource(R.drawable.btn_accept_blue_bg);
            else
                Post_BUTTON_.setBackgroundResource(R.drawable.btn_whitebackground);
        } else
            Post_BUTTON_.setBackgroundResource(R.drawable.btn_whitebackground);
    }

    private boolean isValidReq() {
        if (Cate_name.equalsIgnoreCase("")) {
            Toast.makeText(ActivityNewPost.this, "Select professional you are looking for", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (ItemDesc.equalsIgnoreCase("")) {
            add_title_edt.setError("Please write something");
            return false;
        }
        return true;
    }

    private void Add_Community_disc(String user_id, String pType, File image_disFile) {
        Log.e(TAG, "+++++_ADd_Community: ");
        Log.e(ContentValues.TAG, "++++Method_USER_IDDD:  " + session.getUser_Id());
        Log.e(ContentValues.TAG, "----ADd_Community: " + pType);

        Log.e(ContentValues.TAG, "===Profile_Image: " + image_disFile);

        ProgressDialog progressDialog = new ProgressDialog(this);

        Log.e(ContentValues.TAG, "===ItemDesc: " + ItemDesc);

        progressDialog.show();

        AndroidNetworking.upload(Base_Url + add_community)
                .addMultipartParameter("user_id", user_id)
                .addMultipartParameter("description", ItemDesc)
                .addMultipartParameter("type", pType)
                .addMultipartFile("image", image_disFile)

//                .addMultipartParameter("visiting_card_image", Image_visiting_card)
//                .addMultipartParameter("govt_id_image", Image_visiting_card)

                //.setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        progressDialog.dismiss();
                        try {
                            Log.d("NewPost", "Requirement Discussion--->" + jsonObject.toString());
                            progressDialog.dismiss();
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");
                            if (result.equalsIgnoreCase("true")) {
                                Log.e(ContentValues.TAG, "===Intent_profile: ");
                                session.setValue("firstTime", "false");
                                finish();
                            } else {
                                Toast.makeText(ActivityNewPost.this, msg, Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onError(ANError anError) {
                        progressDialog.dismiss();
                    }
                });

    }

    private void Add_Community_req(String user_id, String PType, String cate_name, File ImageREQFile) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        AndroidNetworking.upload(Base_Url + add_community)
                .addMultipartParameter("user_id", user_id)
                .addMultipartParameter("description", ItemDesc)
                .addMultipartParameter("type", PType)
                .addMultipartParameter("category_id", cate_name)
                .addMultipartFile("image", ImageREQFile)
                .addMultipartParameter("phone", "yes")
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        progressDialog.dismiss();
                        try {
                            Log.e("NewPost", "Requirement Response--->" + jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);
//                            FloatinGJob_List_Progress.setVisibility(GONE);
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");
                            if (result.equalsIgnoreCase("true")) {

                                Log.e(ContentValues.TAG, "===Intent_profile: ");
//                                Intent intent = new Intent(ActivityNewPost.this, HomeActivity.class);
//                                intent.putExtra("NewPost", "true");
//                                startActivity(intent);
                                session.setValue("firstTime", "false");
                                finish();
                                /*FragmentManager fragmentManager = getSupportFragmentManager();
                                final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

                                fragmentTransaction.add(R.id.layOut_fragment_jobList, new ListJobFragment()).commit();
*/


                            } else {
//                                FloatinGJob_List_Progress.setVisibility(GONE);
                                Toast.makeText(ActivityNewPost.this, msg, Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
//                            FloatinGJob_List_Progress.setVisibility(GONE);
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
//                        FloatinGJob_List_Progress.setVisibility(GONE);
                        progressDialog.dismiss();


                    }
                });
    }

    private void _Get_Main_Category(String USER_ID) {
        Log.e(TAG, "***_Get_Main_Category: ");

        professionalNameListArrayList.clear();

        FloatinGJob_List_Progress.setVisibility(VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_main_category, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "_Get_Main_CategoryonResponse:response " + response);
                    FloatinGJob_List_Progress.setVisibility(GONE);


                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        professionalNameListArrayList.clear();


                        JSONArray state = jsonObject.getJSONArray("data");


                        for (int i = 0; i < state.length(); i++) {

                            JSONObject country_data = state.getJSONObject(i);

                            String Cate_id = country_data.getString("id");
                            String Cate_img = country_data.getString("name");

                            ProfessionalNameList professionalNameList = new ProfessionalNameList(Cate_id, Cate_img, Cate_id);

                            professionalNameListArrayList.add(professionalNameList);

                            ProcATE.add(Cate_name);


                        }

                     /*   ArrayAdapter ad1 = new ArrayAdapter(ActivityNewPost.this, simple_spinner_item, ProcATE);
                        ad1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner_pro_cate.setAdapter(ad1);*/

                    } else {
                        FloatinGJob_List_Progress.setVisibility(GONE);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    FloatinGJob_List_Progress.setVisibility(GONE);

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                FloatinGJob_List_Progress.setVisibility(GONE);
                Toast.makeText(ActivityNewPost.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", USER_ID);
                map.put("type", "service_provider");

//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:UpdateCateSubonResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST_FOR_VISITING_CARD);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e("requestCode->", "onActivityResult: " + requestCode);
        try {
            super.onActivityResult(requestCode, resultCode, data);

            Log.e(TAG, "onActivityResult:---- requestCode   " + requestCode);
            Log.e(TAG, "onActivityResult:---- resultCode    " + resultCode);
            if (requestCode == 1) {
                Bitmap bitmap = BitmapFactory.decodeFile(data.getData().getPath());
                IMAGE_REQ.setImageBitmap(bitmap);

                Log.e("BITMAAP", "requestCode_1_onActivityResult: " + bitmap);
                ImageREQFile = bitmapToFile(ActivityNewPost.this, bitmap);
            } else if (requestCode == 2) {
                Bitmap bitmap = BitmapFactory.decodeFile(data.getData().getPath());
                IMG_FOR_POST.setImageBitmap(bitmap);
                Log.e("BITMAAP", "requestCode_2_onActivityResult: " + bitmap);
                IMAGE_DISFile = bitmapToFile(ActivityNewPost.this, bitmap);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


    void dilog() {
        Dialog dialogView = new Dialog(ActivityNewPost.this);
        dialogView.setContentView(R.layout.list_dialog);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogView.show();


        RecyclerView lay_ = dialogView.findViewById(R.id.heigth_list);
        ImageView close_img = dialogView.findViewById(R.id.close_img);


        close_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogView.dismiss();
            }
        });

        PopupListAdapter popupListAdapter = new PopupListAdapter(ActivityNewPost.this, professionalNameListArrayList, dialogView, this::onClick, this::onname);

        LinearLayoutManager layoutManager = new LinearLayoutManager(ActivityNewPost.this, LinearLayoutManager.VERTICAL, false);


        lay_.setLayoutManager(layoutManager);
        lay_.setAdapter(popupListAdapter);

    }


    @Override
    public void onClick(String value) {
        Log.e(TAG, "onClick:value  " + value);
        Cate_name = value;

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }


    @Override
    public void onname(String value) {
        Log.e(TAG, "onname: " + value);
        txt_.setText(value);
        checkBtnStatus();
    }


}






