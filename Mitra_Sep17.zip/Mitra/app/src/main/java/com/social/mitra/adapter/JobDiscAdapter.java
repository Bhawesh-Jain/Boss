package com.social.mitra.adapter;

import static android.content.ContentValues.TAG;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.COMUNITY_PATH_URL;
import static com.social.mitra.util.BaseUrl.USER_JOB_URL;
import static com.social.mitra.util.BaseUrl.get_community_countss;
import static com.social.mitra.util.BaseUrl.like_unlike_community;
import static com.social.mitra.util.BaseUrl.report_community_post;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.BuildConfig;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.JobPostCommentActivity;
import com.social.mitra.R;
import com.social.mitra.activity.PostCommentActivity;
import com.social.mitra.model.JobDataList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class JobDiscAdapter extends RecyclerView.Adapter<JobDiscAdapter.MyViewHolder> {

    private final ArrayList<JobDataList> list;
    private final Context context;
    private final String communityPath;
    private final Session session;
    public JobDiscAdapter(ArrayList<JobDataList> list, Context context, String communityPath) {
        this.list = list;
        this.context = context;
        this.communityPath = communityPath;
        session = new Session(context);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_job_diss, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        JobDataList currentModel = list.get(position);

        holder.user_name_tv.setText(currentModel.getName());
        holder.time_ago_tv.setText(currentModel.getAgo_time());
        holder.user_type_tv.setText(currentModel.getUser_type());
        holder.user_location_tv.setText(currentModel.getCity_name());
        holder.like_count_tv.setText(currentModel.getLike_count());
        holder.comment_count_tv.setText(currentModel.getComment_count());

        holder.desc_edt.setText(currentModel.getDescription());

        if (currentModel.getLiked().equalsIgnoreCase("1")){
            holder.ic_like.setBackgroundResource(R.drawable.love);
        }

        if (currentModel.getPost_user_category().length() != 0){
            holder.user_type_tv.setText(currentModel.getPost_user_category());
        }

        if (currentModel.getUser_image().length() != 0){
            Glide.with(context).load(currentModel.getUser_path() + currentModel.getUser_image()).into(holder.user_img);
        } else {
            String myChar = "X";
            if (!currentModel.getName().equalsIgnoreCase(""))
                myChar = Character.toString(currentModel.getName().charAt(0));

            holder.txtlet.setText(myChar.toUpperCase(Locale.ROOT));
            holder.txtlet.setVisibility(VISIBLE);
        }

        if (currentModel.getCommunity_image().length() != 0){
            Glide.with(context).load(communityPath + currentModel.getCommunity_image()).placeholder(R.drawable.loading).into(holder.disc_img);
            holder.img_card.setVisibility(VISIBLE);
        }

        holder.report_abuse_img.setOnClickListener(view -> dialog(currentModel.getId(), session.getUser_Id()));

        holder.like_lay.setOnClickListener(view -> Like_Unlike_Community(session.getUser_Id(), currentModel.getId(), holder.ic_like, holder.like_count_tv, currentModel));

        holder.share_lay.setOnClickListener(view -> {
            BitmapDrawable drawable = (BitmapDrawable) context.getResources().getDrawable(R.drawable.mitra_logo);
            Bitmap bitmap = drawable.getBitmap();
            String bitmapPath = MediaStore.Images.Media.insertImage(context.getContentResolver(), bitmap, "", "");
            Uri uri = Uri.parse(bitmapPath);

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.putExtra(Intent.EXTRA_TEXT, "Mitra\n" + currentModel.getDescription()+"\n"+"https://play.google.com/store/apps/details?id=");
            context.startActivity(Intent.createChooser(intent, "share"));
        });

        holder.call_lay.setOnClickListener(view -> {
            if (currentModel.getLiked().equals("1")) {
                if (currentModel.getUser_mobile().equalsIgnoreCase("no")) {
                    Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intentDial = new Intent
                            (Intent.ACTION_DIAL, Uri.parse("tel:" + currentModel.getUser_mobile()));

                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions((Activity) context,
                                new String[]{Manifest.permission.CALL_PHONE},   //request specific permission from user
                                10);
                    } else {
                        try {
                            context.startActivity(intentDial);  //call activity and make phone call
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(context, "yourActivity is not founded", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            } else
                Toast.makeText(context, "Please show interest for using direct call button", Toast.LENGTH_SHORT).show();
        });

        holder.comment_lay.setOnClickListener(view -> {
            Intent intent = new Intent(context, PostCommentActivity.class);
            intent.putExtra("id", currentModel.getId());

            context.startActivity(intent);
        });
    }

    private void Like_Unlike_Community(String user_id, String id, ImageView like_post, TextView like_counts, JobDataList jobDataList) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + like_unlike_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.e(TAG, "Like_Unlike_CommunityonResponse:=-=-=-=      " + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONObject DATA = jsonObject.getJSONObject("data");
                        String liked = DATA.getString("liked");
                        String like_count = DATA.getString("like_count");
                        jobDataList.setLiked(liked);
                        if (liked.equalsIgnoreCase("0")) {

                            like_post.setImageResource(R.drawable.love);
                            like_counts.setText("" + like_count);
                        } else if (liked.equalsIgnoreCase("1")) {

                            like_post.setImageResource(R.drawable.like_heart_icon);
                            like_counts.setText("" + like_count);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(context, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("community_id", id);

                Log.e(TAG, "getParams:Likes " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    private void dialog(String community_id, String user_id) {
        Dialog dialogView = new Dialog(context);
        dialogView.setContentView(R.layout.dialog_postoptions);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView report_post, promotional_post, spam_post;

        report_post = dialogView.findViewById(R.id.report_post);
        promotional_post = dialogView.findViewById(R.id.promotional_post);
        spam_post = dialogView.findViewById(R.id.spam_post);

        report_post.setOnClickListener(view -> {
            reportPost(report_post.getText().toString(), community_id, user_id);
            dialogView.dismiss();
        });
        promotional_post.setOnClickListener(view -> {
            reportPost(promotional_post.getText().toString(), community_id, user_id);
            dialogView.dismiss();
        });
        spam_post.setOnClickListener(view -> {
            reportPost(spam_post.getText().toString(), community_id, user_id);
            dialogView.dismiss();
        });
        dialogView.show();
    }

    private void reportPost(String type, String community_id, String user_id) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + report_community_post, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.d(TAG, "reportPost onResponse() called with: response = [" + response + "]");
                    Toast.makeText(context, ""+jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
//                    Layout_Progress.setVisibility(GONE);
                    e.printStackTrace();
                }
            }
        }, error -> Log.e(TAG, "reportPost: ", error)) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", user_id);
                map.put("community_id", community_id);
                map.put("report", type);

                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout like_lay, call_lay, comment_lay, share_lay;
        EditText desc_edt;
        ImageView ic_like, disc_img, report_abuse_img;
        CircleImageView user_img;
        TextView user_name_tv, time_ago_tv, user_type_tv, user_location_tv, txtlet, comment_count_tv, like_count_tv;
        CardView img_card;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            like_lay = itemView.findViewById(R.id.like_lay);
            call_lay = itemView.findViewById(R.id.call_lay);
            comment_lay = itemView.findViewById(R.id.comment_lay);
            share_lay = itemView.findViewById(R.id.share_lay);

            desc_edt = itemView.findViewById(R.id.desc_edt);

            ic_like = itemView.findViewById(R.id.ic_like);
            disc_img = itemView.findViewById(R.id.disc_img);
            report_abuse_img = itemView.findViewById(R.id.report_abuse_img);

            user_img = itemView.findViewById(R.id.user_img);

            txtlet = itemView.findViewById(R.id.txtlet);
            user_name_tv = itemView.findViewById(R.id.user_name_tv);
            time_ago_tv = itemView.findViewById(R.id.time_ago_tv);
            user_type_tv = itemView.findViewById(R.id.user_type_tv);
            user_location_tv = itemView.findViewById(R.id.user_location_tv);
            comment_count_tv = itemView.findViewById(R.id.comment_count_tv);
            like_count_tv = itemView.findViewById(R.id.like_count_tv);

            img_card = itemView.findViewById(R.id.img_card);
        }
    }
}