package com.social.mitra.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.social.mitra.fragments.JobDiscussionFragment;
import com.social.mitra.fragments.ListJobFragment;
import com.social.mitra.model.ReelModel;

import java.util.ArrayList;

public class MyWorksViewpager extends FragmentStateAdapter {

    ArrayList<ReelModel> list;
    public MyWorksViewpager(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0)
        return new ListJobFragment();
        else return new JobDiscussionFragment();
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
