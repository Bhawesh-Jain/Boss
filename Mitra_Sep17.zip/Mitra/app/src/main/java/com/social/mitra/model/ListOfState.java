package com.social.mitra.model;

public class ListOfState {

    String state_id,State_name;

    public ListOfState(String state_id, String state_name) {
        this.state_id = state_id;
        State_name = state_name;
    }

    public String getState_id() {
        return state_id;
    }

    public void setState_id(String state_id) {
        this.state_id = state_id;
    }

    public String getState_name() {
        return State_name;
    }

    public void setState_name(String state_name) {
        State_name = state_name;
    }
}
