package com.social.mitra;

import static android.R.layout.simple_spinner_item;
import static android.content.ContentValues.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_cities;
import static com.social.mitra.util.BaseUrl.get_experience;
import static com.social.mitra.util.BaseUrl.update_profile_new;
import static com.social.mitra.util.BaseUrl.update_profile_new_image;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.core.motion.utils.Oscillator;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.model.ListOfExperience;
import com.social.mitra.model.ListOfState;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MaterialProfileCreationActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST = 1;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    Session session;
    String user_id, mobile_number;
    CardView upload_user_visiting_card, user_gov_id_upload, next_btn_after_profile;
    ImageView Image_holder_user, Upload_icon_image, image_visiting_card, image_govv_idd;
    EditText Full_name_user, location_user, user_mobile_number_, user_firm_name, bio_user, user_professional_cate, User_Email;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    Switch switch_for_mobile_hide_unhide;
    MaterialSpinner list_experience, list_home_city;
    String Procate_name;
    String MTypee;
    File Profile_Image = null, Image_visiting_card = null, Image_Gov_id = null;
    int switch_value = 0;
    ArrayList<ListOfState> listOfStateArrayList = new ArrayList<>();
    ArrayList<String> MyCity = new ArrayList<>();

    ArrayList<ListOfExperience> listOfExperiences = new ArrayList<>();
    ArrayList<String> MyExperience = new ArrayList<>();

    String city_id = "", experience = "";
    String Addresss, cate_name;
    String LocationName;
    String City_Name;
    String loac;
    SessionLogOut sessionLogOut;

    public static File bitmapToFile(Context mContext, Bitmap bitmap) {
        try {
            String name = System.currentTimeMillis() + ".png";
            File file = new File(mContext.getCacheDir(), name);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 60, bos);
            byte[] bArr = bos.toByteArray();
            bos.flush();
            bos.close();

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mat_creation);
        session = new Session(MaterialProfileCreationActivity.this);
        sessionLogOut = new SessionLogOut(MaterialProfileCreationActivity.this);
        user_gov_id_upload = findViewById(R.id.user_gov_id_upload);
        upload_user_visiting_card = findViewById(R.id.upload_user_visiting_card);
        Image_holder_user = findViewById(R.id.Image_holder_user);
        Upload_icon_image = findViewById(R.id.Upload_icon_image);
        Full_name_user = findViewById(R.id.Full_name_user);
        user_mobile_number_ = findViewById(R.id.user_mobile_number_);
        user_firm_name = findViewById(R.id.user_firm_name);
        bio_user = findViewById(R.id.bio_user);
        user_professional_cate = findViewById(R.id.user_professional_cate);
        next_btn_after_profile = findViewById(R.id.next_btn_after_profile);
        switch_for_mobile_hide_unhide = findViewById(R.id.switch_for_mobile_hide_unhide);
        location_user = findViewById(R.id.location_user);
        list_experience = findViewById(R.id.list_experience);
        list_home_city = findViewById(R.id.list_home_state);
        User_Email = findViewById(R.id.User_Email);
        image_visiting_card = findViewById(R.id.image_visiting_card);
        image_govv_idd = findViewById(R.id.image_govv_idd);


        user_id = session.getUser_Id();
        Log.e(TAG, "===MaterialProfileCreationActivity_USER_ID: " + user_id);
        mobile_number = session.getMobile();
        Log.e(TAG, "===MaterialProfileCreationActivity_mobile_number: " + mobile_number);

        user_mobile_number_.setText(mobile_number);

        LocationName = sessionLogOut.getLocName();

        if (getIntent() != null) {
            Addresss = getIntent().getStringExtra("address");
            MTypee = getIntent().getStringExtra("KeyType");
            Procate_name = getIntent().getStringExtra("cate_name");
            loac = getIntent().getStringExtra("LOC");
        }
        City_Name = session.getcity_name();

        if (Procate_name.equalsIgnoreCase(""))
            Procate_name = session.getProfessionNAME();

        Log.e(Oscillator.TAG, "---City_Name: " + City_Name);
        Log.e(Oscillator.TAG, "---Procate_name: " + Procate_name);

        Log.e(Oscillator.TAG, "==MaterialProfileCreationActivity" + LocationName);
        Log.e(Oscillator.TAG, "==MaterialProfileCreationActivity_cate_name" + cate_name);
        Log.e(Oscillator.TAG, "==loac" + loac);
        Log.e(Oscillator.TAG, "==MTypee" + MTypee);

        location_user.setText(City_Name);

        user_professional_cate.setText(Procate_name);

        switch_for_mobile_hide_unhide.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                switch_value = 1;
                Log.e(TAG, "===switch_value=true;: " + switch_value);
            }
        });


        image_govv_idd.setOnClickListener(view -> ImagePicker.Companion.with(MaterialProfileCreationActivity.this)
                .crop()
                .compress(200)            //Final image size will be less than 1 MB(Optional)
                .start(3));


        image_visiting_card.setOnClickListener(view -> ImagePicker.Companion.with(MaterialProfileCreationActivity.this)
                .crop()
                .compress(200)            //Final image size will be less than 1 MB(Optional)
                .start(2));

        Upload_icon_image.setOnClickListener(view -> ImagePicker.Companion.with(MaterialProfileCreationActivity.this)
                .crop()
                .compress(200)            //Final image size will be less than 1 MB(Optional)
                .start(1));

        Get_CityList();
        Get_Experience();

        list_home_city.setOnItemSelectedListener((view, position, id, item) -> city_id = listOfStateArrayList.get(position).getState_id());

        list_experience.setOnItemSelectedListener((view, position, id, item) -> {
            experience = listOfExperiences.get(position).getExperience_Name();
            session.setEX_Name(experience);
        });


        next_btn_after_profile.setOnClickListener(view -> {
            Log.e(TAG, "next_btn_after_profile: ");
            if (Full_name_user.getText().toString().equals("") && Full_name_user.getText().length() < 3) {
                Full_name_user.setFocusable(true);
                Full_name_user.setError("Enter Your Full Name");
            } else {
                Update_Profile_New(session.getUser_Id());
                Log.e(TAG, "++++USER_IDDD:  " + session.getUser_Id());
            }

        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.e("requestCode->", "onActivityResult: " + requestCode);
        try {
            super.onActivityResult(requestCode, resultCode, data);

            Log.e(TAG, "onActivityResult:---- requestCode   " + requestCode);
            Log.e(TAG, "onActivityResult:---- resultCode    " + resultCode);
            if (requestCode == 1) {
                Bitmap bitmap = BitmapFactory.decodeFile(data.getData().getPath());
                Image_holder_user.setImageBitmap(bitmap);

                Log.e("BITMAAP", "requestCode_1_onActivityResult: " + bitmap);
                Profile_Image = bitmapToFile(MaterialProfileCreationActivity.this, bitmap);

                Update_Profile_New_Image(session.getUser_Id());

            } else if (requestCode == 2) {
                Bitmap bitmap = BitmapFactory.decodeFile(data.getData().getPath());
                image_visiting_card.setImageBitmap(bitmap);
                Log.e("BITMAAP", "requestCode_2_onActivityResult: " + bitmap);
                Image_visiting_card = bitmapToFile(MaterialProfileCreationActivity.this, bitmap);
                _Update_Profile_New_Image(session.getUser_Id());

            } else if (requestCode == 3) {
                Bitmap bitmap = BitmapFactory.decodeFile(data.getData().getPath());
                image_govv_idd.setImageBitmap(bitmap);
                Log.e("BITMAAP", "requestCode_3_onActivityResult: " + bitmap);
                Image_Gov_id = bitmapToFile(MaterialProfileCreationActivity.this, bitmap);
                _Update_Profile_New_Image_(session.getUser_Id());
            }


        } catch (Exception exception) {

            exception.printStackTrace();

        }


    }

    private void _Update_Profile_New_Image_(String user_id) {
        AndroidNetworking.upload(Base_Url + update_profile_new_image)
                .addMultipartParameter("user_id", user_id)
                .addMultipartFile("govt_id_image", Image_Gov_id)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("---rrrProfile", "save_postsave_post" + jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");

                            Toast.makeText(MaterialProfileCreationActivity.this, msg, Toast.LENGTH_SHORT).show();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                    }
                });
    }

    private void _Update_Profile_New_Image(String user_id) {
        AndroidNetworking.upload(Base_Url + update_profile_new_image)
                .addMultipartParameter("user_id", user_id)
                .addMultipartFile("visiting_card_image", Image_visiting_card)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("---rrrProfile", "save_postsave_post" + jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);

                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");
                            Toast.makeText(MaterialProfileCreationActivity.this, msg, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                    }
                });
    }

    private void Update_Profile_New_Image(String user_id) {
        AndroidNetworking.upload(Base_Url + update_profile_new_image)
                .addMultipartParameter("user_id", user_id)
                .addMultipartFile("image", Profile_Image)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("---rrrProfile", "save_postsave_post" + jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");
                            Toast.makeText(MaterialProfileCreationActivity.this, msg, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                    }
                });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, 2);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, 3);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void Get_Experience() {
        listOfExperiences.clear();

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_experience, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e("MaterialProfileActivity", "---Get_Experience>>" + jsonObject);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONArray countryArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < countryArray.length(); i++) {
                            JSONObject country_data = countryArray.getJSONObject(i);

                            String experience_id = country_data.getString("id");
                            String experience_name = country_data.getString("name");

                            ListOfExperience listOfExperience = new ListOfExperience(experience_id, experience_name);
                            listOfExperiences.add(listOfExperience);
                            MyExperience.add(experience_name);
                        }
                        ArrayAdapter<String> ad = new ArrayAdapter<>(MaterialProfileCreationActivity.this, simple_spinner_item, MyExperience);
                        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        list_experience.setAdapter(ad);

                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(MaterialProfileCreationActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    Toast.makeText(MaterialProfileCreationActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, error -> {
            progressDialog.dismiss();
            Toast.makeText(MaterialProfileCreationActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        });
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void Get_CityList() {
        listOfStateArrayList.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e("MaterialProfileActivity", "---Get_CityList>>" + jsonObject);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONArray state = jsonObject.getJSONArray("data");

                        for (int i = 0; i < state.length(); i++) {
                            JSONObject country_data = state.getJSONObject(i);

                            String City_id = country_data.getString("id");
                            String City_name = country_data.getString("name");

                            ListOfState listOfState = new ListOfState(City_id, City_name);
                            listOfStateArrayList.add(listOfState);
                            MyCity.add(City_name);
                        }
                        ArrayAdapter<String> ad1 = new ArrayAdapter<>(MaterialProfileCreationActivity.this, simple_spinner_item, MyCity);
                        ad1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        list_home_city.setAdapter(ad1);
                    } else {
                        Toast.makeText(MaterialProfileCreationActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(MaterialProfileCreationActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, error -> Toast.makeText(MaterialProfileCreationActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show());

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void Update_Profile_New(String user_id) {
        if (experience.equalsIgnoreCase(""))
            experience = listOfExperiences.get(list_experience.getSelectedIndex()).getExperience_Name();

        ProgressDialog progressDialog = new ProgressDialog(this);
        String ItemName = Full_name_user.getText().toString();
        String ItemDesc = user_firm_name.getText().toString();
        String itemBio = bio_user.getText().toString();
        String Email = User_Email.getText().toString();

        if (city_id.equalsIgnoreCase("") || city_id.equalsIgnoreCase("0"))
            city_id = listOfStateArrayList.get(list_home_city.getSelectedIndex()).getState_id();

        Log.e("MaterialProfileActivity", "++++Method_USER_IDDD:  " + session.getUser_Id());
        Log.e("MaterialProfileActivity", "addPost: ");
        Log.e("MaterialProfileActivity", "===Switch_API: " + switch_value);
        Log.e("MaterialProfileActivity", "===Profile_Image: " + Profile_Image);
        Log.e("MaterialProfileActivity", "===Image_visiting_card_API: " + Image_visiting_card);
        Log.e("MaterialProfileActivity", "===Image_Gov_id_API: " + Image_Gov_id);
        Log.e("MaterialProfileActivity", "===ItemName: " + ItemName);
        Log.e("MaterialProfileActivity", "===ItemDesc: " + ItemDesc);
        Log.e("MaterialProfileActivity", "===itemBio: " + itemBio);
        Log.e("MaterialProfileActivity", "===Email: " + Email);
        Log.e("MaterialProfileActivity", "===experience: " + experience);
        Log.e("MaterialProfileActivity", "===City_name: " + city_id);

        AndroidNetworking.upload(Base_Url + update_profile_new)
                .addMultipartParameter("user_id", user_id)
                .addMultipartParameter("name", ItemName)
                .addMultipartParameter("no_on_profile", String.valueOf(switch_value))
                .addMultipartParameter("company_name", ItemDesc)
                .addMultipartParameter("email", Email)
                .addMultipartParameter("bio", itemBio)
                .addMultipartParameter("experience", experience)
                .addMultipartParameter("location", City_Name)
                .addMultipartParameter("language", session.getValue(Session.language))
                .addMultipartParameter("city_id", city_id)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("MaterialProfileActivity", "save_postsave_post" + jsonObject.toString());

                            progressDialog.dismiss();
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");

                            if (result.equalsIgnoreCase("true")) {
                                Log.e(TAG, "===Intent_profile: ");
                                Intent intent = new Intent(MaterialProfileCreationActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", MTypee);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(MaterialProfileCreationActivity.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                    }
                });
    }
}
