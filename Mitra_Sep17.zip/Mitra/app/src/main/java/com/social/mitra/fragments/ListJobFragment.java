package com.social.mitra.fragments;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_cities;
import static com.social.mitra.util.BaseUrl.get_community;
import static com.social.mitra.util.BaseUrl.get_main_category;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.social.mitra.ActivityNewPost;
import com.social.mitra.R;
import com.social.mitra.adapter.WorkJobAdapter;
import com.social.mitra.model.CityList;
import com.social.mitra.model.JobDataList;
import com.social.mitra.model.ProfessionalNameList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ListJobFragment extends Fragment {
    private static final String TAG = "ListJobFragment";
    FloatingActionButton BUTTON_FLOATING;
    ArrayList<CityList> simple_months = new ArrayList<>();
    ArrayAdapter<String> spinnermnthArrayAdapter;
    ArrayList<String> monthlist = new ArrayList<>();


    Spinner city_spinner;
    Spinner profession_spinner;
    String Cate_name;
    RecyclerView recycler_jobb_list;
    RelativeLayout Job_List_Progress;
    String city_name = "", category_id = "";

    ArrayList<ProfessionalNameList> professionalNameListArrayList = new ArrayList<>();
    ArrayList<String> ProcATE = new ArrayList<>();


    Session session;
    String USER_ID;
    String Type = "requirement";

    ArrayList<JobDataList> jobDataListArrayList = new ArrayList<>();
    private boolean firstTime = true;
    private boolean firstTimeCity = true;


    @Override
    public void onResume() {
        super.onResume();
        if (session.getValue("firstTime").equalsIgnoreCase("false")) {
            _Get_Community(USER_ID, Type);
            session.setValue("firstTime", "true");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_joblist_, container, false);

        session = new com.social.mitra.sessionData.Session(getActivity());
        USER_ID = session.getUser_Id();
        Log.e(TAG, "===ListJobFragment_USER_ID: " + USER_ID);


        BUTTON_FLOATING = root.findViewById(R.id.BUTTON_FLOATING);

        city_spinner = root.findViewById(R.id.spinner1);
        profession_spinner = root.findViewById(R.id.spinner2);
        recycler_jobb_list = root.findViewById(R.id.recycler_jobb_list);

        Job_List_Progress = root.findViewById(R.id.Job_List_Progress);

        _Get_Community(USER_ID, Type);

        _Get_Main_Category(USER_ID);

        city_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    city_name = simple_months.get(position).getCityName();
                    String cate_name = profession_spinner.getSelectedItem().toString();
                    if (!city_name.equalsIgnoreCase("All Cities") && !firstTimeCity) {
                        filterCommunity(city_name, cate_name, USER_ID, Type);
                    } else if (!cate_name.equalsIgnoreCase("All Professions") && !firstTimeCity) {
                        filterCommunity(city_name, cate_name, USER_ID, Type);
                    } else
                        _Get_Community(USER_ID, Type);
                    firstTimeCity = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        profession_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    city_name = city_spinner.getSelectedItem().toString();
                    String cate_name = professionalNameListArrayList.get(position).getProfession_name();
                    if (!city_name.equalsIgnoreCase("All Cities") && !firstTime) {
                        filterCommunity(city_name, cate_name, USER_ID, Type);
                    } else if (!cate_name.equalsIgnoreCase("All Professions") && !firstTime) {
                        filterCommunity(city_name, cate_name, USER_ID, Type);
                    } else
                        _Get_Community(USER_ID, Type);
                    firstTime = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        BUTTON_FLOATING.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ActivityNewPost.class);
                startActivity(intent);
            }
        });

        get_cities();
        return root;
    }

    private void filterCommunity(String city, String cate, String user_id, String type) {
        Log.e(TAG, "filterCommunity: Params - city"+ city +", cate " + cate+", user_id " + user_id+", type " + type );
        jobDataListArrayList.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                Base_Url + get_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String community_path = jsonObject.getString("community_path");

//                    Job_List_Progress.setVisibility(View.GONE);
                    Log.e(TAG, "==onResponse:_Get_Community   " + response);
//                    progressDialog.dismiss();
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Community_id = dataObj.getString("id");

                            String id_ID = dataObj.getString("user_id");

                            String _name = dataObj.getString("name");


                            String _image = dataObj.getString("user_image");
                            String _required = dataObj.getString("required");
                            String _description = dataObj.getString("description");
                            String _created_date = dataObj.getString("created_date");
                            String _ago_time = dataObj.getString("ago_time");
                            String _community_image = dataObj.getString("community_image");
                            String _liked = dataObj.getString("liked");
                            String _like_count = dataObj.getString("like_count");
                            String _comment_count = dataObj.getString("comment_count");
                            String city_name = dataObj.getString("city_name");
                            String user_type = dataObj.getString("usertype");
                            String is_phone = dataObj.getString("is_phone");
                            String post_user_category = dataObj.getString("post_user_category");
                            String user_mobile = dataObj.getString("user_mobile");

                            if (city.equalsIgnoreCase("All Cities")) {
                                if (cate.equalsIgnoreCase(_required)) {
                                    JobDataList jobDataList = new JobDataList(Community_id, id_ID, _name, _image, _required, _description, _community_image, _created_date, _ago_time, _liked, _like_count, _comment_count, city_name, user_type, is_phone, post_user_category, user_mobile);
                                    jobDataListArrayList.add(jobDataList);
                                }
                            } else if (cate.equalsIgnoreCase("All Professions")) {
                                if (city.equalsIgnoreCase(city_name)) {
                                    JobDataList jobDataList = new JobDataList(Community_id, id_ID, _name, _image, _required, _description, _community_image, _created_date, _ago_time, _liked, _like_count, _comment_count, city_name, user_type, is_phone, post_user_category, user_mobile);
                                    jobDataListArrayList.add(jobDataList);
                                }
                            } else if (city.equalsIgnoreCase(city_name) && cate.equalsIgnoreCase(_required)) {
                                JobDataList jobDataList = new JobDataList(Community_id, id_ID, _name, _image, _required, _description, _community_image, _created_date, _ago_time, _liked, _like_count, _comment_count, city_name, user_type, is_phone, post_user_category, user_mobile);
                                jobDataListArrayList.add(jobDataList);
                            }
                        }
                        if (jobDataListArrayList.size() == 0) {
                            Toast.makeText(getContext(), "No Post for Selected Filters", Toast.LENGTH_SHORT).show();
                            WorkJobAdapter workJobAdapter = new WorkJobAdapter(new ArrayList<>(), getActivity(), community_path);

                            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
                            recycler_jobb_list.setLayoutManager(layoutManager);
                            recycler_jobb_list.setAdapter(workJobAdapter);
                        } else {
                            WorkJobAdapter workJobAdapter = new WorkJobAdapter(jobDataListArrayList, getActivity(), community_path);

                            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
                            recycler_jobb_list.setLayoutManager(layoutManager);
                            recycler_jobb_list.setAdapter(workJobAdapter);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("type", type);
                Log.e(TAG, "getParams:workJob   ListonResponse " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    private void _Get_Community(String user_id, String type) {
        jobDataListArrayList.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                Base_Url + get_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String community_path = jsonObject.getString("community_path");

//                    Job_List_Progress.setVisibility(View.GONE);
                    Log.e(TAG, "==onResponse:_Get_Community   " + response);
//                    progressDialog.dismiss();
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        jobDataListArrayList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Community_id = dataObj.getString("id");

                            String id_ID = dataObj.getString("user_id");

                            String _name = dataObj.getString("name");

                            String _image = dataObj.getString("user_image");
                            String _required = dataObj.getString("required");
                            String _description = dataObj.getString("description");
                            String _created_date = dataObj.getString("created_date");
                            String _ago_time = dataObj.getString("ago_time");
                            String _community_image = dataObj.getString("community_image");
                            String _liked = dataObj.getString("liked");
                            String _like_count = dataObj.getString("like_count");
                            String _comment_count = dataObj.getString("comment_count");
                            String city_name = dataObj.getString("city_name");
                            String user_type = dataObj.getString("usertype");
                            String is_phone = dataObj.getString("is_phone");
                            String post_user_category = dataObj.getString("post_user_category");
                            String user_mobile = dataObj.getString("user_mobile");

                            JobDataList jobDataList = new JobDataList(Community_id, id_ID, _name, _image, _required, _description, _community_image, _created_date, _ago_time, _liked, _like_count, _comment_count, city_name, user_type, is_phone, post_user_category, user_mobile);

                            jobDataListArrayList.add(jobDataList);
                        }
                        WorkJobAdapter workJobAdapter = new WorkJobAdapter(jobDataListArrayList, getActivity(), community_path);

                        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
                        recycler_jobb_list.setLayoutManager(layoutManager);
                        recycler_jobb_list.setAdapter(workJobAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("type", type);
                Log.e(TAG, "getParams:workJob   ListonResponse " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    private void get_cities() {

        simple_months.clear();
        monthlist.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse:response  " + response);
                        try {
                            JSONObject obj = new JSONObject(response);

                            String result = obj.getString("result");
                            if (result.equalsIgnoreCase("true")) {
                                monthlist.add("All Cities");

                                JSONArray jsonArray = obj.getJSONArray("data");

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                                    String plan_id = jsonObject1.getString("id");
                                    String special = jsonObject1.getString("name");
                                    CityList allCommunityModel = new CityList(plan_id, special);
                                    monthlist.add(special);
                                    simple_months.add(allCommunityModel);
                                }
                                simple_months.add(0, new CityList("", "All Cities"));

                                spinnermnthArrayAdapter = new ArrayAdapter<>(getActivity(), R.layout.simple_spinner_item, monthlist);
                                spinnermnthArrayAdapter.setDropDownViewResource(R.layout.simple_spinner_item);

                                city_spinner.setAdapter(spinnermnthArrayAdapter);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    private void _Get_Main_Category(String USER_ID) {
        Log.e(TAG, "***_Get_Main_Category: ");
        professionalNameListArrayList.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_main_category, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "==onResponse:_Get_Main_Category" + response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        Log.e("ProfileCreationActivity", "---Get_SateList>>" + jsonObject);

                        JSONArray state = jsonObject.getJSONArray("data");

                        ProcATE.add("All Professions");
                        for (int i = 0; i < state.length(); i++) {
                            JSONObject country_data = state.getJSONObject(i);

                            String Cate_id = country_data.getString("id");
                            String Cate_img = country_data.getString("image");
                            Cate_name = country_data.getString("name");

                            ProfessionalNameList professionalNameList = new ProfessionalNameList(Cate_img, Cate_name, Cate_id);

                            professionalNameListArrayList.add(professionalNameList);

                            ProcATE.add(Cate_name);
                        }
                        ArrayAdapter<String> ad1 = new ArrayAdapter<>(getActivity(), R.layout.simple_spinner_item, ProcATE);
                        professionalNameListArrayList.add(0, new ProfessionalNameList("", "All Professions", ""));

                        ad1.setDropDownViewResource(R.layout.simple_spinner_item);
                        profession_spinner.setAdapter(ad1);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", USER_ID);
                map.put("type", "service_provider");
                Log.e(TAG, "getParams:UpdateCateSubonResponse " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }
}