package com.social.mitra.UI;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.Post_Video_Url;
import static com.social.mitra.util.BaseUrl.get_reels;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.jarvanmo.exoplayerview.media.SimpleMediaSource;
import com.jarvanmo.exoplayerview.ui.ExoVideoView;
import com.social.mitra.R;
import com.social.mitra.activity.AddPostActivity;
import com.social.mitra.adapter.HomeReelAdapter;
import com.social.mitra.adapter.VideoViewAdapter;
import com.social.mitra.interfa.On_Click;
import com.social.mitra.model.HomePostModel;
import com.social.mitra.model.ReelModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class HomeFragment extends Fragment {

    public static ArrayList<Integer> video_position = new ArrayList<>();
    VideoViewAdapter videoViewAdapter;
    ArrayList<String> videos = new ArrayList<>();
    ImageView bookmark, like_img, like_img1, comment_img, refrence_img, report_abuse_img, ic_camera;
    CircleImageView user_image;
    Session session;
    ExoVideoView videoView;
    RecyclerView home_post_list;
    ArrayList<HomePostModel> homePostModels = new ArrayList<>();
    //    HomePostAdapter homePostAdapter;
    On_Click click;
    private ArrayList<ReelModel> reelList = new ArrayList<>();
    HomeReelAdapter homeReelAdapter;
    RecyclerView homeReelRecycler;
    private final String TAG = "HomeFragment";

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        homeReelRecycler = root.findViewById(R.id.home_recycler);

        bookmark = root.findViewById(R.id.bookmark_img);
        user_image = root.findViewById(R.id.user_image);
        refrence_img = root.findViewById(R.id.reference_img);
        like_img = root.findViewById(R.id.delete_img);
        comment_img = root.findViewById(R.id.comment_img);

        report_abuse_img = root.findViewById(R.id.report_abuse_img);
        home_post_list = root.findViewById(R.id.home_post_list);
        videoView = root.findViewById(R.id.fullscreenVideoView);

        ic_camera = root.findViewById(R.id.ic_camera);

        session = new Session(getActivity());

        ic_camera.setOnClickListener(view -> dialog());

        home_post_list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onScrollStateChanged(@NonNull @NotNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull @NotNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager llm = (LinearLayoutManager) recyclerView.getLayoutManager();

                int visiblePosition = llm.findFirstCompletelyVisibleItemPosition();

                RecyclerView.SmoothScroller smoothScroller = new
                        LinearSmoothScroller(getActivity()) {
                            @Override
                            protected int getVerticalSnapPreference() {
                                return LinearSmoothScroller.SNAP_TO_ANY;
                            }
                        };

                if (visiblePosition > -1 && !homePostModels.get(visiblePosition).getPost_video().equals("")) {

                    smoothScroller.setTargetPosition(visiblePosition);

                    home_post_list.getLayoutManager().startSmoothScroll(smoothScroller);
//                Log.e(" Scroll ", "onScrolled: "+visiblePosition );

                    SimpleMediaSource mediaSource = new SimpleMediaSource(Post_Video_Url + homePostModels.get(visiblePosition).getPost_video());

                    Log.e(" Scroll ", "onScrolled in : " + visiblePosition);

                    ExoVideoView post_video_view = llm.findViewByPosition(visiblePosition).findViewById(R.id.videoView);

                    post_video_view.hideController();
                    post_video_view.setControllerAutoShow(false);
                    post_video_view.setUseController(false);

                    post_video_view.changeWidgetVisibility(R.id.exo_player_controller_back, View.INVISIBLE);

                    for (int i = 0; i < video_position.size(); i++) {
                        if (visiblePosition == video_position.get(i)) {
                            post_video_view.play(mediaSource);
                            post_video_view.resume();
                        } else {
                            post_video_view.stop();
                            post_video_view.pause();
                        }
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            getReels();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getReels() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_reels, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if (jsonObject.getString("result").equals("true")) {
                        reelList.clear();
                        Log.d(TAG, "onResponse() called with: response = [" + response + "]");
                        JSONArray data = jsonObject.getJSONArray("data");
                        String user_path = jsonObject.getString("user_path");
                        String reel_path = jsonObject.getString("reel_path");

                        for (int i = 0; i < data.length(); i++) {
                            JSONObject dataObj = data.getJSONObject(i);

                            String id = dataObj.getString("id");
                            String user_id = dataObj.getString("user_id");
                            String file = dataObj.getString("file");
                            String image_2 = dataObj.getString("image_2");
                            String image_3 = dataObj.getString("image_3");
                            String image_4 = dataObj.getString("image_4");
                            String image_5 = dataObj.getString("image_5");
                            String image_6 = dataObj.getString("image_6");
                            String image_7 = dataObj.getString("image_7");
                            String image_8 = dataObj.getString("image_8");
                            String image_9 = dataObj.getString("image_9");
                            String image_10 = dataObj.getString("image_10");
                            String description = dataObj.getString("description");
                            String image_text = dataObj.getString("image_text");
                            String textColor = dataObj.getString("textcolor");
                            String type = dataObj.getString("type");
                            String created_date = dataObj.getString("created_date");
                            String updated_date = dataObj.getString("updated_date");
                            String name = dataObj.getString("name");
                            String fname = dataObj.getString("fname");
                            String lname = dataObj.getString("lname");
                            String city_name = dataObj.getString("city_name");
                            String user_image = dataObj.getString("user_image");

                            int like_count = dataObj.getInt("like_count");
                            int i_liked = dataObj.getInt("i_liked");
                            int comment_count = dataObj.getInt("comment_count");
                            int i_followed = dataObj.getInt("i_followed");

                            ReelModel model = new ReelModel(id, user_id, file, image_2, image_3, image_4,
                                    image_5, image_6, image_7, image_8, image_9, image_10, description,
                                    image_text, textColor, type, created_date, updated_date, name, fname,
                                    lname, city_name, user_image, like_count, i_liked, comment_count, i_followed, user_path, reel_path);

                            reelList.add(model);
                        }
                        homeReelAdapter = new HomeReelAdapter(reelList, getContext());
                        homeReelRecycler.setAdapter(homeReelAdapter);
                        homeReelRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
                    } else {
                        Toast.makeText(getContext(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", session.getUser_Id());

                return map;
            }
        };
        VolleySingleton.getInstance(getContext()).addToRequestQueue(stringRequest);
    }

    void dialog() {
        Dialog dialogView = new Dialog(getContext());
        dialogView.setContentView(R.layout.dialog_addpost);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView text, photo, video;

        text = dialogView.findViewById(R.id.text_add_post);
        photo = dialogView.findViewById(R.id.photo_add_post);
        video = dialogView.findViewById(R.id.video_add_post);

        if (text != null)
            text.setOnClickListener(view -> {
                startActivity(new Intent(getActivity(), AddPostActivity.class).putExtra("mode", "text"));
                dialogView.dismiss();
            });
        if (photo != null)
            photo.setOnClickListener(view -> {
                startActivity(new Intent(getActivity(), AddPostActivity.class).putExtra("mode", "image"));
                dialogView.dismiss();
            });
        if (video != null)
            video.setOnClickListener(view -> {
                startActivity(new Intent(getActivity(), AddPostActivity.class).putExtra("mode", "video"));
                dialogView.dismiss();
            });
        dialogView.show();

    }
}