package com.social.mitra.interfa;

import com.social.mitra.model.MaterialSubCateList;

public interface MSubCateClick {

    void MSubClicked(MaterialSubCateList itemClicked);
}
