package com.social.mitra.adapter;

import static com.social.mitra.util.BaseUrl.Cate_image_url;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.interfa.Category_interface;
import com.social.mitra.model.HouseGetCategoryModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class GetCategoryAdapter extends RecyclerView.Adapter<GetCategoryAdapter.MyViewHolder> {

    Context context;
    ArrayList<HouseGetCategoryModel> houseGetCategoryModels;
    Category_interface listener;

    public GetCategoryAdapter(Context context, ArrayList<HouseGetCategoryModel> houseGetCategoryModels, Category_interface listener) {
        this.context = context;
        this.houseGetCategoryModels = houseGetCategoryModels;
        this.listener = listener;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_stage_house, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        if (houseGetCategoryModels.size() > 0) {
            HouseGetCategoryModel houseGetCategoryModel = houseGetCategoryModels.get(position);

            holder.bind(houseGetCategoryModel,listener);

            Glide.with(context).load(Cate_image_url + houseGetCategoryModel.getCate_image()).into(holder.category_iconn);

            holder.txt_cate_subject.setText(houseGetCategoryModel.getCate_name());

            holder.txt_cate_sub_subject.setText(houseGetCategoryModel.getCate_desc());
        }

//        holder.layout_house_stages.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//
//                            holder.layout_house_stages.setBackgroundResource(R.drawable.list_border);
//                            holder.layout_image_icon.setBackgroundResource(R.drawable.list_border);
//                            final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(context);
//                            View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.bottom_sheet, null);
//                            mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//
//
//                            mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//                            mBottomSheetDialog.setContentView(sheetView);
//
//                            CheckBox check_one_one, check_two_two, check_three_three, check_four_four, check_five_five;
//                            RecyclerView recycler_sub_category;
//                            check_one_one = mBottomSheetDialog.findViewById(R.id.check_one_one);
//                            recycler_sub_category = mBottomSheetDialog.findViewById(R.id.recycler_sub_category);
//                            check_two_two = mBottomSheetDialog.findViewById(R.id.check_two_two);
//                            check_three_three = mBottomSheetDialog.findViewById(R.id.check_three_three);
//                            check_four_four = mBottomSheetDialog.findViewById(R.id.check_four_four);
//                            check_five_five = mBottomSheetDialog.findViewById(R.id.check_five_five);
//
//
//                            CardView nextt_button = mBottomSheetDialog.findViewById(R.id.nextt_button);
//
//                            check_one_one.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//
//                                        }
//                                    });
//                                }
//                            });
//                            check_two_two.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//                                        }
//                                    });
//                                }
//                            });
//
//                            check_three_three.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//                                        }
//                                    });
//                                }
//                            });
//                            check_four_four.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
//                                        }
//                                    });
//                                }
//                            });
//
//                            check_five_five.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                                    check_one_one.setChecked(false);
//                                    check_two_two.setChecked(false);
//                                    check_three_three.setChecked(false);
//                                    check_four_four.setChecked(false);
//                                    nextt_button.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View view) {
//                                            Intent intent = new Intent(context, ActivityVerifyProfile.class);
//                                            context.startActivity(intent);
////                                finish();
//                                        }
//                                    });
//                                }
//                            });
//
//                            mBottomSheetDialog.show();
//
//                        }
//
//
//                });
//        notifyDataSetChanged();


    }


    @Override
    public int getItemCount() {
        return houseGetCategoryModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView category_iconn;
        TextView txt_cate_subject,txt_cate_sub_subject;
        LinearLayout layout_bg_image,layout_house_stages,layout_image_icon;


        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            category_iconn = itemView.findViewById(R.id.category_iconn);
            txt_cate_subject = itemView.findViewById(R.id.txt_cate_subject);
            txt_cate_sub_subject = itemView.findViewById(R.id.txt_cate_sub_subject);
            layout_house_stages = itemView.findViewById(R.id.layout_house_stages);
            layout_bg_image = itemView.findViewById(R.id.layout_bg_image);
            layout_image_icon = itemView.findViewById(R.id.layout_image_icon);
        }

        public void bind(HouseGetCategoryModel houseGetCategoryModel, Category_interface onItemClick) {
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        listener.onItemClick(houseGetCategoryModel);
                    }
                });
        }
    }
}




