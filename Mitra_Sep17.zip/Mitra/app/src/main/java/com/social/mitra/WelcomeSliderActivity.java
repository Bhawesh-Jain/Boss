package com.social.mitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;

public class WelcomeSliderActivity extends AppCompatActivity {
    ImageSlider image_slider;
    TextView AG_getstarted;


    ArrayList<SlideModel> slideModelArrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_slider);

        image_slider = findViewById(R.id.image_slider);
        AG_getstarted = findViewById(R.id.AG_getstarted);



        SlideModel slideModel=new SlideModel(R.drawable.sliders1, ScaleTypes.FIT);
        SlideModel slideModel2=new SlideModel(R.drawable.sliders2,ScaleTypes.FIT);
        SlideModel slideModel3=new SlideModel(R.drawable.sliders3,ScaleTypes.FIT);
        // for one image
        slideModelArrayList.add(slideModel);
        slideModelArrayList.add(slideModel2);
        slideModelArrayList.add(slideModel3);
        image_slider.setImageList(slideModelArrayList, ScaleTypes.FIT);




        AG_getstarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeSliderActivity.this, SelectLanguageActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.enter, R.anim.exit);
            }
        });




    }
}