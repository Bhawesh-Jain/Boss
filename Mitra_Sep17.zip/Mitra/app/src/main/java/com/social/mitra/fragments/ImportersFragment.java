package com.social.mitra.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;
import com.social.mitra.activity.BuyLeadActivity;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ImportersFragment extends Fragment {

    TextView interasted_tv;
    Session session;
    public ImportersFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_buy_lead, container, false);
        interasted_tv = root.findViewById(R.id.interasted_tv);
        session = new Session(getActivity());
        interasted_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().startActivity(new Intent(getActivity(), BuyLeadActivity.class));
//                getActivity().overridePendingTransition( R.anim.nav_default_enter_anim, R.anim.nav_default_exit_anim );


            }
        });

        return root;
    }

    private void getImportersPostList(){

        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if(jsonObject.getString("result").equals("true")){

                        progressDialog.dismiss();
                    }else {
                        progressDialog.dismiss();

                        Toast.makeText(getActivity(), ""+jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    progressDialog.dismiss();

                    Toast.makeText(getActivity(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Toast.makeText(getActivity(), ""+error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String > map = new HashMap<>();
                map.put("user_id",session.getUser_Id());

                return map;

            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }

}