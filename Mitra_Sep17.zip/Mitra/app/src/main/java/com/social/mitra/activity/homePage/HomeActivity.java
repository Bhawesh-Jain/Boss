package com.social.mitra.activity.homePage;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_verify_profilestatus;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.social.mitra.MyrequirementsActivity;
import com.social.mitra.R;
import com.social.mitra.UI.HomeFragment;
import com.social.mitra.UI.MyWorksFragment;
import com.social.mitra.UI.NewsFragment;
import com.social.mitra.UI.ProfileFragment;
import com.social.mitra.UI.SearchFragment;
import com.social.mitra.activity.ContactUsActivity;
import com.social.mitra.activity.EditProfileActivity;
import com.social.mitra.activity.FeedBackActivity;
import com.social.mitra.activity.FragNavController;
import com.social.mitra.activity.MemberShipActivity;
import com.social.mitra.activity.MyProductActivity;
import com.social.mitra.activity.SearchActivity;
import com.social.mitra.activity.TermAndConditionActivity;
import com.social.mitra.adapter.LeftDrawerAdapter;
import com.social.mitra.fragments.MainFragment;
import com.social.mitra.fragments.ShareFragment;
import com.social.mitra.model.DrawerItem;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.FragmentHistory;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class HomeActivity extends AppCompatActivity implements FragNavController.TransactionListener, FragNavController.RootFragmentListener, HomeInterface {
    public static int close_drawer = 0;
    private final int[] mTabIconsSelected = {
            R.drawable.home_ic,
            R.drawable.search_img,
            R.drawable.add,
            R.drawable.heart,
            R.drawable.user_account};
    public BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {


        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:

                    Fragment fragment_home = new HomeFragment();
                    FragmentTransaction ft_home = getSupportFragmentManager().beginTransaction();
                    ft_home.replace(R.id.frame_content, fragment_home);
                    ft_home.commit();
                    return true;

                case R.id.search:
                    Fragment fragment_search = new SearchFragment();
                    FragmentTransaction ft_search = getSupportFragmentManager().beginTransaction();
                    ft_search.replace(R.id.frame_content, fragment_search);
                    ft_search.commit();
                    return true;

                case R.id.add:
                    Fragment fragment_my_work = new MyWorksFragment();
                    FragmentTransaction ft_add = getSupportFragmentManager().beginTransaction();
                    ft_add.replace(R.id.frame_content, fragment_my_work);
                    ft_add.commit();
                    return true;

                case R.id.notifi:
                    FragmentTransaction ft_notifi = getSupportFragmentManager().beginTransaction();

                    ft_notifi.replace(R.id.frame_content, new NewsFragment());
                    ft_notifi.commit();

                    return true;

                case R.id.profile:
                    FragmentTransaction ftrr = getSupportFragmentManager().beginTransaction();
//                    if(MTypee.equalsIgnoreCase("home_owner")){
//                        ftrr.replace(R.id.frame_content, new SignUp());
//                    }else {
                    ftrr.replace(R.id.frame_content, new ProfileFragment());
//                    }
                    ftrr.commit();
                    return true;
            }
            return false;
        }
    };
    public ArrayList<DrawerItem> List_Item = new ArrayList<>();
    public RelativeLayout ll_nav_header;
    public int ScreenPos = 0;


//    private void Get_Profile(String user_id)MTypee.equalsIgnoreCase("home_owner")
//String MTypee2 = "service_provider";
//    String MTypee3 = "material_supplier";ProfileFragment
//        {
//            Log.e(TAG, "ProfileFragment_Get_Profile: " );
//            ProgressDialog progressDialog = new ProgressDialog(HomeActivity.this);
//            progressDialog.show();
//
//
//            StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
//                @Override
//                public void onResponse(String response) {
//                    try {
//                        JSONObject jsonObject = new JSONObject(response);
//
//                        progressDialog.dismiss();
//                        Log.e(TAG, "onResponse: ProfileFragment_Get_Profile     "+ response);
//
//                        if (jsonObject.getString("result").equalsIgnoreCase("true")) {
//
//                            JSONObject data = jsonObject.getJSONObject("data");
//
//                            String User_id = data.getString("id");
//                            String First_name = data.getString("fname");
//                            String Last_name = data.getString("lname");
//                            String Mobile_ = data.getString("mobile");
//                            String TYPE = data.getString("type");
//                            String Imagee = data.getString("image");
//
//                            Log.e(TAG, "First_name: "+First_name);
//                            Log.e(TAG, "Last_name: "+Last_name);
//                            Log.e(TAG, "Mobile_: "+Mobile_);
//                            Log.e(TAG, "TYPE: "+TYPE);
//
//
//                            Glide.with(HomeActivity.this).load(User_image_Url).into(myprofile_img);
//
//                            NAME.setText(First_name);
//                            Type_user.setText(TYPE);
//
//
//
//
////                        Bundle simple_bundle=new Bundle();
////                        simple_bundle.putString("MOBILE",user_mobile);
////                        simple_bundle.putString("ID",User_id);
////                        simple_bundle.putString("OTP",user_otp);
//
//
//                        } else {
//                            progressDialog.dismiss();
//
//                        }
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                        progressDialog.dismiss();
//
//                    }
//                }
//            }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    progressDialog.dismiss();
//                    Toast.makeText(getActivity(), "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }) {
//                @Override
//                protected Map<String, String> getParams() throws AuthFailureError {
//
//                    Map<String, String> map = new HashMap<>();
//                    map.put("user_id",user_id);
////                map.put("fcm_id", "asdfhaiofhoa");
//                    Log.e(TAG, "--getParams:ProfileFragment "+map );
//                    return map;
//                }
//            };
//
//            VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
//
//        }
//
    String MTypee1 = "home_owner";
    String MTypee2 = "service_provider";
    String MTypee3 = "material_supplier";
    Session session;
    BottomNavigationView bottom_nav_view;
    TabLayout bottomTabLayout;
    LeftDrawerAdapter leftDrawerAdapter;
    ActionBarDrawerToggle mDrawerToggle;
    ListView mDrawerList;
    DrawerLayout mDrawerLayout;
    String[] TABS = {"Home", "Search", "Work ", "Notifications", "Profile"};
    ImageView drawer_icon, search_img;
    CircleImageView nav_img_profile;
    TextView nav_tv_name;
    FrameLayout contentFrame;
    Toolbar toolbar;
    DrawerItem drawerItem;
    String User_id;

    String MTypee;
    String prostatus = "0";
    String form_status = "1";
    FragmentTransaction ft_profile;
    String Pro_status = " ";
    String value;
    String verify_staus;
    String form_statuss = "1";
    private FragNavController mNavController;
    private FragmentHistory fragmentHistory;
    private boolean WorkFlag;

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_drawer_lay);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        bottomTabLayout = findViewById(R.id.bottom_tab_layout);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        search_img = findViewById(R.id.search_img);
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

        session = new Session(this);
        User_id = session.getUser_Id();

        String wTab = session.getValue("startWorkTab");

        if (getIntent() != null) {
            verify_staus = getIntent().getStringExtra("status_key");
//            form_statuss = getIntent().getStringExtra("form_status");
            MTypee = getIntent().getStringExtra("KeyType");
            Log.e(TAG, "----pro_status" + verify_staus);
            Log.e(TAG, "----pro_status" + form_statuss);
            if (getIntent().getStringExtra("NewPost") != null && getIntent().getStringExtra("NewPost").equalsIgnoreCase("true")){
                WorkFlag = true;
            }
        }

//        Log.e(TAG, "----MTypee"+MTypee);


//        Get_Verify_Profilestatus(User_id);

        contentFrame = findViewById(R.id.content_frame);
        mDrawerList = findViewById(R.id.left_drawer);
//        iv_drawer = findViewById(R.id.iv_drawer);
        toolbar = findViewById(R.id.toolbar);
        drawer_icon = findViewById(R.id.drawer_icon);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);

        toggle.syncState();


        View header = getLayoutInflater().inflate(R.layout.nav_header_activity_navigation, null);

        ll_nav_header = header.findViewById(R.id.ll_nav_header);
        nav_img_profile = header.findViewById(R.id.nav_img_profile);
        nav_tv_name = header.findViewById(R.id.nav_tv_name);

        mDrawerList.addHeaderView(header);


        Window window = getWindow();

        //clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        //add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        //finally change the color

        window.setStatusBarColor(ContextCompat.getColor(HomeActivity.this, R.color.appcolor));

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        initToolbar();

        bottom_nav_view = findViewById(R.id.bottom_nav_view);
        bottom_nav_view.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        if (WorkFlag)
            bottom_nav_view.setSelectedItemId(R.id.add);

        Fragment fragment_home = new HomeFragment();
        android.app.FragmentManager fragmentManager1 = getFragmentManager();
        FragmentTransaction ft_home = getSupportFragmentManager().beginTransaction();
        ft_home.replace(R.id.frame_content, fragment_home);
        ft_home.commit();


        if (wTab.equalsIgnoreCase("yes")){
            bottom_nav_view.setSelectedItemId(R.id.add);
            session.setValue("startWorkTab", "no");
        }


        search_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                startActivity(intent);
            }
        });


//        initTab();


//           mDrawerList.addHeaderView(header);

        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {

                    mDrawerLayout.closeDrawer(GravityCompat.START);
                } else {

                    mDrawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        DrawerItem();


        SetupDrawer();

//        getProfile(session.getUser_Id());

    /*
        fragmentHistory = new FragmentHistory();


        mNavController = FragNavController.newBuilder(savedInstanceState, getSupportFragmentManager(), R.id.content_frame)
                .transactionListener(this)
                .rootFragmentListener(this, TABS.length)
                .build();


        switchTab(0);

        bottomTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                fragmentHistory.push(tab.getPosition());

                switchTab(tab.getPosition());


            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

                mNavController.clearStack();

                switchTab(tab.getPosition());


            }
        });


      bottomTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
          @Override
          public void onTabSelected(TabLayout.Tab tab) {

              if(tab.getPosition()==3)
              {

              }

          }

          @Override
          public void onTabUnselected(TabLayout.Tab tab) {

          }

          @Override
          public void onTabReselected(TabLayout.Tab tab) {

          }
      });*/
//        setBadge();


     /*   new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                final Balloon balloon = new Balloon.Builder(HomeActivity.this)
                        .setArrowSize(10)
                        .setArrowOrientation(ArrowOrientation.TOP)
                        .setArrowPositionRules(ArrowPositionRules.ALIGN_ANCHOR)
                        .setArrowPosition(0.5f)
                        .setWidth(BalloonSizeSpec.WRAP)
                        .setHeight(65)
                        .setTextSize(15f)
                        .setLayout(R.layout.notification_badge_layout)
                        .setBackgroundColor(getColor(R.color.colorPrimary))
                        .setCornerRadius(7f)
                        .setAlpha(0.9f)
                        .setText("You can access your profile from now on.")
                        .setTextColor(ContextCompat.getColor(HomeActivity.this, R.color.white))
                        .setTextIsHtml(true)
                        .setOnBalloonInitializedListener(new OnBalloonInitializedListener() {
                            @Override
                            public void onBalloonInitialized(@NotNull View view) {

                                RelativeLayout follo_lay = view.findViewById(R.id.follo_lay);
                                RelativeLayout likes_lay = view.findViewById(R.id.likes_lay);
                                RelativeLayout comment_lay = view.findViewById(R.id.comment_lay);
                                TextView total_follow_notifi = view.findViewById(R.id.total_follow_notifi);
                                TextView total_like_notifi = view.findViewById(R.id.total_like_notifi);
                                TextView total_comment_notifi = view.findViewById(R.id.total_comment_notifi);


                            }
                        })
                        .setOnBalloonClickListener(new OnBalloonClickListener() {
                            @Override
                            public void onBalloonClick(@NotNull View view) {

                                *//*    FragmentManager fragmentManager = getSupportFragmentManager();
                                    fragmentManager.beginTransaction()
                                            .addToBackStack("Search")
                                            .replace(R.id.content_frame, new NewsFragment())
                                            .commit();*//*

                            }
                        })
                        .setBalloonAnimation(BalloonAnimation.FADE)
                        .setLifecycleOwner(new LifecycleOwner() {
                            @NonNull
                            @NotNull
                            @Override
                            public Lifecycle getLifecycle() {
                                return null;
                            }
                        })
                        .build();
                balloon.setOnBalloonOutsideTouchListener(new OnBalloonOutsideTouchListener() {
                    @Override
                    public void onBalloonOutsideTouch(@NotNull View view, @NotNull MotionEvent motionEvent) {

                        balloon.dismiss();


                    }
                });

                balloon.show(bottom_nav_view.getChildAt(0).findViewById(R.id.notifi));

            }
        }, 3000);

*/

    }


//    private void getProfile(String user_id) {
//
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//
//                        JSONObject data = jsonObject.getJSONObject("data");
//
//
//                    } else {
//
//
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//            }
//        }) {
//
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//
//                Map<String, String> map = new HashMap<>();
//                map.put("user_id", user_id);
//
//                return map;
//            }
//        };
//    }


    private void initToolbar() {
        setSupportActionBar(toolbar);


    }

    //    Drawer Item Array
    public void DrawerItem() {

        List_Item.clear();

        List_Item.add(new DrawerItem(R.drawable.edit, "Edit Profile", R.drawable.ic_expand));
//        List_Item.add(new DrawerItem(R.drawable.ic_baseline_search_24,"Search", R.drawable.ic_expand));
//        List_Item.add(new DrawerItem(R.drawable.checklists, "Post your requirements", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.my_product, "My Requirements", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.imports, "My Importers", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.member, "Become Member", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.feed, "Feedback", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.contact_us, "Contact Us", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.terms, "Terms  & Conditions", R.drawable.ic_expand));
        List_Item.add(new DrawerItem(R.drawable.ic_logout_24, "Logout", R.drawable.ic_expand));
    }


    //Navigation Drawer Method
    public void SetupDrawer() {
        //Drawer Adapter
        leftDrawerAdapter = new LeftDrawerAdapter(HomeActivity.this, List_Item);
        //Set Adapter
        mDrawerList.setAdapter(leftDrawerAdapter);

        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {

                if (pos != 0) {

                    int position = pos - 1;

                    SelectOption(position);
                } else if (pos == 0) {

                    mDrawerLayout.closeDrawer(mDrawerList);
                    ft_profile = getSupportFragmentManager().beginTransaction();
                    ft_profile.addToBackStack("profile");
//                    if(MTypee1.equalsIgnoreCase("home_owner")){
//                        ft_profile.replace(R.id.frame_content, new SignUp());
//                    }else {
                    ft_profile.replace(R.id.frame_content, new ProfileFragment());
//                    }
                    ft_profile.commit();
                    bottom_nav_view.setSelectedItemId(R.id.profile);
                }

            }
        });
    }

    private void Get_Verify_Profilestatus(String user_id) {
        Log.e(TAG, "***Get_Verify_Profilestatus: ");
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_verify_profilestatus, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, "onResponse:Get_Verify_Profilestatus" + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String User_id = data.getString("id");
                        String Form_Status = data.getString("form_status");
                        String Verify_Profile = data.getString("verify_profile");
                        Log.e(TAG, "Get_Verify_Profilestatus_idonResponse: " + User_id);
                        Log.e(TAG, "Form_Status_Get_Verify_Profilestatus_idonResponse: " + Form_Status);
                        Log.e(TAG, "Get_Verify_Profilestatus_idonResponse: " + Verify_Profile);
//                        Bundle simple_bundle=new Bundle();
//                        simple_bundle.putString("MOBILE",user_mobile);
//                        simple_bundle.putString("ID",User_id);
//                        simple_bundle.putString("OTP",user_otp);

//                        if(prostatus.equalsIgnoreCase(verify_staus)){
//                            FragmentManager fragmentManager = getSupportFragmentManager();
//                            fragmentManager.beginTransaction()
//                                    .addToBackStack("profile")
//                                    .replace(R.id.content_frame, new SignUp())
//                                    .commit();
//                        }else {
//                            FragmentManager fragmentManager = getSupportFragmentManager();
//                            fragmentManager.beginTransaction()
//                                    .addToBackStack("profile")
//                                    .replace(R.id.content_frame, new ProfileFragment())
//                                    .commit();
//
//                        }
                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(HomeActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "==getParams:getStatus_onResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }

    public void SelectOption(int pos) {
        ScreenPos = pos;
//        Selected Value Highlighted
        leftDrawerAdapter.setSelectedIndex(pos);
//        Get List Item
        drawerItem = List_Item.get(pos);
        Log.e("Position......", String.valueOf(pos));
        String Item_Name = drawerItem.getItemName();
        Log.e("Position......", drawerItem.getItemName());
//        Call Fragment on a listview click listner
//        Toast.makeText(this, ""+Item_Name, Toast.LENGTH_SHORT).show();
        if (Item_Name.equals("Edit Profile")) {
            Intent intent = new Intent(this, EditProfileActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            mDrawerLayout.closeDrawer(mDrawerList);

        } else if (Item_Name.equals("Search")) {
            Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
            Fragment fragment = new SearchFragment();
// Insert the fragment by replacing any existing fragment
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .addToBackStack("Search")
                    .replace(R.id.content_frame, new SearchFragment())
                    .commit();
            mDrawerLayout.closeDrawer(mDrawerList);
        } else if (Item_Name.equals("Contact Us")) {

            Intent intent = new Intent(this, ContactUsActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        } else if (Item_Name.equals("Terms  & Conditions")) {

            Intent intent = new Intent(this, TermAndConditionActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        } else if (Item_Name.equals("Feedback")) {

            Intent intent = new Intent(this, FeedBackActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        } else if (Item_Name.equals("My Importers")) {

            Intent intent = new Intent(this, MyProductActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        } /*else if (Item_Name.equals("Post your requirements")) {

            Intent intent = new Intent(this, RequiementPostActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        }*/ else if (Item_Name.equals("My Requirements")) {

            Intent intent = new Intent(this, MyrequirementsActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        } else if (Item_Name.equals("Become Member")) {

            Intent intent = new Intent(this, MemberShipActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            mDrawerLayout.closeDrawer(mDrawerList);

        } else if (Item_Name.equals("Logout")) {

            mDrawerLayout.closeDrawer(mDrawerList);

            new AlertDialog.Builder(HomeActivity.this)
                    .setTitle("Logout")
                    .setMessage("Do you want log out")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
//                            session.logout();
//                            logOut(session.getUser_Id());

                        }
                    }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).show();
        }


    }

//    private void logOut(String user_id) {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + logout, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//                    if (jsonObject.getString("result").equals("true")) {
//                        progressDialog.dismiss();
//                        session.logout();
//                    } else {
//                        progressDialog.dismiss();
//                        Toast.makeText(HomeActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//                    }
//                } catch (JSONException e) {
//                    progressDialog.dismiss();
//                    e.printStackTrace();
//                    Toast.makeText(HomeActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//                Toast.makeText(HomeActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> map = new HashMap<>();
//                map.put("user_id", user_id);
//                return map;
//            }
//        };
//
//        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
//    }
/*

    private void initTab() {

        if (bottomTabLayout != null) {
            for (int i = 0; i < TABS.length; i++) {
                bottomTabLayout.addTab(bottomTabLayout.newTab());
                TabLayout.Tab tab = bottomTabLayout.getTabAt(i);
                if (tab != null)
                    tab.setCustomView(getTabView(i));
            }
        }


    }


    private View getTabView(int position) {
        View view = LayoutInflater.from(HomeActivity.this).inflate(R.layout.tab_item_bottom, null);
        ImageView icon = view.findViewById(R.id.tab_icon);
        icon.setImageDrawable(Utils.setDrawableSelector(HomeActivity.this, mTabIconsSelected[position], mTabIconsSelected[position]));
        return view;
    }
*/


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {


            case android.R.id.home:


                onBackPressed();
                return true;
        }


        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onBackPressed() {
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_nav_view);
        int seletedItemId = bottomNavigationView.getSelectedItemId();
        if (R.id.home != seletedItemId) {
            setHomeItem(HomeActivity.this);
        } else {
            super.onBackPressed();
        }

    }

    private void setHomeItem(HomeActivity activity) {
        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                activity.findViewById(R.id.bottom_nav_view);
        bottomNavigationView.setSelectedItemId(R.id.home);
        getFragmentManager().getBackStackEntryCount();
    }

    private void updateTabSelection(int currentTab) {

        for (int i = 0; i < TABS.length; i++) {
            TabLayout.Tab selectedTab = bottomTabLayout.getTabAt(i);
            selectedTab.getCustomView().setSelected(currentTab == i);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mNavController != null) {
            mNavController.onSaveInstanceState(outState);
        }
    }

    @Override
    public void pushFragment(Fragment fragment) {
        if (mNavController != null) {
            mNavController.pushFragment(fragment);
        }
    }



/*
    private void setBadgeInCart(String count) {

        bottomTabLayout.setOnTabSelectedListener(mOnNavigationItemSelectedListener);

        BottomNavigationMenuView menuView = (BottomNavigationMenuView) bottomTabLayout.getChildAt(3);

        BottomNavigationItemView itemView = bottomNavigationView.findViewById(R.id.navigation_cart);
        notificationBadge = LayoutInflater.from(this).inflate(R.layout.badge_lay, menuView, false);


        TextView badge_count = notificationBadge.findViewById(R.id.badge_count);
        badge_count.setText(count);

        itemView.addView(notificationBadge);

    }*/


    private void updateToolbar() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(!mNavController.isRootFragment());
        getSupportActionBar().setDisplayShowHomeEnabled(!mNavController.isRootFragment());
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
    }


    @Override
    public void onFragmentTransaction(Fragment fragment, FragNavController.TransactionType transactionType) {
        //do fragmentty stuff. Maybe change title, I'm not going to tell you how to live your life
        // If we have a backstack, show the back button
        if (getSupportActionBar() != null && mNavController != null) {

            updateToolbar();

        }
    }


    @Override
    public Fragment getRootFragment(int index) {
        switch (index) {

            case FragNavController.TAB1:
                return new MainFragment();
            case FragNavController.TAB2:
                return new SearchFragment();
            case FragNavController.TAB3:
                return new ShareFragment();
            case FragNavController.TAB4:
                return new NewsFragment();
            case FragNavController.TAB5:
//                if(MTypee.equalsIgnoreCase("home_owner")){
//                    ft_profile.replace(R.id.frame_content, new SignUp());
//                }else {
                ft_profile.replace(R.id.frame_content, new ProfileFragment());

        }
        throw new IllegalStateException("Need to send an index that we know");
    }

    public void initToolbar(Toolbar toolbar, String title, boolean isBackEnabled) {

        setSupportActionBar(toolbar);

        if (isBackEnabled) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        }

        getSupportActionBar().setTitle(title);


    }

    public void initToolbar(Toolbar toolbar, boolean isBackEnabled) {
        setSupportActionBar(toolbar);

        if (isBackEnabled) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        }
    }

    private void switchTab(int position) {
        mNavController.switchTab(position);


//        updateToolbarTitle(position);
    }


    @Override
    public void onTabTransaction(Fragment fragment, int index) {

    }


    public void updateToolbarTitle(String title) {


        getSupportActionBar().setTitle(title);

    }

    @Override
    public void setWorkTab() {

    }
}