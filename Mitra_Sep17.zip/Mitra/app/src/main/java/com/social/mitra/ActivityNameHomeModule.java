package com.social.mitra;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_subcategory;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.adapter.InterestAdapter;
import com.social.mitra.interfa.Sub_item_click;
import com.social.mitra.model.SubCategoryModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ActivityNameHomeModule extends AppCompatActivity {

    ImageView back_name_home;
    EditText home_type_name;
    TextView Name_button;
    String MType;
    CardView list_btnn_;
    RecyclerView list_interest;
    Session session;
    String user_idd;
    ImageView back_interest;
    ArrayList<SubCategoryModel> subCategoryModelArrayList = new ArrayList<>();
    TextView txtdone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest);
        session = new Session(ActivityNameHomeModule.this);

        if (getIntent() != null) {
            MType = getIntent().getStringExtra("KeyType");
            Log.e(TAG, "----MType>>> " + MType);
        }
        user_idd = session.getUser_Id();

        list_btnn_ = findViewById(R.id.list_btnn_);
        list_interest = findViewById(R.id.list_interest);
        back_interest = findViewById(R.id.back_interest);
        txtdone = findViewById(R.id.txtdone);

        back_interest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Get_Subcategory(user_idd);
        list_btnn_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityNameHomeModule.this, HomeModuleActivity.class);
                intent.putExtra("KeyType", MType);
                startActivity(intent);
            }
        });
    }

    private void Get_Subcategory(String user_idd) {
        subCategoryModelArrayList.clear();
        Log.e(TAG, "Get_Sub_Category: ");
        ProgressDialog progressDialog = new ProgressDialog(ActivityNameHomeModule.this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_subcategory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObject1 = jsonObject.getJSONObject("category_status");

                    String status = jsonObject1.getString("signup_category_updated");
                    Log.e(TAG, ">>>>status: " + status);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        subCategoryModelArrayList.clear();
                        progressDialog.dismiss();
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Sub_Cate_id = dataObj.getString("id");
                            String Sub_cate_name = dataObj.getString("name");

                            SubCategoryModel subCategoryModel = new SubCategoryModel(Sub_Cate_id, Sub_cate_name);
                            subCategoryModelArrayList.add(subCategoryModel);
                        }
                        InterestAdapter interestAdapter = new InterestAdapter(ActivityNameHomeModule.this, subCategoryModelArrayList, new Sub_item_click() {
                            @Override
                            public void SubItemClick(SubCategoryModel item) {
                                item.getSub_cate_id();
//                                Toast.makeText(ActivityNameHomeModule.this, item.getSub_cate_id(), Toast.LENGTH_SHORT).show();
                                txtdone.setBackground(getResources().getDrawable(R.drawable.btn_accept_new_bg));
                            }
                        });

                        LinearLayoutManager layoutManager = new LinearLayoutManager(ActivityNameHomeModule.this, LinearLayoutManager.VERTICAL, false);
                        list_interest.setLayoutManager(layoutManager);
                        list_interest.setAdapter(interestAdapter);
                    } else {
                        Toast.makeText(ActivityNameHomeModule.this, "error1" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    Toast.makeText(ActivityNameHomeModule.this, "error2" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, error -> {
            progressDialog.dismiss();
            Toast.makeText(ActivityNameHomeModule.this, "error3" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_idd);

                return map;
            }
        };
        VolleySingleton.getInstance(ActivityNameHomeModule.this).addToRequestQueue(stringRequest);
    }
}