package com.social.mitra.activity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.social.mitra.R;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.sessionData.Session;

public class FeedBackActivity extends AppCompatActivity {

    ImageView back_img;
    TextView submit_feedback,countinue_tv;
    EditText your_title_edt, your_feed_back_edt;

    Session session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        back_img = findViewById(R.id.back_img);
        submit_feedback = findViewById(R.id.submit_feedback);
        your_title_edt = findViewById(R.id.your_title_edt);
        your_feed_back_edt = findViewById(R.id.your_feed_back_edt);
        session = new Session(this);

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        submit_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (your_title_edt.getText().toString().equals("")) {

                    your_title_edt.setFocusable(true);
                    your_title_edt.setError("Enter Feedback Title");
                } else {
                    if (your_feed_back_edt.getText().toString().equals("")) {

                        your_feed_back_edt.setFocusable(true);
                        your_feed_back_edt.setError("Enter Your Feedback");
                    } else {

//                        showFeedDialog();
//                        postfeedback();
                    }
                }
            }
        });

    }


//    private void postfeedback() {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + Feedback, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//                        progressDialog.dismiss();
//
//                        showFeedDialog();
//                        Toast.makeText(FeedBackActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        progressDialog.dismiss();
//
//                        Toast.makeText(FeedBackActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//                    }
//
//                } catch (JSONException e) {
//                    progressDialog.dismiss();
//
//                    e.printStackTrace();
//                    Toast.makeText(FeedBackActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                }
//
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//
//                Toast.makeText(FeedBackActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> map = new HashMap<>();
//
//                map.put("user_id", session.getUser_Id());
//                map.put("title", your_title_edt.getText().toString());
//                map.put("description", your_feed_back_edt.getText().toString());
//
//                return map;
//            }
//        };
//
//        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
//
//    }

    private void showFeedDialog() {

        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.feed_back_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(false);

        countinue_tv = dialog.findViewById(R.id.countinue_tv);

        countinue_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(FeedBackActivity.this,HomeActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);

                startActivity(intent);
                finish();
            }
        });

        dialog.show();
    }
}