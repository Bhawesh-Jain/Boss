package com.social.mitra.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.model.CityList;
import com.social.mitra.model.FilterModel;
import com.social.mitra.model.MainCatmodel;
import com.social.mitra.model.ProfessionalNameList;
import com.social.mitra.model.SubCatmodel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Professionalcat_postsAdapter extends RecyclerView.Adapter<Professionalcat_postsAdapter.MyViewHolder> {
    private static final String TAG = "ProfessionalCatAdapter";
    Context context;
    ArrayList<MainCatmodel> profileFollowersListModels = new ArrayList<>();
    ArrayList<SubCatmodel> review_subcatshowmodels = new ArrayList<>();
    SubcatdataproAdapter subcategoryRviewsAdapter;
    FilterModel model;
    boolean cityFlag = false;
    ArrayList<MainCatmodel> data = new ArrayList<>();


    public Professionalcat_postsAdapter(Context context, ArrayList<MainCatmodel> profileFollowersListModels, FilterModel model) {
        this.data.clear();
        this.profileFollowersListModels.clear();
        this.context = context;
        this.model = model;
        this.data = profileFollowersListModels;

        if (model != null && model.getCityNameLists().size() == 0 && model.getProfNameLists().size() == 0)
            this.model = null;

        if (this.model == null)
            this.profileFollowersListModels = profileFollowersListModels;
        if (this.model != null) {
            if (this.model.getCityNameLists().size() != 0) {
                cityFlag = true;
            }
            ArrayList<ProfessionalNameList> nameList = this.model.getProfNameLists();
            if (nameList.size() != 0) {
                for (int i = 0; i < nameList.size(); i++) {
                    String profName = nameList.get(i).getProfession_name();
                    for (int j = 0; j < data.size(); j++) {
                        if (data.get(j).getName().equalsIgnoreCase(profName))
                            data.get(j).setToAdd(true);
//                        Log.e(TAG, "onBindViewHolder: ProfileFollowName - " + profileFollowersListModels.get(j).getName() + " modelName - " + profName);
                    }
                }
                for (int i = 0; i < data.size(); i++) {
                    if (data.get(i).isToAdd())
                        this.profileFollowersListModels.add(data.get(i));
                }
            } else this.profileFollowersListModels = data;

            if (this.profileFollowersListModels.size() == 0)
                Toast.makeText(context, "No Match Found!", Toast.LENGTH_SHORT).show();
        }
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.row_, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if (profileFollowersListModels.size() > 0) {

            // Glide.with(context).load(ImageUrl + profileFollowersListModels.get(position).getImage()).into(holder.img);
            review_subcatshowmodels.clear();

            for (int i = 0; i < profileFollowersListModels.get(position).getJsonArray().length(); i++) {
                Log.e("TAG", "onBindViewHolder: " + profileFollowersListModels.get(position).getJsonArray().length());
                JSONObject scat = null;
                try {
                    scat = profileFollowersListModels.get(position).getJsonArray().getJSONObject(i);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (scat != null)
                    try {
                        SubCatmodel review_subcatshowmodel = new SubCatmodel
                                (scat.getString("user_id"),
                                        scat.getString("user_name"),
                                        scat.getString("user_image"),
                                        scat.getString("category_name"),
                                        scat.getString("post_counts"),
                                        scat.getString("followers_count"),
                                        scat.getString("following_count"),
                                        scat.getString("city_name")
                                );
                        if (cityFlag) {
                            ArrayList<CityList> cityNameLists = model.getCityNameLists();
                            for (int j = 0; j < cityNameLists.size(); j++) {
                                if (review_subcatshowmodel.getCity_name().equalsIgnoreCase(cityNameLists.get(j).getCityName()))
                                    review_subcatshowmodels.add(review_subcatshowmodel);
                            }
                        } else review_subcatshowmodels.add(review_subcatshowmodel);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
            }
            holder.linearLayout.setVisibility(View.VISIBLE);
            if (review_subcatshowmodels.size() != 0)
                holder.txtcat.setText(profileFollowersListModels.get(position).getName());
            else holder.linearLayout.setVisibility(View.GONE);

            RecyclerView.LayoutManager mLayoutManger = new LinearLayoutManager(context);
            holder.rvsubcat.setLayoutManager(mLayoutManger);
            holder.rvsubcat.setLayoutManager(new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false));

            subcategoryRviewsAdapter = new SubcatdataproAdapter(context, review_subcatshowmodels);
            holder.rvsubcat.setAdapter(subcategoryRviewsAdapter);

            subcategoryRviewsAdapter.notifyDataSetChanged();

        } else Toast.makeText(context, "No Match Found", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int getItemCount() {
        return profileFollowersListModels.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtcat;
        LinearLayout linearLayout;
        RecyclerView rvsubcat;

        public MyViewHolder(View itemView) {
            super(itemView);

            linearLayout = itemView.findViewById(R.id.ll_body);
            txtcat = itemView.findViewById(R.id.txtcat);
            rvsubcat = itemView.findViewById(R.id.rvsubcat);


        }
    }

}
