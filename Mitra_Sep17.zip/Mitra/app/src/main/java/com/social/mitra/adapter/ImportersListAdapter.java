package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.model.ImportersListModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class ImportersListAdapter extends RecyclerView.Adapter<ImportersListAdapter.MyViewHolder> {

    Context context;
    ArrayList<ImportersListModel> importersListModels;

    public ImportersListAdapter(Context context, ArrayList<ImportersListModel> importersListModels) {
        this.context = context;
        this.importersListModels = importersListModels;
    }

    @NonNull
    @NotNull
    @Override
    public ImportersListAdapter.MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.importers_list_lay, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ImportersListAdapter.MyViewHolder holder, int position) {


        if (importersListModels.size() > 0) {

        }
    }

    @Override
    public int getItemCount() {
        return importersListModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView country_name_tv, post_date_tv, require_speci_tv, quantity_tv, post_of_discharge_tv;
        ImageView user_flag_img;
        Button interasted_btn;

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            country_name_tv = itemView.findViewById(R.id.country_name_tv);
            post_date_tv = itemView.findViewById(R.id.post_date_tv);
            require_speci_tv = itemView.findViewById(R.id.require_speci_tv);
            quantity_tv = itemView.findViewById(R.id.quantity_tv);
            post_of_discharge_tv = itemView.findViewById(R.id.post_of_discharge_tv);
            user_flag_img = itemView.findViewById(R.id.user_flag_img);
            interasted_btn = itemView.findViewById(R.id.interasted_btn);


        }

    }
}
