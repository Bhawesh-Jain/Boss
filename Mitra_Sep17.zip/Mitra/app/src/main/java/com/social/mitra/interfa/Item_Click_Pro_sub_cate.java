package com.social.mitra.interfa;

import com.social.mitra.model.ProfessionalSubCateList;

public interface Item_Click_Pro_sub_cate {

    void ItemSubCateClick(ProfessionalSubCateList subItem,ProfessionalSubCateList name);
}


