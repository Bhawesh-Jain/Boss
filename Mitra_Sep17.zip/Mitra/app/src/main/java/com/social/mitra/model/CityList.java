package com.social.mitra.model;

public class CityList {
    String CityID,CityName,CityImage;

    public CityList(String cityID, String cityName ) {
        CityID = cityID;
        CityName = cityName;

    }

    public String getCityID() {
        return CityID;
    }

    public void setCityID(String cityID) {
        CityID = cityID;
    }

    public String getCityName() {
        return CityName;
    }

    public void setCityName(String cityName) {
        CityName = cityName;
    }

    public String getCityImage() {
        return CityImage;
    }

    public void setCityImage(String cityImage) {
        CityImage = cityImage;
    }
}
