package com.social.mitra.activity;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_folloing_userslist;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;
import com.social.mitra.adapter.FollowingListAdapter;
import com.social.mitra.model.FollowersListModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AllFollowingActivity extends AppCompatActivity {
    private static final String TAG = AllFollowingActivity.class.getSimpleName();
    ImageView back_img;
    TextView send_tv;
    CardView progress_card;
    int flag = 0;
    Session session;
    RecyclerView rv_folowing;
    ArrayList<FollowersListModel> followersListModels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_following);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        session = new Session(this);
        back_img = findViewById(R.id.back_img);
        send_tv = findViewById(R.id.send_tv);
        rv_folowing = findViewById(R.id.rv_folowing);

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        getAllFollowings();
    }

    private void getAllFollowings() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_folloing_userslist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "onResponse:get_folloing_userslist     " + response);
                    if (jsonObject.getString("result").equals("true")) {
                        if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject dataObj = jsonArray.getJSONObject(i);

                                String id_ID = dataObj.getString("id");
                                String _name = dataObj.getString("name");
                                String image = dataObj.getString("image");

                                FollowersListModel followersListModel = new FollowersListModel(id_ID, _name, image);
                                followersListModels.add(followersListModel);
                            }
                            FollowingListAdapter followersListAdapter = new FollowingListAdapter(AllFollowingActivity.this, followersListModels);

                            LinearLayoutManager layoutManager = new LinearLayoutManager(AllFollowingActivity.this, LinearLayoutManager.VERTICAL, false);
                            rv_folowing.setLayoutManager(layoutManager);
                            rv_folowing.setAdapter(followersListAdapter);
                        }
                    }
                } catch (JSONException e) {
                    Toast.makeText(AllFollowingActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(AllFollowingActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", session.getUser_Id());
                return map;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}