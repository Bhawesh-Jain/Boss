package com.social.mitra;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.adapter.MCateListSAdapter;
import com.social.mitra.interfa.MaterialCateClick;
import com.social.mitra.model.MaterialCateList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_main_category;
import static com.social.mitra.util.BaseUrl.get_second_category;

public class MaterialProfessionalCateListActivity extends AppCompatActivity {

    ArrayList<MaterialCateList> materialCateListArrayList = new ArrayList<>();
    MCateListSAdapter mCateListSAdapter;
    RecyclerView mATERIAL_cate_recycler;
    Button Mcate_BUTTON_NEXT;
    ImageView back_mat_cate;
    EditText material_search;
    String city_name;
    String Category_name;
    String user_id;
    String cate_status;
    Session session;
    RelativeLayout LayoutMListCate_Progress;
    String MTyPe = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material_cate);
        session = new Session(MaterialProfessionalCateListActivity.this);
        mATERIAL_cate_recycler = findViewById(R.id.mATERIAL_cate_recycler);
        Mcate_BUTTON_NEXT = findViewById(R.id.Mcate_BUTTON_NEXT);
        back_mat_cate = findViewById(R.id.back_mat_cate);
        material_search = findViewById(R.id.material_search);
        LayoutMListCate_Progress = findViewById(R.id.LayoutMListCate_Progress);

        back_mat_cate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        user_id = session.getUser_Id();

        if (getIntent() != null) {
            city_name = getIntent().getStringExtra("LOC");
            MTyPe = getIntent().getStringExtra("KeyType");
            Log.e(TAG, "ProfessionalCategoryList_city_name: " + city_name);
            Log.e(TAG, "=====MTyPe: " + MTyPe);

        }

        Get_Main_Category(user_id);


        /*
        Mcate_BUTTON_NEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MaterialProfessionalCateListActivity.this, MaterialProfileCreationActivity.class);
                intent.putExtra("LOC",city_name);
                intent.putExtra("KeyType",MTyPe);
                intent.putExtra("KEYMcate",Category_name);
//                Log.e(TAG, "===INSIDEonClick: "+city_name);
//                intent.putExtra("cate_name",Category_name);
                startActivity(intent);
                finish();

            }
        });
        */

    }

    private void Get_Main_Category(String user_id) {
        Log.e(TAG, "***Get_Second_Category: ");
        LayoutMListCate_Progress.setVisibility(View.VISIBLE);
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_main_category, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "==onResponse:Get_Mat_Category" + response);
                    LayoutMListCate_Progress.setVisibility(View.GONE);
//                    progressDialog.dismiss();category_status

                    JSONObject jsonObjec = jsonObject.getJSONObject("category_status");

                    String MCate_status = jsonObjec.getString("second_category_updated");

                    Log.e(TAG, "===MCate_status: " + MCate_status);

                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String MCate_ID = dataObj.getString("id");

                            String MCate_name = dataObj.getString("name");

                            String MCate_image = dataObj.getString("image");

                            MaterialCateList materialCateList = new MaterialCateList(MCate_ID, MCate_name, MCate_image);

                            materialCateListArrayList.add(materialCateList);

                            Log.e(TAG, "onResponse: "+materialCateList.getMCate_name());
                        }

                        MCateListSAdapter mCateListSAdapter1 = new MCateListSAdapter(materialCateListArrayList, MaterialProfessionalCateListActivity.this, new MaterialCateClick() {
                            @Override
                            public void MCateClick(MaterialCateList CateIdClicked, MaterialCateList cateName) {
                                CateIdClicked.getMCate_Id();
                                Toast.makeText(MaterialProfessionalCateListActivity.this, CateIdClicked.getMCate_Id(), Toast.LENGTH_SHORT).show();
                                cateName.getMCate_name();
                                Category_name = cateName.getMCate_name();
                                Log.e(TAG, "_____Category_name: " + Category_name);

                                Mcate_BUTTON_NEXT.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(MaterialProfessionalCateListActivity.this, MaterialProfileCreationActivity.class);
                                        intent.putExtra("LOC", city_name);
                                        intent.putExtra("KeyType", MTyPe);
                                        intent.putExtra("KEYMcate", Category_name);
//                Log.e(TAG, "===INSIDEonClick: "+city_name);
//                intent.putExtra("cate_name",Category_name);
                                        startActivity(intent);
                                        finish();

                                    }
                                });
                            }
                        });

                        LinearLayoutManager layoutManager = new LinearLayoutManager(MaterialProfessionalCateListActivity.this, LinearLayoutManager.VERTICAL, false);
                        mATERIAL_cate_recycler.setLayoutManager(layoutManager);
                        mATERIAL_cate_recycler.setAdapter(mCateListSAdapter1);


                    } else {
                        LayoutMListCate_Progress.setVisibility(View.GONE);
//                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    LayoutMListCate_Progress.setVisibility(View.GONE);
//                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                LayoutMListCate_Progress.setVisibility(View.GONE);
//                progressDialog.dismiss();
                Toast.makeText(MaterialProfessionalCateListActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("type", MTyPe);
                Log.e(TAG, "getParams: " + map);
                return map;
            }
        };


        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }

}
