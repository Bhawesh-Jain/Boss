package com.social.mitra.fragments;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_community;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.social.mitra.ActivityNewPost;
import com.social.mitra.R;
import com.social.mitra.adapter.JobDiscAdapter;
import com.social.mitra.adapter.WorkJobAdapter;
import com.social.mitra.model.JobDataList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class
JobDiscussionFragment extends Fragment {
    private final String TAG = "JobDiscussionFragment";

    FloatingActionButton BUTTON_FLOATING;
    RecyclerView recycler_discussion;
    ArrayList<JobDataList> jobDataListArrayList = new ArrayList<>();
    String _liked;
    String _like_count;
    String _comment_count;
    RelativeLayout __Job_List_Progress;
    Session session;
    String Community_id;
    String USER_IDD;
    String Type = "discussion";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_job_discussion, container, false);

        session = new Session(getContext());
        USER_IDD = session.getUser_Id();
        Log.e(TAG, "--USER_IDD_JobDiscussionFragment: " + USER_IDD);
        BUTTON_FLOATING = root.findViewById(R.id.BUTTON_FLOATING);
        recycler_discussion = root.findViewById(R.id.recycler_discussion);
        __Job_List_Progress = root.findViewById(R.id.__Job_List_Progress);

        _Get_Community(USER_IDD, Type);

        BUTTON_FLOATING.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), ActivityNewPost.class);
            startActivity(intent);
        });
        return root;
    }

    private void _Get_Community(String user_idd, String type) {

        __Job_List_Progress.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "onResponse:get_community  ");
                    __Job_List_Progress.setVisibility(View.GONE);

                    String community_path = jsonObject.getString("community_path");
                    String user_path = jsonObject.getString("user_path");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        jobDataListArrayList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            Community_id = dataObj.getString("id");
                            String id_ID = dataObj.getString("user_id");
                            String _name = dataObj.getString("name");
                            String _image = dataObj.getString("user_image");
                            String _required = dataObj.getString("required");
                            String _description = dataObj.getString("description");
                            String usertype = dataObj.getString("usertype");
                            String _created_date = dataObj.getString("created_date");
                            String _ago_time = dataObj.getString("ago_time");
                            Log.e(TAG, "+++++_ago_time: " + _ago_time);
                            String _community_image = dataObj.getString("community_image");
                            _liked = dataObj.getString("liked");
                            _like_count = dataObj.getString("like_count");
                            _comment_count = dataObj.getString("comment_count");
                            String city_name = dataObj.getString("city_name");

                            String is_phone = dataObj.getString("is_phone");
                            String post_user_category = dataObj.getString("post_user_category");
                            String user_mobile = dataObj.getString("user_mobile");

                            JobDataList jobDataList = new JobDataList(
                                    Community_id,
                                    id_ID,
                                    _name,
                                    _image,
                                    _required,
                                    _description,
                                    _community_image,
                                    _created_date,
                                    _ago_time,
                                    _liked,
                                    _like_count,
                                    _comment_count,
                                    city_name,
                                    usertype,
                                    is_phone,
                                    post_user_category,
                                    user_mobile
                            );
                            jobDataList.setUser_path(user_path);
                            jobDataListArrayList.add(jobDataList);
                        }
                        JobDiscAdapter jobDiscAdapter = new JobDiscAdapter(jobDataListArrayList, getActivity(), community_path);

                        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
                        recycler_discussion.setLayoutManager(layoutManager);
                        recycler_discussion.setAdapter(jobDiscAdapter);
                    } else {
                        __Job_List_Progress.setVisibility(View.GONE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    __Job_List_Progress.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                __Job_List_Progress.setVisibility(View.GONE);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_idd);
                map.put("type", type);
                map.put("fcm_id", "fcm_id");
                Log.e(TAG, "getParams:  " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (session.getValue("firstTime").equalsIgnoreCase("false")) {
            _Get_Community(USER_IDD, Type);
            session.setValue("firstTime", "true");
        }
    }
}