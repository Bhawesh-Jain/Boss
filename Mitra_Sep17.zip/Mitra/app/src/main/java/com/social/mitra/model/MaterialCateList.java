package com.social.mitra.model;

public class MaterialCateList {

    String MCate_Id,MCate_name,MCate_image;

    public MaterialCateList(String MCate_Id, String MCate_name, String MCate_image) {
        this.MCate_Id = MCate_Id;
        this.MCate_name = MCate_name;
        this.MCate_image = MCate_image;
    }

    public String getMCate_Id() {
        return MCate_Id;
    }

    public void setMCate_Id(String MCate_Id) {
        this.MCate_Id = MCate_Id;
    }

    public String getMCate_name() {
        return MCate_name;
    }

    public void setMCate_name(String MCate_name) {
        this.MCate_name = MCate_name;
    }

    public String getMCate_image() {
        return MCate_image;
    }

    public void setMCate_image(String MCate_image) {
        this.MCate_image = MCate_image;
    }
}
