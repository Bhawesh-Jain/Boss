package com.social.mitra.model;

public class ProfessionalSubCateList {
    String Professional_sub_ID,Professional_sub_Name;

    public ProfessionalSubCateList(String professional_sub_ID, String professional_sub_Name) {
        Professional_sub_ID = professional_sub_ID;
        Professional_sub_Name = professional_sub_Name;
    }

    public String getProfessional_sub_ID() {
        return Professional_sub_ID;
    }

    public void setProfessional_sub_ID(String professional_sub_ID) {
        Professional_sub_ID = professional_sub_ID;
    }

    public String getProfessional_sub_Name() {
        return Professional_sub_Name;
    }

    public void setProfessional_sub_Name(String professional_sub_Name) {
        Professional_sub_Name = professional_sub_Name;
    }
}
