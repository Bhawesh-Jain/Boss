package com.social.mitra.UI;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.social.mitra.R;
import com.social.mitra.fragments.DesignIndeFragment;
import com.social.mitra.fragments.MaterialSuppliRFragment;
import com.social.mitra.fragments.ProfessionalFragment;

public class SearchFragment extends Fragment {
    private static final String TAG = "Search_fragment";
    TabLayout tabLayout;
    ViewPager viewPager;
    String userid,get_user_id;
    TextView tv_dr_list,tv_dr_map,tv_dr_sup;
    View root;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View root = inflater.inflate(R.layout.fragment_search, container, false);

        tv_dr_list = root.findViewById(R.id.tv_dr_list);
        tv_dr_map= root.findViewById(R.id.tv_dr_map);
        tv_dr_sup= root.findViewById(R.id.tv_dr_sup);

        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frame_layout, new DesignIndeFragment());
        ft.commit();

        tv_dr_list.setBackground(getResources().getDrawable(R.drawable.selection_bottom_line_bg));
        tv_dr_map.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
        tv_dr_sup.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));

        tv_dr_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_layout, new DesignIndeFragment());
                ft.commit();

                tv_dr_list.setBackground(getResources().getDrawable(R.drawable.selection_bottom_line_bg));
                tv_dr_map.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
                tv_dr_sup.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
            }
        });
        tv_dr_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_layout, new ProfessionalFragment());
                ft.commit();

                tv_dr_map.setBackground(getResources().getDrawable(R.drawable.selection_bottom_line_bg));
                tv_dr_list.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
                tv_dr_sup.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
            }
        });
        tv_dr_sup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_layout, new MaterialSuppliRFragment());
                ft.commit();

                tv_dr_sup.setBackground(getResources().getDrawable(R.drawable.selection_bottom_line_bg));
                tv_dr_list.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
                tv_dr_map.setBackground(getResources().getDrawable(R.drawable.edittext_bottom_line));
            }
        });
        return root;
    }


    /*....................replaceFragment()....................................*/
    @SuppressLint("WrongConstant")
    public void replaceFragment(Fragment fragment, boolean addToBackStack, int containerId) {
        String backStackName = fragment.getClass().getName();
        FragmentManager fm = getActivity().getSupportFragmentManager();
        int i = fm.getBackStackEntryCount();
        while (i > 0) {
            fm.popBackStackImmediate();
            i--;
        }
        boolean fragmentPopped = getFragmentManager().popBackStackImmediate(backStackName, 0);
        if (!fragmentPopped) {
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(containerId, fragment, backStackName).setTransition(FragmentTransaction.TRANSIT_UNSET);
            if (addToBackStack)
                transaction.addToBackStack(backStackName);
            transaction.commit();
        }
}}