package com.social.mitra.adapter;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.followUnfollow;
import static com.social.mitra.util.BaseUrl.like_reel;
import static com.social.mitra.util.BaseUrl.report_reel_post;
import static com.social.mitra.util.Utils.getRandomColor;
import static com.social.mitra.util.Utils.share;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.jarvanmo.exoplayerview.media.SimpleMediaSource;
import com.jarvanmo.exoplayerview.ui.ExoVideoView;
import com.social.mitra.R;
import com.social.mitra.activity.CommentActivity;
import com.social.mitra.model.ReelModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeReelAdapter extends RecyclerView.Adapter<HomeReelAdapter.ViewHolder> {
    private final ArrayList<ReelModel> reelList;
    private final Context context;
    private final String TAG = "HomeReelAdapter";
    private final Session session;
    public ExoVideoView videoView;

    public HomeReelAdapter(ArrayList<ReelModel> reelList, Context context) {
        this.reelList = reelList;
        this.context = context;
        session = new Session(context);
    }


    @Override
    public void onDetachedFromRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);
        videoView.releasePlayer();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.home_post_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (reelList != null && reelList.size() > 0) {
            ReelModel currentReel = reelList.get(position);

            holder.post_date_time.setText(currentReel.getUpdated_date());
            holder.user_text_message.setText(currentReel.getDescription());
            holder.user_name.setText(currentReel.getName());
            holder.user_position.setText(currentReel.getCity_name());
            holder.total_likes.setText(String.valueOf(currentReel.getLike_count()));
            holder.total_comment.setText(String.valueOf(currentReel.getComment_count()));
            holder.report_abuse_img.setOnClickListener(view -> dialog(currentReel.getId(), currentReel.getUser_id()));

            if (currentReel.getI_liked() == 1) {
                holder.like_img.setImageResource(R.drawable.like_heart_icon);
            } else holder.like_img.setImageResource(R.drawable.empty_heart);

            if (currentReel.getI_followed() == 1) {
                holder.i_followed.setText("Following");
            } else holder.i_followed.setText("Follow");

            holder.i_followed.setOnClickListener(view -> followUnfollow(session.getUser_Id(), currentReel.getUser_id(), holder.i_followed));

            String myChar = "";

            if (!currentReel.getUser_image().equalsIgnoreCase("")) {
                Glide.with(context).load(currentReel.getUser_path() + currentReel.getUser_image()).into(holder.user_image);
                holder.user_image_card.setVisibility(View.GONE);
            } else {
                if (!currentReel.getName().equalsIgnoreCase(""))
                    myChar = Character.toString(currentReel.getName().charAt(0));
                holder.user_image_txt.setText(myChar.toUpperCase());
                holder.user_image_card.setCardBackgroundColor(getRandomColor());
            }

            if (currentReel.getType().equalsIgnoreCase("video")) {
                holder.post_image.setVisibility(View.GONE);
                holder.only_text_message.setVisibility(View.GONE);
                holder.post_image_slider.setVisibility(View.GONE);
                holder.post_image_slider_cardview.setVisibility(View.GONE);
                holder.card_video.setVisibility(View.VISIBLE);

                SimpleMediaSource mediaSource = new SimpleMediaSource(currentReel.getReel_path() + currentReel.getFile());
                Log.e(TAG, "onBindViewHolder: Url" + currentReel.getReel_path() + currentReel.getFile());
                videoView.hideController();
                videoView.setControllerAutoShow(true);
                videoView.setUseController(true);
                videoView.changeWidgetVisibility(R.id.exo_player_controller_back, View.VISIBLE);

                videoView.play(mediaSource);

            } else if (currentReel.getType().equalsIgnoreCase("image")) {
                holder.card_video.setVisibility(View.GONE);
                holder.only_text_message.setVisibility(View.GONE);

                ArrayList<SlideModel> slideModels = new ArrayList<>();
                for (int i = 0; i < 10; i++) {
                    SlideModel model = null;
                    if (i == 0) if (!currentReel.getFile().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getFile(), ScaleTypes.CENTER_INSIDE);
                    if (i == 1) if (!currentReel.getImage_2().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_2(), ScaleTypes.CENTER_INSIDE);
                    if (i == 2) if (!currentReel.getImage_3().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_3(), ScaleTypes.CENTER_INSIDE);
                    if (i == 3) if (!currentReel.getImage_4().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_4(), ScaleTypes.CENTER_INSIDE);
                    if (i == 4) if (!currentReel.getImage_5().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_5(), ScaleTypes.CENTER_INSIDE);
                    if (i == 5) if (!currentReel.getImage_6().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_6(), ScaleTypes.CENTER_INSIDE);
                    if (i == 6) if (!currentReel.getImage_7().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_7(), ScaleTypes.CENTER_INSIDE);
                    if (i == 7) if (!currentReel.getImage_8().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_8(), ScaleTypes.CENTER_INSIDE);
                    if (i == 8) if (!currentReel.getImage_9().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_9(), ScaleTypes.CENTER_INSIDE);
                    if (i == 9) if (!currentReel.getImage_10().equalsIgnoreCase("")) model = new SlideModel(currentReel.getReel_path() + currentReel.getImage_10(), ScaleTypes.CENTER_INSIDE);

                    if (model != null) slideModels.add(model);
                }

                if (slideModels.size() > 1) {
                    holder.post_image_slider.setVisibility(View.VISIBLE);
                    holder.post_image.setVisibility(View.GONE);
                    holder.post_image_slider_cardview.setVisibility(View.VISIBLE);
                    holder.post_image_slider.setImageList(slideModels);
                } else {
                    holder.post_image.setVisibility(View.VISIBLE);
                    holder.post_image_slider.setVisibility(View.GONE);
                    holder.post_image_slider_cardview.setVisibility(View.GONE);
                    Glide.with(context).load(currentReel.getReel_path() + currentReel.getFile()).into(holder.post_image);
                }
            } else if (currentReel.getType().equalsIgnoreCase("text")) {
                holder.card_video.setVisibility(View.GONE);
                holder.post_image.setVisibility(View.GONE);
                holder.post_image_slider_cardview.setVisibility(View.GONE);
                holder.post_image_slider.setVisibility(View.GONE);
                holder.only_text_message.setVisibility(View.VISIBLE);

                holder.only_text_message.setText(currentReel.getImage_text());

                if (currentReel.getTextColor().equalsIgnoreCase("blue")) {
                    holder.only_text_message.setBackgroundColor(context.getResources().getColor(R.color.light_blue_ap));
                } else if (currentReel.getTextColor().equalsIgnoreCase("red")) {
                    holder.only_text_message.setBackgroundColor(context.getResources().getColor(R.color.red_ap));
                } else if (currentReel.getTextColor().equalsIgnoreCase("green")) {
                    holder.only_text_message.setBackgroundColor(context.getResources().getColor(R.color.green_ap));
                } else if (currentReel.getTextColor().equalsIgnoreCase("purple")) {
                    holder.only_text_message.setBackgroundColor(context.getResources().getColor(R.color.purple_ap));
                } else if (currentReel.getTextColor().equalsIgnoreCase("yellow")) {
                    holder.only_text_message.setBackgroundColor(context.getResources().getColor(R.color.yellow_ap));
                }
            }

            holder.like_img_lay.setOnClickListener(view -> likeReel(currentReel.getId(), session.getUser_Id(), currentReel, holder.like_img, holder.total_likes));
            holder.share_img_lay.setOnClickListener(view -> {
                if (currentReel.getType().equalsIgnoreCase("text"))
                    share(currentReel.getDescription(), context);
                else share(currentReel.getDescription(), holder.post_image, context);
            });
            holder.comment_img_lay.setOnClickListener(view -> {
                Intent intent = new Intent(context, CommentActivity.class);
                intent.putExtra("reel_id", currentReel.getId());
                context.startActivity(intent);
            });
        }
    }

    private void dialog(String reel_id, String user_id) {
        Dialog dialogView = new Dialog(context);
        dialogView.setContentView(R.layout.dialog_postoptions);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView report_post, promotional_post, spam_post;

        report_post = dialogView.findViewById(R.id.report_post);
        promotional_post = dialogView.findViewById(R.id.promotional_post);
        spam_post = dialogView.findViewById(R.id.spam_post);

        report_post.setOnClickListener(view -> {
            reportPost(report_post.getText().toString(), reel_id, user_id);
            dialogView.dismiss();
        });
        promotional_post.setOnClickListener(view -> {
            reportPost(promotional_post.getText().toString(), reel_id, user_id);
            dialogView.dismiss();
        });
        spam_post.setOnClickListener(view -> {
            reportPost(spam_post.getText().toString(), reel_id, user_id);
            dialogView.dismiss();
        });

        dialogView.show();
    }

    private void followUnfollow(String user_id, String Id, TextView btn) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + followUnfollow, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equals("true")) {
                        if (jsonObject.getString("msg").equals("Followed")) {
                            btn.setText("Following");
                        } else {
                            btn.setText("Follow");
                        }
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("to_user_id", Id);
                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    private void reportPost(String type, String reel_id, String user_id) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + report_reel_post, response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                Log.d(TAG, "reportPost onResponse() called with: response = [" + response + "]");
                Toast.makeText(context, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> Log.e(TAG, "reportPost: ", error)) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", user_id);
                map.put("reel_id", reel_id);
                map.put("report", type);

                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    private void likeReel(String reelId, String user_id, ReelModel currentReel, ImageView image, TextView likeCount) {
        Log.d(TAG, "likeReel() called with: reelId = [" + reelId + "], user_id = [" + user_id + "]");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + like_reel, response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                Log.d(TAG, "onResponse() called with: response = [" + response + "]");
                if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                    if (jsonObject.getString("msg").equalsIgnoreCase("Liked")) {
                        currentReel.setI_liked(1);
                        currentReel.setLike_count(currentReel.getLike_count() + 1);
                        image.setImageResource(R.drawable.like_heart_icon);
                    } else {
                        currentReel.setI_liked(0);
                        currentReel.setLike_count(currentReel.getLike_count() - 1);
                        image.setImageResource(R.drawable.empty_heart);
                    }
                    likeCount.setText(String.valueOf(currentReel.getLike_count()));
                } else {
                    Toast.makeText(context, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> Log.e(TAG, "likeReel: error", error)) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();

                map.put("user_id", user_id);
                map.put("reel_id", reelId);

                return map;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    @Override
    public int getItemCount() {
        if (reelList != null)
            return reelList.size();
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView post_date_time, user_image_txt, total_likes, total_comment, user_position, user_name, user_text_message, only_text_message, i_followed;
        CardView card_video, user_image_card, post_image_slider_cardview;
        CircleImageView user_image;
        ImageView post_image;
        ImageView like_img, comment_img, report_abuse_img;
        LinearLayout share_img_lay, comment_img_lay, like_img_lay;
        ImageSlider post_image_slider;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            post_date_time = itemView.findViewById(R.id.post_date_time);
            user_image_txt = itemView.findViewById(R.id.user_image_txt);
            total_likes = itemView.findViewById(R.id.total_likes);
            total_comment = itemView.findViewById(R.id.total_comment);
            user_position = itemView.findViewById(R.id.user_position);
            user_name = itemView.findViewById(R.id.user_name);
            user_text_message = itemView.findViewById(R.id.user_text_message);
            only_text_message = itemView.findViewById(R.id.only_text_message);
            i_followed = itemView.findViewById(R.id.i_followed);

            like_img = itemView.findViewById(R.id.delete_img);
            comment_img = itemView.findViewById(R.id.comment_img);
            report_abuse_img = itemView.findViewById(R.id.report_abuse_img);

            post_image = itemView.findViewById(R.id.post_image);

            videoView = itemView.findViewById(R.id.videoView);

            post_image_slider = itemView.findViewById(R.id.post_image_slider);

            card_video = itemView.findViewById(R.id.card_video);
            user_image_card = itemView.findViewById(R.id.user_image_card);
            post_image_slider_cardview = itemView.findViewById(R.id.post_image_slider_cardview);

            user_image = itemView.findViewById(R.id.user_image);

            like_img_lay = itemView.findViewById(R.id.like_img_lay);
            comment_img_lay = itemView.findViewById(R.id.comment_img_lay);
            share_img_lay = itemView.findViewById(R.id.share_img_lay);
        }
    }
}
