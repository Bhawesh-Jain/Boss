package com.social.mitra.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import com.social.mitra.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyProductActivity extends AppCompatActivity {

    ImageView back_img;
    CircleImageView edit_post, dlt_post;
    CardView card_lay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_product);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        back_img = findViewById(R.id.back_img);
        card_lay = findViewById(R.id.card_lay);
        edit_post = findViewById(R.id.edit_post);
        dlt_post = findViewById(R.id.dlt_post);

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        edit_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MyProductActivity.this, "Product Edit", Toast.LENGTH_SHORT).show();
            }
        });

        dlt_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                card_lay.setVisibility(View.GONE);
                Toast.makeText(MyProductActivity.this, "Product Delete", Toast.LENGTH_SHORT).show();
            }
        });


    }
}