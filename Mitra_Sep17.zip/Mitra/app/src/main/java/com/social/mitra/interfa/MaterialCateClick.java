package com.social.mitra.interfa;

import com.social.mitra.model.MaterialCateList;

public interface MaterialCateClick {

    void MCateClick(MaterialCateList CateIdClicked,MaterialCateList cateName);
}
