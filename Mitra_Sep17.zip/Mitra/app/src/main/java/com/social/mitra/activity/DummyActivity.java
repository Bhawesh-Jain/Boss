package com.social.mitra.activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Build;
import android.os.Bundle;

import com.jarvanmo.exoplayerview.ui.ExoVideoView;
import com.social.mitra.R;
import com.social.mitra.adapter.VideoViewAdapter;

import java.util.ArrayList;


public class DummyActivity extends AppCompatActivity {


    ExoVideoView video_v;
    public static ViewPager2 videoview_pager;
    ArrayList<String> videos=new ArrayList<>();
    public static int video_position=0;
     VideoViewAdapter videoViewAdapter;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy);

        videoview_pager = findViewById(R.id.videoview_pager);

/*

        videos.add("http://logicaltest.in/Exim_papa/assets/video/187126814_532689178137605_6087944053270491943_n.mp4");
        videos.add("http://logicaltest.in/Exim_papa/assets/video/187126814_532689178137605_6087944053270491943_n.mp4");
        videos.add("http://logicaltest.in/Exim_papa/assets/video/big_buck_bunny_720p_20mb.mp4");
        videos.add("http://logicaltest.in/Exim_papa/assets/video/187126814_532689178137605_6087944053270491943_n.mp4");
        videos.add("http://logicaltest.in/Exim_papa/assets/video/big_buck_bunny_720p_20mb.mp4");
        videos.add("http://logicaltest.in/Exim_papa/assets/video/187126814_532689178137605_6087944053270491943_n.mp4");
        videos.add("http://logicaltest.in/Exim_papa/assets/video/big_buck_bunny_720p_20mb.mp4");

        SimpleMediaSource mediaSource = new SimpleMediaSource("http://logicaltest.in/Exim_papa/assets/video/big_buck_bunny_720p_20mb.mp4");

        video_v.hideController();
        video_v.setControllerAutoShow(false);
        video_v.setUseController(false);
        video_v.play(mediaSource);

        videoViewAdapter = new VideoViewAdapter(DummyActivity.this,videos) ;
        videoview_pager.setAdapter(videoViewAdapter);
*/



    }
}