package com.social.mitra.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.social.mitra.R;

public class MainFragment extends Fragment {
    Button btnClickMe;
    int fragCount;
    String[] Top_TABS = {"Home", "Importer"};
    TabLayout top_tab_layout;
    ViewPagerAdapter viewPagerAdapter;
    ViewPager home_pager;
    PagerAdapter pagerAdapter;
    int tabCount;
    BaseFragment.FragmentNavigation mFragmentNavigation;
    private int[] layouts;

    public MainFragment() {
        // Required empty public constructor
    }

    public static MainFragment newInstance(int instance) {
        Bundle args = new Bundle();
        args.putInt("ARGS_INSTANCE", instance);
        MainFragment fragment = new MainFragment();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_main, container, false);
        top_tab_layout = root.findViewById(R.id.top_tab_layout);
        home_pager = root.findViewById(R.id.home_pager);
        Bundle args = getArguments();
        if (args != null) {
            fragCount = args.getInt("ARGS_INSTANCE");
        }
        intiTab();

        layouts = new int[]{
                R.layout.fragment_joblist_,
                R.layout.fragment_buy_lead};


        viewPagerAdapter = new ViewPagerAdapter(
                getChildFragmentManager());
        home_pager.setAdapter(viewPagerAdapter);

        // It is used to join TabLayout with ViewPager.
        top_tab_layout.setupWithViewPager(home_pager);

        tabCount = top_tab_layout.getTabCount();
        //   tab_custom();

       /* top_tab_layout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
              TextView tab_text=  tab.getCustomView().findViewById(R.id.tab_tv);
              tab_text.setBackground(getActivity().getDrawable(R.drawable.tab_txt_back));
              tab_text.setTextColor(getActivity().getResources().getColor(R.color.white));
//                Toast.makeText(getActivity(), ""+tab.getText(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                TextView tab_text=  tab.getCustomView().findViewById(R.id.tab_tv);
                tab_text.setTextColor(getActivity().getResources().getColor(R.color.black));

                tab_text.setBackground(null);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                TextView tab_text=  tab.getCustomView().findViewById(R.id.tab_tv);
                tab_text.setBackground(getActivity().getDrawable(R.drawable.tab_txt_back));
                tab_text.setTextColor(getActivity().getResources().getColor(R.color.white));

            }
        });
*/
        top_tab_layout.setSelected(true);


//        ( (HomeActivity)getActivity()).updateToolbarTitle((fragCount == 0) ? "Home" : "Sub Home "+fragCount);

        return root;

    }


    private void tab_custom() {


        for (int i = 0; i < tabCount; i++) {


            TabLayout.Tab tab = top_tab_layout.getTabAt(i);
            View tabView = ((ViewGroup) top_tab_layout.getChildAt(0)).getChildAt(i);

//            tabView.requestLayout();

            View view = LayoutInflater.from(getActivity()).inflate(R.layout.tab_lay, null);

            TextView tab_text = view.findViewById(R.id.tab_tv);

            if (i == 0) {
                tab_text.setBackground(getActivity().getDrawable(R.drawable.tab_txt_back));
                tab_text.setTextColor(getActivity().getResources().getColor(R.color.white));
            }
            tab_text.setText(Top_TABS[i]);

            tab.setCustomView(view);
            tab.setText(i + "");
        }
    }

    private void intiTab() {
        if (top_tab_layout != null) {
            for (int i = 0; i < Top_TABS.length; i++) {

                top_tab_layout.addTab(top_tab_layout.newTab());
                TabLayout.Tab tab = top_tab_layout.getTabAt(i);
                if (tab != null)
                    tab.setText(Top_TABS[i]);
            }
        }
    }

    public class ViewPagerAdapter
            extends FragmentPagerAdapter {

        public ViewPagerAdapter(
                @NonNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;
            if (position == 0)
                fragment = new ListJobFragment();
            else if (position == 1)
                fragment = new ImportersFragment();

            return fragment;
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            String title = null;
            if (position == 0)
                title = "Home";
            else if (position == 1)
                title = "Importers";
            return title;
        }
    }

}