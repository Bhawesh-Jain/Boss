package com.social.mitra.fragments;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;


import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.verify_profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.social.mitra.R;
import com.social.mitra.SelectLanguageActivity;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.sessionData.Session;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SignUp extends Fragment {
    ImageView HOLDER_IMAGE, SELECT_IMG;

    String profile_status;
    String form_status;
    Session session;
    String User_id,userName;
    EditText USER_FIRST_NAME;
    private static final int CAMERA_REQUEST = 1;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;

    File ImageFile;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.activity_signup_success, container, false);

        session = new Session(getActivity());
        User_id = session.getUser_Id();
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getActivity());

        bottomSheetDialog.setContentView(R.layout.bottom_signup_service_provider);
        bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        bottomSheetDialog.setCanceledOnTouchOutside(true);

        TextView go_to_language_activity;
        CardView BUTTON_VERIFY_PROFILE;
        SELECT_IMG = bottomSheetDialog.findViewById(R.id.SELECT_IMG);
        HOLDER_IMAGE = bottomSheetDialog.findViewById(R.id.HOLDER_IMAGE);
        USER_FIRST_NAME = bottomSheetDialog.findViewById(R.id.USER_FIRST_NAME);
        BUTTON_VERIFY_PROFILE = bottomSheetDialog.findViewById(R.id.BUTTON_VERIFY_PROFILE);
        go_to_language_activity = bottomSheetDialog.findViewById(R.id.go_to_language_activity);

        userName = session.getHomeUserName();
        USER_FIRST_NAME.setText(userName);

        SELECT_IMG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(getActivity())
                        .crop()
                        .compress(200)            //Final image size will be less than 1 MB(Optional)
                        .start(1);
            }
        });

        go_to_language_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), SelectLanguageActivity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });

        BUTTON_VERIFY_PROFILE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Verify_profile(User_id);
            }
        });


        bottomSheetDialog.show();


        return root;
    }

    public static File bitmapToFile(Context mContext, Bitmap bitmap) {
        try {
            String name = System.currentTimeMillis() + ".png";
            File file = new File(mContext.getCacheDir(), name);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 60, bos);
            byte[] bArr = bos.toByteArray();
            bos.flush();
            bos.close();

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bArr);
            fos.flush();
            fos.close();

            return file;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void Verify_profile(String user_id) {
        Log.e("TAG", "Update_profile: ");

        ProgressDialog progressDialog = new ProgressDialog(getActivity());

        String first_name = USER_FIRST_NAME.getText().toString();


        AndroidNetworking.upload(Base_Url + verify_profile)
                .addMultipartParameter("user_id", user_id)
                .addMultipartFile("image", ImageFile)
                .addMultipartParameter("fname", first_name)
//                .addMultipartParameter("lname", last_name)
                //.setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("---rrrProfile", "UpdateProfileActivityuAPIresponse" + jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);
                            progressDialog.dismiss();
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");


                            if (result.equalsIgnoreCase("true")) {

                                Intent intent = new Intent(getActivity(), HomeActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
                        progressDialog.dismiss();

                    }
                });


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(getActivity(), "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }



    /*@Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(getActivity(), "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }*/

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.e("requestCode->", "onActivityResult: " + requestCode);
        try {
            super.onActivityResult(requestCode, resultCode, data);

            Log.e(TAG, "onActivityResult:---- requestCode   " + requestCode);
            Log.e(TAG, "onActivityResult:---- resultCode    " + resultCode);
            if (requestCode == 1) {
                Bitmap bitmap = BitmapFactory.decodeFile(data.getData().getPath());
                HOLDER_IMAGE.setImageBitmap(bitmap);
                Log.e("BITMAAP", "requestCode_1_onActivityResult: " + bitmap);
                ImageFile = bitmapToFile(getActivity(), bitmap);
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }


   /* @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            HOLDER_IMAGE.setImageBitmap(photo);
//            IMAGE = bitmapToFile(getActivity(), photo);
            Log.e(TAG, "-----CAMERA_IMAGE_onActivityResult: " + IMAGE);

        } else if (requestCode == RESULT_GALLERY && resultCode == Activity.RESULT_OK) {
            Uri selectedImage = data.getData();
            HOLDER_IMAGE.setImageURI(selectedImage);
            IMAGE = new File(selectedImage.getPath());
            Log.e(TAG, "-----GALLERY__IMAGE_onActivityResult: " + IMAGE);
        }
    }*/

    }
}
