package com.social.mitra.model;

public class ListOfExperience {

    String Experience_Id,Experience_Name;

    public ListOfExperience(String experience_Id, String experience_Name) {
        Experience_Id = experience_Id;
        Experience_Name = experience_Name;
    }

    public String getExperience_Id() {
        return Experience_Id;
    }

    public void setExperience_Id(String experience_Id) {
        Experience_Id = experience_Id;
    }

    public String getExperience_Name() {
        return Experience_Name;
    }

    public void setExperience_Name(String experience_Name) {
        Experience_Name = experience_Name;
    }
}
