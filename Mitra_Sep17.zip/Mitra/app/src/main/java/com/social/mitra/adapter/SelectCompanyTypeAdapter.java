package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.model.CompanyTypeModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class SelectCompanyTypeAdapter extends RecyclerView.Adapter<SelectCompanyTypeAdapter.MyViewHolder> {

    ArrayList<CompanyTypeModel>companyTypeModels;
    Context context;

    public SelectCompanyTypeAdapter( Context context,ArrayList<CompanyTypeModel> companyTypeModels) {
        this.companyTypeModels = companyTypeModels;
        this.context = context;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.select_company_type_lay,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull SelectCompanyTypeAdapter.MyViewHolder holder, int position) {

        CompanyTypeModel companyTypeModel = companyTypeModels.get(position);

        holder.company_type_tv.setText(companyTypeModel.getCompany_type());


        holder.company_check_box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {



            }
        });
    }

    @Override
    public int getItemCount() {
        return companyTypeModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        CheckBox company_check_box;
        TextView company_type_tv;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            company_check_box = itemView.findViewById(R.id.company_check_box);

            company_type_tv = itemView.findViewById(R.id.company_type_tv);

        }

    }
}
