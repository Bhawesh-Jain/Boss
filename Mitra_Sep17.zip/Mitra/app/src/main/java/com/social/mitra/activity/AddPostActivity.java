package com.social.mitra.activity;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.add_hastags;
import static com.social.mitra.util.BaseUrl.add_reels;
import static com.social.mitra.util.BaseUrl.get_hashtag_list;
import static com.social.mitra.util.BaseUrl.get_reel_categories;
import static com.social.mitra.util.ImageShortCut.from;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest.MultiPartBuilder;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.sangcomz.fishbun.FishBun;
import com.sangcomz.fishbun.adapter.image.impl.GlideAdapter;
import com.social.mitra.R;
import com.social.mitra.adapter.APCategoryAdapter;
import com.social.mitra.adapter.StringRecyclerAdapter;
import com.social.mitra.databinding.ActivityAddPostBinding;
import com.social.mitra.interfa.AddPostInterface;
import com.social.mitra.model.CityList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vn.tungdx.mediapicker.MediaItem;
import vn.tungdx.mediapicker.MediaOptions;
import vn.tungdx.mediapicker.activities.MediaPickerActivity;

public class AddPostActivity extends AppCompatActivity implements AddPostInterface {

    private static final int REQUEST_MEDIA = 100;
    private final String TAG = AddPostActivity.class.getSimpleName();
    private final ArrayList<CityList> cateList = new ArrayList<>();
    private final ArrayList<CityList> hashList = new ArrayList<>();
    private final ArrayList<String> hashStringList = new ArrayList<>();
    private final ArrayList<String> hashStringFullList = new ArrayList<>();
    String description = "", textColor = "purple", hash_tag_id = "", reel_category_id = "";
    private ActivityAddPostBinding binding;
    private String type = "text";
    private File ImageREQFile;
    private StringRecyclerAdapter stringRecyclerAdapter;
    private boolean categorySelected = false;
    private Session session;
    private String image_text = "";
    private ArrayList<Uri> imageArray = new ArrayList<>();
    private File imgPostFile_2, imgPostFile_3, imgPostFile_4, imgPostFile_5,
            imgPostFile_6, imgPostFile_7, imgPostFile_8, imgPostFile_9, imgPostFile_10;

    private static final String VIDEO_DIRECTORY = "/mitra";
    private final int GALLERY = 1001;
    private final int CAMERA = 2001;

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkNext();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddPostBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        session = new Session(this);


        if (getIntent() != null) {
            type = getIntent().getStringExtra("mode");
        }

        initView();

        checkNext();
    }

    private void initView() {
        binding.icBack.setOnClickListener(view -> finish());

        if (type.equalsIgnoreCase("text")) {
            binding.textAp.getRoot().setVisibility(View.VISIBLE);
            initText();
        } else if (type.equalsIgnoreCase("video")) {
            binding.videoAp.getRoot().setVisibility(View.VISIBLE);
            initVideo();
        } else if (type.equalsIgnoreCase("image")) {
            binding.photoAp.getRoot().setVisibility(View.VISIBLE);
            initPhoto();
        }

        binding.nextTv.setOnClickListener(view -> {
            categoryDialog();
            new Handler().post(this::getNewHash);
        });
        getCategories();
        getHashList();

        hashTag();
    }

    private void initPhoto() {
        binding.preRl.setVisibility(View.GONE);
        binding.preImg.setVisibility(View.VISIBLE);

        binding.photoAp.photo.setOnClickListener(view -> selectImage());

        binding.photoAp.nextCard.setOnClickListener(view -> binding.photoAp.getRoot().setVisibility(View.GONE));

        binding.photoAp.image1.setOnClickListener(view -> setFullScreenImage(0));
        binding.photoAp.image2.setOnClickListener(view -> setFullScreenImage(1));
        binding.photoAp.image3.setOnClickListener(view -> setFullScreenImage(2));
        binding.photoAp.image4.setOnClickListener(view -> setFullScreenImage(3));
        binding.photoAp.image5.setOnClickListener(view -> setFullScreenImage(4));
        binding.photoAp.image6.setOnClickListener(view -> setFullScreenImage(5));
        binding.photoAp.image7.setOnClickListener(view -> setFullScreenImage(6));
        binding.photoAp.image8.setOnClickListener(view -> setFullScreenImage(7));
        binding.photoAp.image9.setOnClickListener(view -> setFullScreenImage(8));
        binding.photoAp.image10.setOnClickListener(view -> setFullScreenImage(9));

        new Handler().postDelayed(this::selectImage, 10);
    }

    private void initVideo() {
        binding.videoAp.selectVideo.setOnClickListener(view -> selectVideo());
    }

    private void initText() {
        binding.preRl.setVisibility(View.VISIBLE);
        binding.preImg.setVisibility(View.GONE);

        binding.textAp.nextTv.setOnClickListener(view -> {
            image_text = binding.textAp.edtAp.getText().toString();

            binding.edtAp.setText(image_text);
            binding.textAp.getRoot().setVisibility(View.GONE);
        });

        binding.textAp.bluePallet.setOnClickListener(view1 -> selectColor(binding.textAp.bluePallet));
        binding.textAp.redPallet.setOnClickListener(view1 -> selectColor(binding.textAp.redPallet));
        binding.textAp.greenPallet.setOnClickListener(view1 -> selectColor(binding.textAp.greenPallet));
        binding.textAp.purplePallet.setOnClickListener(view1 -> selectColor(binding.textAp.purplePallet));
        binding.textAp.yellowPallet.setOnClickListener(view1 -> selectColor(binding.textAp.yellowPallet));

        binding.textAp.edtAp.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() != 0) {
                    hidePallet();
                } else showPallet();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    // Text Code
    private void showPallet() {
        binding.textAp.pallet.setVisibility(View.VISIBLE);
        binding.textAp.nextTv.setVisibility(View.GONE);
    }

    private void hidePallet() {
        binding.textAp.pallet.setVisibility(View.GONE);
        binding.textAp.nextTv.setVisibility(View.VISIBLE);
    }


    private void selectColor(CardView pallet) {
        if (pallet == binding.textAp.bluePallet) {
            binding.textAp.parent.setBackgroundColor(getResources().getColor(R.color.light_blue_ap));
            binding.preRl.setBackgroundColor(getResources().getColor(R.color.light_blue_ap));
            textColor = "blue";
        } else if (pallet == binding.textAp.redPallet) {
            binding.preRl.setBackgroundColor(getResources().getColor(R.color.red_ap));
            binding.textAp.parent.setBackgroundColor(getResources().getColor(R.color.red_ap));
            textColor = "red";
        } else if (pallet == binding.textAp.greenPallet) {
            binding.preRl.setBackgroundColor(getResources().getColor(R.color.green_ap));
            binding.textAp.parent.setBackgroundColor(getResources().getColor(R.color.green_ap));
            textColor = "green";
        } else if (pallet == binding.textAp.purplePallet) {
            binding.preRl.setBackgroundColor(getResources().getColor(R.color.purple_ap));
            binding.textAp.parent.setBackgroundColor(getResources().getColor(R.color.purple_ap));
            textColor = "purple";
        } else if (pallet == binding.textAp.yellowPallet) {
            binding.preRl.setBackgroundColor(getResources().getColor(R.color.yellow_ap));
            binding.textAp.parent.setBackgroundColor(getResources().getColor(R.color.yellow_ap));
            textColor = "yellow";
        }
    }
    // Text Code


    // Video Code
    private void selectVideo() {
        MediaOptions.Builder builder = new MediaOptions.Builder();
        MediaOptions options = builder.selectVideo().build();
        MediaPickerActivity.Companion.open(this, REQUEST_MEDIA, options);
    }
    // Video Code


    // Image Code
    private void selectImage() {
        FishBun.with(AddPostActivity.this)
                .setImageAdapter(new GlideAdapter())
                .setMaxCount(10).hasCameraInPickerPage(true)
                .textOnNothingSelected("Please select at least One Image!")
                .textOnImagesSelectionLimitReached("iYou can't select any more.")
                .setRequestCode(100)
                .setSelectedImages(imageArray)
                .startAlbum();
    }

    private void setFullScreenImage(int pos) {
        if (imageArray != null && imageArray.size() != 0 && imageArray.size() >= pos) {
            binding.photoAp.fullScreenImage.setImageURI(imageArray.get(pos));
            binding.preImg.setImageURI(imageArray.get(pos));
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent imageData) {
        super.onActivityResult(requestCode, resultCode, imageData);

        Log.e(TAG, "onActivityResult: Is calling and Size - " + imageArray.size());
        if (requestCode == 100) {
            try {
                imageArray = imageData.getParcelableArrayListExtra(FishBun.INTENT_PATH);
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (int i = 0; i < imageArray.size(); i++) {
                Log.e(TAG, "onActivityResult: ImagePicker" + imageArray.get(i));

                if (i == 0) binding.photoAp.image1.setImageURI(imageArray.get(i));
                if (i == 1) binding.photoAp.image2.setImageURI(imageArray.get(i));
                if (i == 2) binding.photoAp.image3.setImageURI(imageArray.get(i));
                if (i == 3) binding.photoAp.image4.setImageURI(imageArray.get(i));
                if (i == 4) binding.photoAp.image5.setImageURI(imageArray.get(i));
                if (i == 5) binding.photoAp.image6.setImageURI(imageArray.get(i));
                if (i == 6) binding.photoAp.image7.setImageURI(imageArray.get(i));
                if (i == 7) binding.photoAp.image8.setImageURI(imageArray.get(i));
                if (i == 8) binding.photoAp.image9.setImageURI(imageArray.get(i));
                if (i == 9) binding.photoAp.image10.setImageURI(imageArray.get(i));

                setFullScreenImage(0);
            }
            try {
                uriToFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            if (requestCode == REQUEST_MEDIA) {
                if (resultCode == RESULT_OK) {
                    List<MediaItem> mediaSelectedList = MediaPickerActivity.Companion.getMediaItemSelected(imageData);
                    if (mediaSelectedList != null)
                        if (mediaSelectedList.size() != 0) {
                            Log.e(TAG, "onActivityResult: URI-Origin --->  " + mediaSelectedList.get(0).getUriOrigin());
                            Log.e(TAG, "onActivityResult: URI-Cropped --->  " + mediaSelectedList.get(0).getUriCropped());
                            Toast.makeText(this, "" + mediaSelectedList.get(0).getPathCropped(getApplicationContext()), Toast.LENGTH_SHORT).show();
                            Toast.makeText(this, "" + mediaSelectedList.get(0).getUriOrigin(), Toast.LENGTH_SHORT).show();
                            Toast.makeText(this, "" + mediaSelectedList.get(0).getUriCropped(), Toast.LENGTH_SHORT).show();
                        }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        checkNext();
    }

    private void uriToFile() throws IOException {
        Log.e(TAG, "uriToFile: ArraySize-" + imageArray.size());
        for (int i = 0; i < imageArray.size(); i++) {
            if (i == 0) if (imageArray.get(i) != null) ImageREQFile = from(this, imageArray.get(0));
            if (i == 1) if (imageArray.get(i) != null) imgPostFile_2 = from(this, imageArray.get(1));
            if (i == 2) if (imageArray.get(i) != null) imgPostFile_3 = from(this, imageArray.get(2));
            if (i == 3) if (imageArray.get(i) != null) imgPostFile_4 = from(this, imageArray.get(3));
            if (i == 4) if (imageArray.get(i) != null) imgPostFile_5 = from(this, imageArray.get(4));
            if (i == 5) if (imageArray.get(i) != null) imgPostFile_6 = from(this, imageArray.get(4));
            if (i == 6) if (imageArray.get(i) != null) imgPostFile_7 = from(this, imageArray.get(4));
            if (i == 7) if (imageArray.get(i) != null) imgPostFile_8 = from(this, imageArray.get(4));
            if (i == 8) if (imageArray.get(i) != null) imgPostFile_9 = from(this, imageArray.get(4));
            if (i == 9) if (imageArray.get(i) != null) imgPostFile_10 = from(this, imageArray.get(4));
        }
    }
    // Image Code


    private void checkNext() {
        try {
            if (type.equalsIgnoreCase("image"))
                if (ImageREQFile != null) {
                    binding.photoAp.nextCard.setVisibility(View.VISIBLE);
                } else binding.photoAp.nextCard.setVisibility(View.GONE);
            else if (type.equalsIgnoreCase("video"))
                if (ImageREQFile != null) {
                    binding.photoAp.nextCard.setVisibility(View.VISIBLE);
                } else binding.photoAp.nextCard.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void categoryDialog() {
        Dialog dialogView = new Dialog(AddPostActivity.this);
        dialogView.setContentView(R.layout.dialog_category_list);
        dialogView.setCancelable(true);
        dialogView.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        RecyclerView recyclerView = dialogView.findViewById(R.id.cate_list);
        ImageView close = dialogView.findViewById(R.id.close_img);
        TextView post = dialogView.findViewById(R.id.post_tv);

        post.setOnClickListener(view -> {
            if (categorySelected) {
                addReel();
            } else Toast.makeText(this, "Select Category First!", Toast.LENGTH_SHORT).show();
        });
        close.setOnClickListener(view -> dialogView.dismiss());

        recyclerView.setAdapter(new APCategoryAdapter(getApplicationContext(), cateList, AddPostActivity.this));
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        dialogView.show();
    }

    private void addReel() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        description = binding.addCaptionEdt.getText().toString();

        MultiPartBuilder anAdd = AndroidNetworking.upload(Base_Url + add_reels);
        anAdd.addMultipartParameter("user_id", session.getUser_Id());
        anAdd.addMultipartParameter("description", description);
        anAdd.addMultipartParameter("textcolor", textColor);
        anAdd.addMultipartParameter("hash_tag_id", hash_tag_id);
        anAdd.addMultipartParameter("type", type);
        anAdd.addMultipartParameter("image_text", image_text);
        anAdd.addMultipartParameter("reel_category_id", reel_category_id);
        if (ImageREQFile != null) anAdd.addMultipartFile("image", ImageREQFile);
        if (imgPostFile_2 != null) anAdd.addMultipartFile("image_2", imgPostFile_2);
        if (imgPostFile_3 != null) anAdd.addMultipartFile("image_3", imgPostFile_3);
        if (imgPostFile_4 != null) anAdd.addMultipartFile("image_4", imgPostFile_4);
        if (imgPostFile_5 != null) anAdd.addMultipartFile("image_5", imgPostFile_5);
        if (imgPostFile_6 != null) anAdd.addMultipartFile("image_6", imgPostFile_6);
        if (imgPostFile_7 != null) anAdd.addMultipartFile("image_7", imgPostFile_7);
        if (imgPostFile_8 != null) anAdd.addMultipartFile("image_8", imgPostFile_8);
        if (imgPostFile_9 != null) anAdd.addMultipartFile("image_9", imgPostFile_9);
        if (imgPostFile_10 != null) anAdd.addMultipartFile("image_10", imgPostFile_10);

        anAdd.build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                Log.e(TAG, "Add Reels  onResponse: " + jsonObject.toString());
                try {
                    Toast.makeText(AddPostActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    finish();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onError(ANError anError) {
                progressDialog.dismiss();
                Toast.makeText(AddPostActivity.this, "" + anError.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getCategories() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_reel_categories, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equals("true")) {
                        cateList.clear();

                        JSONArray data = jsonObject.getJSONArray("data");

                        for (int i = 0; i < data.length(); i++) {
                            JSONObject dataObj = data.getJSONObject(i);

                            CityList model = new CityList(
                                    dataObj.getString("id"),
                                    dataObj.getString("name")
                            );
                            cateList.add(model);
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(getApplicationContext(), "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show());
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    private void getHashList() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_hashtag_list, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "onResponse: GetHashList --> " + response);
                    if (jsonObject.getString("result").equals("true")) {
                        hashList.clear();

                        JSONArray data = jsonObject.getJSONArray("data");

                        for (int i = 0; i < data.length(); i++) {
                            JSONObject dataObj = data.getJSONObject(i);

                            CityList model = new CityList(
                                    dataObj.getString("id"),
                                    dataObj.getString("name")
                            );
                            hashList.add(model);
                            hashStringFullList.add(dataObj.getString("name"));
                            hashStringList.add(dataObj.getString("name"));
                        }
                        binding.hashRecyclerList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        stringRecyclerAdapter = new StringRecyclerAdapter(hashStringList, getApplicationContext(), AddPostActivity.this);
                        binding.hashRecyclerList.setAdapter(stringRecyclerAdapter);

                    } else {
                        Toast.makeText(getApplicationContext(), "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(getApplicationContext(), "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show());
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    private void hashTag() {
        binding.addCaptionEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString();
                if (text.lastIndexOf("#") > text.lastIndexOf(" ")) {
                    String tag = text.substring(text.lastIndexOf("#"));
                    if (tag.length() > 1) {
                        filterHash(tag);
                        binding.hashRecyclerList.setVisibility(View.VISIBLE);
                    } else binding.hashRecyclerList.setVisibility(View.GONE);
                } else binding.hashRecyclerList.setVisibility(View.GONE);
            }
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    private void filterHash(String tag) {
        hashStringList.clear();
        for (int i = 0; i < hashStringFullList.size(); i++) {
            String name = hashStringFullList.get(i);
            if (name.contains(tag))
                hashStringList.add(name);
        }
        stringRecyclerAdapter.notifyDataSetChanged();
    }

    private void getNewHash() {
        if (binding.addCaptionEdt.getText().length() != 0)
            try {
                String text = binding.addCaptionEdt.getText().toString();
                String[] words = text.split(" ");
                ArrayList<String> tags = new ArrayList<>();

                for (String word : words) {
                    if (word.charAt(0) == '#') {
                        tags.add(word);
                    }
                }

                for (int i = 0; i < hashStringFullList.size(); i++) {
                    String hash = hashStringFullList.get(i);
                    for (int j = 0; j < tags.size(); j++) {
                        if (hash.equalsIgnoreCase(tags.get(j)))
                            tags.remove(tags.get(j));
                    }
                }

                for (int i = 0; i < tags.size(); i++) {
                    AddHashtag(tags.get(i));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    private void AddHashtag(String tag) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + add_hastags, response -> Log.e(TAG, "onResponse: Add Tag Response + tag - " + tag + response), null) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                HashMap<String, String> map = new HashMap<>();
                map.put("name", tag);
                return map;
            }
        };
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    @Override
    public void onHashtagClick(String tag) {
        String allText = binding.addCaptionEdt.getText().toString();

        for (int i = 0; i < hashList.size(); i++) {
            if (hashList.get(i).getCityName().equalsIgnoreCase(tag)) {
                hash_tag_id = hash_tag_id + ", " + hashList.get(i).getCityID();
                break;
            }
        }

        int end = allText.lastIndexOf("#");

        String last = allText.substring(0, end);
        String text = last + tag + " ";

        binding.addCaptionEdt.setText(text);
        binding.addCaptionEdt.setSelection(binding.addCaptionEdt.getText().length());
    }

    @Override
    public void onCateClick(String id) {
        categorySelected = true;
        reel_category_id = reel_category_id + ", " + id;
    }
}