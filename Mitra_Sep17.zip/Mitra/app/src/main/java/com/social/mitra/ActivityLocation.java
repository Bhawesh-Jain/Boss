package com.social.mitra;

import static android.content.ContentValues.TAG;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.social.mitra.gps.GPSTracker;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class ActivityLocation extends AppCompatActivity {

    private static final int REQUEST_LOCATION = 1;
    private static final int MY_PERMISSION_ACCESS_COURSE_LOCATION = 12;
    LocationManager locationManager;
    TextView btn_nextttt;
    GPSTracker gpsTracker;
    TextView button_next,txt_current_location;
    String locality;
    String city;
    String region_code;
    String zipcode;
    Session session;
    String LocalAdd;
    SessionLogOut sessionLogOut;

    String location;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_locationn);

        gpsTracker = new GPSTracker(ActivityLocation.this);
        session = new Session(ActivityLocation.this);
        sessionLogOut = new SessionLogOut(ActivityLocation.this);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);


        button_next = findViewById(R.id.button_next);


        txt_current_location = findViewById(R.id.txt_current_location);
        btn_nextttt = findViewById(R.id.btn_nextttt);

        btn_nextttt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityLocation.this,SelectProfiletypesActivity.class);
//                intent.putExtra("KEYCITY",locality);
                startActivity(intent);
                finish();
            }
        });

        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if ( ContextCompat.checkSelfPermission( ActivityLocation.this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION ) !=
                        PackageManager.PERMISSION_GRANTED ) {

                    ActivityCompat.requestPermissions( ActivityLocation.this,
                            new String[] {  android.Manifest.permission.
                                    ACCESS_COARSE_LOCATION  },
                            ActivityLocation.MY_PERMISSION_ACCESS_COURSE_LOCATION );
                }
                if (gpsTracker.canGetLocation()){
                    getLocation();

                }else{
                    OnGPS();
                }

            }
        });




    }



    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ActivityLocation.this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getLocation() {
        double lat          =    gpsTracker.getLocation().getLatitude();
        double longitude    =  gpsTracker.getLocation().getLongitude();

        Log.e(TAG, "getLocation:lat "+lat );
        Log.e(TAG, "getLocation:longitude "+longitude );

//        Toast.makeText(ActivityLocation.this, gpsTracker.getLocation().toString(), Toast.LENGTH_SHORT).show();


        Geocoder geocoder = new Geocoder(ActivityLocation.this, Locale.getDefault());
        List<Address>
                addresses = null;
        try {
            addresses = geocoder.getFromLocation(lat, longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (addresses.size() > 0) {
            Address address = addresses.get(0);
              locality     = address.getLocality();
              city         = address.getCountryName();
              region_code  = address.getCountryCode();
              zipcode      = address.getPostalCode();

//            Toast.makeText(ActivityLocation.this, "address =>" + locality, Toast.LENGTH_SHORT).show();
            txt_current_location.setText(locality);

//            sessionLogOut.setLocName(locality);

        }
/*        if (ActivityCompat.checkSelfPermission(
                ActivityLocation.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                ActivityLocation.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                latitude = String.valueOf(lat);
                longitude = String.valueOf(longi);
                Log.e(TAG, "===latitude=getLocation: "+latitude);
                Log.e(TAG, "===longitude=getLocation: "+longitude);
//                showLocation.setText("Your Location: " + "\n" + "Latitude: " + latitude + "\n" + "Longitude: " + longitude);
            } else {
                Toast.makeText(this, "Unable to find location.", Toast.LENGTH_SHORT).show();
            }
        }*/
    }
}
