package com.social.mitra.activity;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.resend_otp;
import static com.social.mitra.util.BaseUrl.verify_otp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.HomeModuleActivity;
import com.social.mitra.HomeModuleCategory;
import com.social.mitra.MaterialProfessionalCateListActivity;
import com.social.mitra.MaterialProfileCreationActivity;
import com.social.mitra.ProfessionalCategoryList;
import com.social.mitra.ProfileCreationActivity;
import com.social.mitra.R;
import com.social.mitra.SelectProfiletypesActivity;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class OtpVerificationActivity extends AppCompatActivity {

    LinearLayout Otpbutton;
    String user_id = "", otp = "", mobile = "", verify_staus = "", form_status = "";
    String timeLeftFormatted;
    TextView _otp, verify_otp_btn;
    EditText editTextone, pin_second_edittext, pin_third_edittext, pin_forth_edittext;
    Session session;
    TextView resend_otp_txt;
    String VERIFY_PROFILE = "0";
    String MOBILE_PRE, pre_mobile;
    SessionLogOut sessionLogOut;
    String LocationExist;
    String M_TYPE;
    String LOc;
    String TYPE = "";
    String V_Profile = "0";
    String cate_status = "1";
    String Seccate_status = "1";
    String pro_status = "1";
    String homeCate_status = "1";
    RelativeLayout Layout_otp_Progress;
    String OTP;
    int val = 0;
    private EditText[] editTexts;
    private String TAG = "OTP Activity  ";
    private long mTimeLeftInMillis;

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        verify_otp_btn = findViewById(R.id.verify_otp_btn);

        editTextone = findViewById(R.id.editTextone);
        _otp = findViewById(R.id._otp);
        pin_second_edittext = findViewById(R.id.pin_second_edittext);
        pin_third_edittext = findViewById(R.id.pin_third_edittext);
        pin_forth_edittext = findViewById(R.id.pin_forth_edittext);
        resend_otp_txt = findViewById(R.id.resend_otp_txt);
        Layout_otp_Progress = findViewById(R.id.Layout_otp_Progress);
        session = new Session(this);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        editTexts = new EditText[]{editTextone, pin_second_edittext, pin_third_edittext, pin_forth_edittext};

        if (getIntent() != null) {
            user_id = getIntent().getStringExtra("ID");
            otp = getIntent().getStringExtra("OTP");
            pre_mobile = getIntent().getStringExtra("PreMobNum");
            M_TYPE = getIntent().getStringExtra("KeyType");
            LOc = getIntent().getStringExtra("LOC");
            Log.e(TAG, "=====onCreate:LOc>>>" + LOc);
            verify_staus = getIntent().getStringExtra("PRO_key");
//            form_status = getIntent().getStringExtra("form_status");
            Log.e(TAG, "===onCreate:M_TYPE>>>" + M_TYPE);
            Log.e(TAG, "onCreate:  >>>" + verify_staus);
            Log.e(TAG, "onCreate: user_user_id>>>" + user_id);
            Log.e(TAG, "onCreate: user_mobile>>>" + pre_mobile);
            Log.e(TAG, "onCreate: user otp>>>" + otp);
            Log.e(TAG, "onCreate: user_form_status>>>" + form_status);
            Toast.makeText(this, "OTP = >" + otp, Toast.LENGTH_SHORT).show();
        }

        sessionLogOut = new SessionLogOut(OtpVerificationActivity.this);

        MOBILE_PRE = sessionLogOut.getMobilePre();


//        Verify_status = session.getProfile_status();
//        Log.e(TAG, "onCreate: user otp>>>" + Verify_status);

        LocationExist = sessionLogOut.getLocName();
        new CountDownTimer(45000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                mTimeLeftInMillis = millisUntilFinished;
                //  txt_resend.setText(String.valueOf(counter));


                updateCountDownText();


            }

            @Override
            public void onFinish() {
                resend_otp_txt.setClickable(true);
                resend_otp_txt.setText("Resend otp.");
            }


        }.start();

        resend_otp_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextone.setFocusable(true);
                editTextone.getText().clear();
                pin_second_edittext.getText().clear();
                pin_third_edittext.getText().clear();
                pin_forth_edittext.getText().clear();
                if (MOBILE_PRE.equalsIgnoreCase(pre_mobile)) {
                    _Resend_otp(MOBILE_PRE);
                }
                Resend_otp(mobile);
            }
        });

        editTextone.addTextChangedListener(new PinTextWatcher(0));
        pin_second_edittext.addTextChangedListener(new PinTextWatcher(1));
        pin_third_edittext.addTextChangedListener(new PinTextWatcher(2));
        pin_forth_edittext.addTextChangedListener(new PinTextWatcher(3));

        editTextone.setOnKeyListener(new PinOnKeyListener(0));
        pin_second_edittext.setOnKeyListener(new PinOnKeyListener(1));
        pin_third_edittext.setOnKeyListener(new PinOnKeyListener(2));
        pin_forth_edittext.setOnKeyListener(new PinOnKeyListener(3));


        verify_otp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextone.getText().toString().equals("")) {
                    editTextone.setFocusable(true);
                    editTextone.setError("OTP");
                } else {
                    if (pin_second_edittext.getText().toString().equals("")) {
                        pin_second_edittext.setFocusable(true);
                        pin_second_edittext.setError("OTP");
                    } else {
                        if (pin_third_edittext.getText().toString().equals("")) {
                            pin_third_edittext.setFocusable(true);
                            pin_third_edittext.setError("OTP");
                        } else {
                            if (pin_forth_edittext.getText().toString().equals("")) {
                                pin_forth_edittext.setFocusable(true);
                                pin_forth_edittext.setError("OTP");
                            } else {
                                OTP = editTextone.getText().toString() + pin_second_edittext.getText().toString() + pin_third_edittext.getText().toString() + pin_forth_edittext.getText().toString();
                                verifyOtp(user_id, OTP);
                            }
                            /* verifyOtp("" + editTextone.getText().toString() + pin_second_edittext.getText().toString() + pin_third_edittext.getText().toString() + pin_forth_edittext.getText().toString());
                             */
//                                matchOtp(""+editTextone.getText().toString()+pin_second_edittext.getText().toString()+pin_third_edittext.getText().toString()+pin_forth_edittext.getText().toString());
                        }
                    }
                }
//                overridePendingTransition(R.anim.enter, R.anim.exit);
            }
        });
    }

    private void _Resend_otp(String mobile_pre) {
        Log.e(TAG, "Resend_otp: ");
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + resend_otp, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "onResponse: jsonObject   " + jsonObject);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String id = data.getString("id");
                        String resend_otp = data.getString("otp");
                        Log.e(TAG, "--resend_otp_onResponse: " + resend_otp);

                        Toast.makeText(OtpVerificationActivity.this, "Resend_otp" + resend_otp, Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();

                        Toast.makeText(OtpVerificationActivity.this, "Home ACtivty", Toast.LENGTH_SHORT).show();

                        session.setLogin(true);
                        session.setUser_Id(id);
                        verify_otp_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                startActivity(intent);
//                                setResult(RESULT_OK, intent);
                                finish();
                            }
                        });
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(OtpVerificationActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, error -> progressDialog.dismiss()) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("mobile", mobile_pre);
                Log.e(TAG, "getParams: " + map);

                return map;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void Resend_otp(String mobile) {

        Log.e(TAG, "Resend_otp: ");

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + resend_otp, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "onResponse: jsonObject   " + jsonObject);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String id = data.getString("id");
                        String resend_otp = data.getString("otp");
                        Log.e(TAG, "--resend_otp_onResponse: " + resend_otp);

                        Toast.makeText(OtpVerificationActivity.this, "Resend_otp" + resend_otp, Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
//                        Toast.makeText(OtpVerificationActivity.this, "Home ACtivty", Toast.LENGTH_SHORT).show();

                        verifyOtp(user_id, OTP);


                       /* session.setLogin(true);
                        session.setUser_Id(id);
                        verify_otp_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                               startActivity(intent);
//                                setResult(RESULT_OK, intent);
                                finish();

                            }
                        });*/


                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(OtpVerificationActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    Toast.makeText(OtpVerificationActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(OtpVerificationActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("mobile", mobile);
                Log.e(TAG, "getParams: " + map);
                return map;

            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }

    private void updateCountDownText() {
        int hours = (int) (mTimeLeftInMillis / 1000) / 3600;
        int minutes = (int) ((mTimeLeftInMillis / 1000) % 3600) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;

        if (hours > 0) {
            timeLeftFormatted = String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds);
        } else {
            timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        }
        resend_otp_txt.setClickable(false);
        resend_otp_txt.setText(timeLeftFormatted);
    }

    private void verifyOtp(String user_ID, String o) {

        Layout_otp_Progress.setVisibility(View.VISIBLE);


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + verify_otp, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "===onResponse:jsonObject" + jsonObject);

                    String result = jsonObject.getString("result");

                    if (result.equalsIgnoreCase("true")) {

                        Layout_otp_Progress.setVisibility(View.GONE);

                        JSONObject data = jsonObject.getJSONObject("data");

                        String id = data.getString("id");
                        TYPE = data.getString("type");
                        form_status = data.getString("form_status");
                        V_Profile = data.getString("verify_profile");

                        Log.e(TAG, "====TYPE: " + TYPE);

                        session.setLogin(true);
                        session.setUser_Id(id);


                        if (TYPE.equalsIgnoreCase("home_owner")) {

                            Log.e(TAG, "onResponse: home_owner ");

                            if (form_status.equalsIgnoreCase("0")) {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("2")) {


                                Intent intent = new Intent(OtpVerificationActivity.this, HomeModuleCategory.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("3")) {

                                Intent intent = new Intent(OtpVerificationActivity.this, HomeModuleActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("4")) {

                                Intent intent = new Intent(OtpVerificationActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();

                            } else {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            }


                        } else if (TYPE.equalsIgnoreCase("service_provider")) {
//                                 cate_status.equalsIgnoreCase("1")
//                                 ProfileCreationActivity
//                                 ProfessionalCategoryList
//                                 pro_status.equalsIgnoreCase("1")

                            if (form_status.equalsIgnoreCase("0")) {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("2")) {


                                Intent intent = new Intent(OtpVerificationActivity.this, ProfessionalCategoryList.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("3")) {

                                Intent intent = new Intent(OtpVerificationActivity.this, ProfileCreationActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("4")) {

                                Intent intent = new Intent(OtpVerificationActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            }

                        } else if (TYPE.equalsIgnoreCase("material_supplier")) {
//                                 HomeActivity
//                                 MaterialProfessionalCateListActivity
//                                 MaterialProfileCreationActivity


                            if (form_status.equalsIgnoreCase("0")) {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();

                            } else if (form_status.equalsIgnoreCase("2")) {


                                Intent intent = new Intent(OtpVerificationActivity.this, MaterialProfessionalCateListActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("3")) {

                                Intent intent = new Intent(OtpVerificationActivity.this, MaterialProfileCreationActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else if (form_status.equalsIgnoreCase("4")) {

                                Intent intent = new Intent(OtpVerificationActivity.this, HomeActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            } else {
                                Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                                intent.putExtra("KeyType", M_TYPE);
                                intent.putExtra("LOC", LOc);
                                startActivity(intent);
                                finish();
                            }

                        } else {


                            Intent intent = new Intent(OtpVerificationActivity.this, SelectProfiletypesActivity.class);
                            intent.putExtra("KeyType", M_TYPE);
                            intent.putExtra("LOC", LOc);
                            startActivity(intent);
                            finish();
                        }

                    } else {
                        // if (jsonObject.getString("result").equalsIgnoreCase("false")){

                        Toast.makeText(OtpVerificationActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();

                        Layout_otp_Progress.setVisibility(View.GONE);
//                        progressDialog.dismiss();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Layout_otp_Progress.setVisibility(View.GONE);
//                    progressDialog.dismiss();
                    Toast.makeText(OtpVerificationActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Layout_otp_Progress.setVisibility(View.GONE);
//                progressDialog.dismiss();
                Toast.makeText(OtpVerificationActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();

                map.put("otp", o);
                map.put("user_id", user_ID);
                Log.e(TAG, "---verify_OTP_getParams: " + map);
                return map;

            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }


    public class PinTextWatcher implements TextWatcher {

        private int currentIndex;
        private boolean isFirst = false, isLast = false;
        private String newTypedString = "";

        PinTextWatcher(int currentIndex) {
            this.currentIndex = currentIndex;

            if (currentIndex == 0)
                this.isFirst = true;
            else if (currentIndex == editTexts.length - 1)
                this.isLast = true;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            newTypedString = s.subSequence(start, start + count).toString().trim();

            if (currentIndex == editTexts.length - 1) {

                hideKeyboard();
            }
        }


        @Override
        public void afterTextChanged(Editable s) {

            String text = newTypedString;

            /* Detect paste event and set first char */
            if (text.length() > 1)
                text = String.valueOf(text.charAt(0)); // TODO: We can fill out other EditTexts

            editTexts[currentIndex].removeTextChangedListener(this);
            editTexts[currentIndex].setText(text);
            editTexts[currentIndex].setSelection(text.length());
            editTexts[currentIndex].addTextChangedListener(this);

            if (text.length() == 1)
                moveToNext();
            else if (text.length() == 0)
                moveToPrevious();
        }

        private void moveToNext() {
            if (!isLast)
                editTexts[currentIndex + 1].requestFocus();

            if (isAllEditTextsFilled() && isLast) { // isLast is optional
                editTexts[currentIndex].clearFocus();
                hideKeyboard();
            }
        }

        private void moveToPrevious() {
            if (!isFirst)
                editTexts[currentIndex - 1].requestFocus();
        }

        private boolean isAllEditTextsFilled() {
            for (EditText editText : editTexts)
                if (editText.getText().toString().trim().length() == 0)
                    return false;
            return true;
        }

        private void hideKeyboard() {
            if (getCurrentFocus() != null) {
                InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            }
        }

    }


    public class PinOnKeyListener implements View.OnKeyListener {

        private int currentIndex;

        PinOnKeyListener(int currentIndex) {
            this.currentIndex = currentIndex;
        }

        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_DEL && event.getAction() == KeyEvent.ACTION_DOWN) {
                if (editTexts[currentIndex].getText().toString().isEmpty() && currentIndex != 0)
                    editTexts[currentIndex - 1].requestFocus();
            }
            return false;
        }

    }
}