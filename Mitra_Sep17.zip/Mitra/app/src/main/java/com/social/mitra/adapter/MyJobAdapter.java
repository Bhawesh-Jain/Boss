package com.social.mitra.adapter;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.COMUNITY_PATH_URL;
import static com.social.mitra.util.BaseUrl.delete_community;
import static com.social.mitra.util.BaseUrl.get_my_community;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.model.JobDataList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyJobAdapter extends RecyclerView.Adapter<MyJobAdapter.MyViewHolder> {

    Session session;
    String User_ID, Item_ID;
    String like;
    String un_like;
    String comment_count;
    int likee = 0;
    Context context;
    String community_path;
    ArrayList<JobDataList> jobDataListArrayList;
    String other = "";

    public MyJobAdapter(Context context, ArrayList<JobDataList> jobDataListArrayList, String community_path) {
        this.context = context;
        this.jobDataListArrayList = jobDataListArrayList;
        this.community_path = community_path;
        try {
            session = new Session(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public MyJobAdapter(Context context, ArrayList<JobDataList> jobDataListArrayList, String community_path, String other) {
        this.context = context;
        this.jobDataListArrayList = jobDataListArrayList;
        this.community_path = community_path;
        this.other = other;
        try {
            session = new Session(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @NonNull
    @Override
    public MyJobAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.row_myjobs, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyJobAdapter.MyViewHolder holder, int position) {
        User_ID = session.getUser_Id();
        Item_ID = jobDataListArrayList.get(position).getId();
        like = jobDataListArrayList.get(position).getLiked();
        un_like = jobDataListArrayList.get(position).getLike_count();
        comment_count = jobDataListArrayList.get(position).getComment_count();

        if (other.length() != 0){
            holder.like_lay_out1.setVisibility(View.GONE);
        }

        if (jobDataListArrayList.size() > 0) {
            JobDataList jobDataList = jobDataListArrayList.get(position);

            holder.userlike_name.setText(jobDataList.getDescription());
            holder.counting.setText(jobDataList.getAgo_time());

            if (jobDataList.getCommunity_image().equalsIgnoreCase(""))
                holder.img.setVisibility(View.GONE);
            else
                Glide.with(context).load(COMUNITY_PATH_URL + jobDataList.getCommunity_image()).into(holder.img);
        }
        holder.delete_img.setOnClickListener(view -> deletePost(holder.getAbsoluteAdapterPosition(), jobDataListArrayList.get(holder.getAbsoluteAdapterPosition()).getId()));

        holder.parent.setOnClickListener(view -> {
            context.startActivity(new Intent(context, HomeActivity.class));
            session.setValue("startWorkTab", "yes");
        });
    }

    private void deletePost(int position, String community_id) {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(context);
        myAlertDialog.setTitle("Delete Job Post");
        myAlertDialog.setMessage("Are you sure you want to delete your job post?");

        myAlertDialog.setPositiveButton("Yes", (arg0, arg1) -> {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + delete_community, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                            Toast.makeText(context, ""+jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                            jobDataListArrayList.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, jobDataListArrayList.size());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, error -> Toast.makeText(context, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show()) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> map = new HashMap<>();
                    map.put("community_id", community_id);

                    Log.e("CommId", "getParams:  " + map);
                    return map;
                }
            };
            VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
        });

        myAlertDialog.setNegativeButton("Cancel", null);
        myAlertDialog.show();
    }


    @Override
    public int getItemCount() {
        return jobDataListArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView img, delete_img;
        TextView counting, userlike_name;
        LinearLayout parent;
        RelativeLayout like_lay_out1;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            userlike_name = itemView.findViewById(R.id.userlike_name);
            counting = itemView.findViewById(R.id.counting);
            img = itemView.findViewById(R.id.img);

            like_lay_out1 = itemView.findViewById(R.id.like_lay_out1);
            parent = itemView.findViewById(R.id.parent);
            delete_img = itemView.findViewById(R.id.delete_img);
        }
    }
}
