package com.social.mitra.interfa;

import com.social.mitra.model.CityList;

public interface CityItemClick {

    void City_Item_Click(CityList CityId);
}
