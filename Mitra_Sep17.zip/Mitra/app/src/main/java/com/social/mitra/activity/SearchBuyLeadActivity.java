package com.social.mitra.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.social.mitra.R;

public class SearchBuyLeadActivity extends AppCompatActivity {

    TextView search_type,interasted_tv;
    ImageView back_img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_buy_lead);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        search_type =findViewById(R.id.search_type);
        interasted_tv =findViewById(R.id.interasted_tv);
        back_img =findViewById(R.id.back_img);

        if(getIntent()!=null){

            String type = getIntent().getStringExtra("type");
            search_type.setText(""+type);
        }

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        interasted_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SearchBuyLeadActivity.this,BuyLeadActivity.class));
            }
        });

    }
}