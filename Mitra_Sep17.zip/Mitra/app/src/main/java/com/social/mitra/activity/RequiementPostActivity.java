package com.social.mitra.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RequiementPostActivity extends AppCompatActivity {
    ImageView back_img;
    Button submit_req_btn;
    EditText required_specification,quantity_edt, target_price_edt,post_of_discharge_edt,required_quote_edt;
    Spinner minimum_unit_spin, minimum_quantity_spin, country_drop_spinner, requird_price_type_spin, payment_terms_spin;

    String[] units = {"Select ", "Pcss", "MT", "20Ft", "40Ft", "High Res", "Other"};


//    String[] quantity = {"Select Minimum Quantity", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};

    String[] post_of_discharge = {"Select", "India", "Brazil", "USA", "South Africa", "NewIsland"};

    String[] require_price_type = {"Select", "ExFactory", "FOR", "CNF", "CIF","FOB","Other"};

    String[] payment_term = {"Select", "TT", "LC", "Advance", "Not Disclose", "Other"};

    String[] required_quote = {"Select", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Other"};

    String minimum_unit, post_of_dischar, require_price, paymentTerm, requiredQuote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requiement_post);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        back_img = findViewById(R.id.back_img);
        submit_req_btn = findViewById(R.id.submit_req_btn);
        required_specification = findViewById(R.id.required_specification);
        target_price_edt = findViewById(R.id.target_price_edt);
        minimum_unit_spin = findViewById(R.id.minimum_unit_spin);
        quantity_edt = findViewById(R.id.quantity_edt);
        post_of_discharge_edt = findViewById(R.id.post_of_discharge_edt);
        requird_price_type_spin = findViewById(R.id.requird_price_type_spin);
        payment_terms_spin = findViewById(R.id.payment_terms_spin);
        required_quote_edt = findViewById(R.id.required_quote_spin);

        ArrayAdapter minimum_unit_adapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,
                units);
        minimum_unit_spin.setAdapter(minimum_unit_adapter);

      /*  ArrayAdapter minimum_qty_adapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,
                quantity);
        minimum_quantity_spin.setAdapter(minimum_qty_adapter);*/

      /*  ArrayAdapter postOfDischargeAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,
                post_of_discharge);
        country_drop_spinner.setAdapter(postOfDischargeAdapter);
*/
        ArrayAdapter requiredPriceAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,
                require_price_type);
        requird_price_type_spin.setAdapter(requiredPriceAdapter);


        ArrayAdapter payment_termAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,
                payment_term);
        payment_terms_spin.setAdapter(payment_termAdapter);




        minimum_unit_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                minimum_unit = units[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

      /*  minimum_quantity_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                minimum_qty = quantity[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/

 /*       country_drop_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                post_of_dischar = post_of_discharge[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
*/
        requird_price_type_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                require_price = require_price_type[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        payment_terms_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                paymentTerm = payment_term[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        submit_req_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (required_specification.getText().toString().equals("")) {
                    required_specification.setFocusable(true);

                    required_specification.setError("Enter Your Requirement Specification");
                } else {
                    if (minimum_unit.equals("Select Minimum Unit")) {
                        Toast.makeText(RequiementPostActivity.this, "Please Select Unti", Toast.LENGTH_SHORT).show();

                    } else {
                        if (quantity_edt.getText().toString().equals("")) {
                            Toast.makeText(RequiementPostActivity.this, "Please Select Quantity", Toast.LENGTH_SHORT).show();

                        } else {
                            if (post_of_discharge_edt.getText().toString().equals("")) {
                                post_of_discharge_edt.setFocusable(true);
                                post_of_discharge_edt.setError("Enter Country Name");

                            } else {
                                if (require_price.equals("Required Price Type")) {
                                    Toast.makeText(RequiementPostActivity.this, "Please Select Required Price Type", Toast.LENGTH_SHORT).show();

                                } else {
                                    if (paymentTerm.equals("Select Payment Terms")) {
                                        Toast.makeText(RequiementPostActivity.this, "Please Select Payment Term", Toast.LENGTH_SHORT).show();

                                    } else {
                                        if (required_quote_edt.getText().toString().equals("")) {
                                            required_quote_edt.setFocusable(true);
                                            required_quote_edt.setError("Enter");

                                        } else {
                                            Toast.makeText(RequiementPostActivity.this, "Requirement Post Successfully Posted", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(RequiementPostActivity.this, HomeActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                                            startActivity(intent);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });

    }

    private void postRequirements(){

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if(jsonObject.getString("result").equals("true")){

                        progressDialog.dismiss();
                    }else {
                        progressDialog.dismiss();

                        Toast.makeText(RequiementPostActivity.this, ""+jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    progressDialog.dismiss();

                    Toast.makeText(RequiementPostActivity.this, ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Toast.makeText(RequiementPostActivity.this, ""+error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String > map = new HashMap<>();


                return map;

            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }

}