package com.social.mitra.interfa;

public interface likesItemClick {

    void likesClick(String likes_licked);
}
