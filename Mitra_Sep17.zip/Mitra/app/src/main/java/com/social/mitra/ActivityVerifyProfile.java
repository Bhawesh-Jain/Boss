package com.social.mitra;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.verify_profile;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.sessionData.Session;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

public class ActivityVerifyProfile extends AppCompatActivity {

    ImageView verify_user_profile,image_selection,back_btn_profile_icon;
    TextView txt_change_profile,btn_user_verify_profile,logout_without_signUp_home;
    EditText first_name_user,last_name_user;

    String user_id;
    Session session;
    File IMAGE;
    String VERIFY_PROFILE;
    String profile_Status = " ";
    String form_status = " ";
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    public static final int RESULT_GALLERY = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_profile);
        session = new Session(ActivityVerifyProfile.this);
        verify_user_profile = findViewById(R.id.verify_user_profile);
        image_selection = findViewById(R.id.image_selection);
        txt_change_profile = findViewById(R.id.txt_change_profile);
        btn_user_verify_profile = findViewById(R.id.btn_user_verify_profile);
        first_name_user = findViewById(R.id.first_name_user);
        last_name_user = findViewById(R.id.last_name_user);
        back_btn_profile_icon = findViewById(R.id.back_btn_profile_icon);
        logout_without_signUp_home = findViewById(R.id.logout_without_signUp_home);

        back_btn_profile_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        if (getIntent() != null) {
            profile_Status = getIntent().getStringExtra("status_key");
            form_status = getIntent().getStringExtra("form_status");
            Log.e(TAG, "----pro_status"+profile_Status);
            Log.e(TAG, "----form_status"+form_status);
        }

        user_id = session.getUser_Id();
        Log.e(TAG, "--user_id__onCreate: "+user_id );
//        VERIFY_PROFILE = session.getProfile_status();
//        Log.e(TAG, "--ActivityVerifyProfile_VERIFY_PROFILE: "+VERIFY_PROFILE);


        logout_without_signUp_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityVerifyProfile.this, SelectLanguageActivity.class);
                startActivity(intent);
                finish();
            }
        });

        image_selection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(
                        ActivityVerifyProfile.this);
                myAlertDialog.setTitle("Upload Pictures Option");
                myAlertDialog.setMessage("How do you want to set your picture?");

                myAlertDialog.setPositiveButton("Camera",
                        new DialogInterface.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.M)
                            public void onClick(DialogInterface arg0, int arg1) {
                                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                    requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                                } else {
                                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                                    startActivityForResult(cameraIntent, CAMERA_REQUEST);

                                }
                            }
                        });

                myAlertDialog.setNegativeButton("Gallery",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface arg0, int arg1) {

                                Intent galleryIntent = new Intent(
                                        Intent.ACTION_PICK,
                                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                startActivityForResult(galleryIntent , RESULT_GALLERY );

                            }
                        });
                myAlertDialog.show();


            }
        });




        btn_user_verify_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Verify_profile(user_id);


            }
        });


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
            else
            {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            verify_user_profile.setImageBitmap(photo);
//            IMAGE = bitmapToFile(ActivityVerifyProfile.this, photo);
            Log.e(TAG, "-----CAMERA_IMAGE_onActivityResult: " + IMAGE);

        } else if (requestCode == RESULT_GALLERY && resultCode == Activity.RESULT_OK) {
            Uri selectedImage = data.getData();
            verify_user_profile.setImageURI(selectedImage);
            IMAGE = new File(selectedImage.getPath());
            Log.e(TAG, "-----GALLERY__IMAGE_onActivityResult: " + IMAGE);
        }
    }


    private void Verify_profile(String user_id) {

        Log.e("TAG", "Update_profile: ");

        ProgressDialog progressDialog = new ProgressDialog(this);

        String first_name = first_name_user.getText().toString();
        String last_name = last_name_user.getText().toString();

        AndroidNetworking.upload(Base_Url + verify_profile)
                .addMultipartParameter("user_id", user_id)
                .addMultipartFile("image", IMAGE)
                .addMultipartParameter("fname", first_name)
                .addMultipartParameter("lname", last_name)
                //.setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            Log.d("---rrrProfile", "UpdateProfileActivityuAPIresponse"+jsonObject.toString());
                            // JSONObject obj = new JSONObject(response);
                            progressDialog.dismiss();
                            String result = jsonObject.getString("result");
                            String msg = jsonObject.getString("msg");


                            if (result.equalsIgnoreCase("true")) {

                                final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(ActivityVerifyProfile.this);
                                View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.bottom_sign_up_layout, null);
                                mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                mBottomSheetDialog.setContentView(sheetView);
                                mBottomSheetDialog.setCanceledOnTouchOutside(true);


                                TextView txt_btn_not_now,txt_btn_agree;
                                LinearLayout layout_not_now,layout_agree;
                                txt_btn_not_now = mBottomSheetDialog.findViewById(R.id.txt_btn_not_now);
                                txt_btn_agree = mBottomSheetDialog.findViewById(R.id.txt_btn_agree);
                                layout_not_now = mBottomSheetDialog.findViewById(R.id.layout_not_now);
                                layout_agree = mBottomSheetDialog.findViewById(R.id.layout_agree);

                                txt_btn_not_now.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
//                                        txt_btn_not_now.setBackgroundResource(R.color.white);
//                                        layout_not_now.setBackgroundResource(R.drawable.btn_accept_new_bg);
//                                        layout_agree.setBackgroundResource(R.drawable.yellow_light_bg);
//                                        Verify_profile(user_id);
                                        Intent intent = new Intent(ActivityVerifyProfile.this, HomeActivity.class);
                                        intent.putExtra("status_key",profile_Status);
                                        intent.putExtra("form_status",form_status);
                                    startActivity(intent);
                                    }
                                });
                                txt_btn_agree.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
//                                        layout_agree.setBackgroundResource(R.drawable.btn_accept_new_bg);
//                                        layout_not_now.setBackgroundResource(R.drawable.yellow_light_bg);
//                                        txt_btn_agree.setBackgroundResource(R.color.white);
//                                        Verify_profile(user_id);
                                         Intent intent = new Intent(ActivityVerifyProfile.this,HomeActivity.class);
                                        intent.putExtra("status_key",profile_Status);
                                        intent.putExtra("form_status",form_status);
                                        startActivity(intent);
                                    }

                                });
                                mBottomSheetDialog.show();

                                Toast.makeText(ActivityVerifyProfile.this, msg, Toast.LENGTH_SHORT).show();
//                                Intent intent = new Intent(ActivityVerifyProfile.this, HomeActivity.class);
//                                startActivity(intent);
                            } else {

                                Toast.makeText(ActivityVerifyProfile.this, msg, Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
                        progressDialog.dismiss();

                    }
                });


    }





}

