package com.social.mitra.sessionData;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.social.mitra.activity.SplashActivity;
import com.social.mitra.model.FilterModel;

public class Session {

    public static final String language = "language";
    public static final String english = "English";
    public static final String hindi = "Hindi";
    public static final String User_Id = "user_id";
    public static final String Name = "name";
    public static final String Mobile = "mobile";
    public static final String Email = "email";
    public static final String ProfilePic = "profilepic";
    private static final String UserData = "UserData";
    private static final String IS_LOGGEDIN = "isLoggedIn";
    private static final String STATUS = "status";
    private static final String Checked = "checked";
    private static final String ProfessionCateId = "professioncateid";
    private static final String ProfessionCateNAME = "professioncatename";
    private static final String SubcateId = "subcateid";
    private static final String SubcateNAME = "Subcatename";
    private static final String HOMEUSERBNAME = "homeusername";
    private static final String EXPERIENCE = "experience";
    private static final String APPTYPE = "apptype";
    private static final String Pro_Status = "pro_status";
    private static final String Form_Status = "form_status";
    private static final String CITY_NAME = "city_name";
    private static final String Profeesiona_Sub_Cate_Id = "profession_sub_cate_id";
    private static final String LAT_ = "lat_";
    private static final String LONG_ = "long_";
    private static final String COMID = "comid";
    private static SharedPreferences userData;
    private Context _context;
    private SharedPreferences.Editor editor;

    public Session(Context context) {
        this._context = context;
        userData = _context.getSharedPreferences(UserData, Context.MODE_PRIVATE);
        editor = userData.edit();
        editor.apply();
    }

    public String getStaTus() {

        return userData.getString(APPTYPE, "");
    }

    public void setStaTus(String status_) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(STATUS, status_);
        editor.apply();
    }

    public String getAppTYpe() {

        return userData.getString(APPTYPE, "");
    }

    public void setAppTYpe(String appTYpe) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(APPTYPE, appTYpe);
        editor.apply();
    }

    public String getHomeUserName() {

        return userData.getString(HOMEUSERBNAME, "");
    }

    public void setHomeUserName(String homeuser_name) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(HOMEUSERBNAME, homeuser_name);
        editor.apply();
    }

    public void setProfessionCateNAME(String procate_name) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(ProfessionCateNAME, procate_name);
        editor.apply();
    }

    public String getProfessionNAME() {

        return userData.getString(ProfessionCateNAME, "");
    }

    public String getEX_Name() {

        return userData.getString(EXPERIENCE, "");
    }

    public void setEX_Name(String experience) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(EXPERIENCE, experience);
        editor.apply();
    }

    public void setcity_name(String city_name) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(CITY_NAME, city_name);
        editor.apply();
    }

    public String getcity_name() {

        return userData.getString(CITY_NAME, "");
    }


    public String get_current_lat() {

        return userData.getString(LAT_, "");
    }

    public void set_current_lat(String latitute) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(LAT_, latitute);
        editor.apply();
    }

    public String get_current_longg() {

        return userData.getString(LONG_, "");
    }

    public void set_current_longg(String longgg) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(LONG_, longgg);
        editor.apply();
    }

    public String getForm_status() {

        return userData.getString(Form_Status, "");
    }

    public void setForm_status(String form_status) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Form_Status, form_status);
        editor.apply();
    }

    public String getProfile_status() {

        return userData.getString(Pro_Status, "");
    }

    public void setProfile_status(String pro_status) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Pro_Status, pro_status);
        editor.apply();
    }

    public String getUser_Id() {

        return userData.getString(User_Id, "");
    }

    public void setUser_Id(String user_id) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(User_Id, user_id);
        editor.apply();
    }

    public void setProfessionCateIDD(String pro_cate_id) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(ProfessionCateId, pro_cate_id);
        editor.apply();
    }

    public String get_Profession_cate_id() {

        return userData.getString(ProfessionCateId, "");
    }

    public void set_Profession_Sub_cate_id(String pro_sub_cat_id) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Profeesiona_Sub_Cate_Id, pro_sub_cat_id);
        editor.apply();
    }

    public String get_Profession_Subcate_id() {

        return userData.getString(Profeesiona_Sub_Cate_Id, "");
    }

    public String getSubcate_Name() {

        return userData.getString(SubcateId, "");
    }

    public void setSubcate_Name(String subCate_name) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(SubcateNAME, subCate_name);
        editor.apply();
    }

    public String getSubcate_Id() {

        return userData.getString(SubcateId, "");
    }

    public void setSubcate_Id(String subCate_id) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(SubcateId, subCate_id);
        editor.apply();
    }

    public String getChecked() {

        return userData.getString(Checked, "");
    }

    public void setChecked(String checked) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Checked, checked);
        editor.apply();
    }

    public String getMobile() {
        return userData.getString(Mobile, "");
    }

    public void setMobile(String mobile) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Mobile, mobile);
        editor.apply();
    }

    public String getName() {
        return userData.getString(Name, "");
    }

    public void setName(String Name) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Name, Name);
        editor.apply();
    }

    public String getEmail() {

        return userData.getString(Email, "");
    }

    public void setEmail(String Email) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Email, Email);
        editor.apply();
    }

    public void setValue(String Key, String Value) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(Key, Value);
        editor.apply();
    }

    public FilterModel getFilerModel(String key) {
        String json = getValue(key);
        return new Gson().fromJson(json, FilterModel.class);
    }

    public Object getObject(String key, Class<?> classOfT) {
        String json = getValue(key);
        return new Gson().fromJson(json, classOfT);
    }

    public void putObject(String key, Object obj) {
        Gson gson = new Gson();
        setValue(key, gson.toJson(obj));
    }

    public String getValue(String Key) {
        return userData.getString(Key, "");
    }

    public String getEditProfilePic() {

        return userData.getString(ProfilePic, "");
    }

    public void setEditProfilePic(String ProfilePic1) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putString(ProfilePic, ProfilePic1);
        editor.apply();
    }

    public void setLogin(boolean isLoggedIn) {
        SharedPreferences.Editor editor = userData.edit();
        editor.putBoolean(IS_LOGGEDIN, isLoggedIn);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return userData.getBoolean(IS_LOGGEDIN, false);
    }

    public void logout() {
        editor.clear();
        editor.apply();
        Intent showLogin = new Intent(_context, SplashActivity.class);
        showLogin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        showLogin.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        _context.startActivity(showLogin);
    }
}
