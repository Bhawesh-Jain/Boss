package com.social.mitra;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.adapter.ProfessionalAdapterCategory.subCatItems;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_main_category;
import static com.social.mitra.util.BaseUrl.update_main_catsubcat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.adapter.ProfessionalAdapterCategory;
import com.social.mitra.interfa.Profession_click;
import com.social.mitra.model.ProfessionalNameList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProfessionalCategoryList extends AppCompatActivity {

    ArrayList<ProfessionalNameList> professionalNameLists = new ArrayList<>();
    EditText professional_search;
    ImageView back_pro_cate;
    RecyclerView professional_cate_recycler, professional_sub_cate_recycler;
    Session session;
    Button btn_next_for_profile;
    String city_name;
    String Category_name;
    RelativeLayout LayoutCate_List_Progress;
    String cate_status;
    String MyType = "";
    String val;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_professional_category);

        session = new Session(ProfessionalCategoryList.this);
        back_pro_cate = findViewById(R.id.back_pro_cate);
        professional_search = findViewById(R.id.professional_search);
        professional_cate_recycler = findViewById(R.id.professional_cate_recycler);
        professional_sub_cate_recycler = findViewById(R.id.professional_sub_cate_recycler);
        btn_next_for_profile = findViewById(R.id.btn_next_for_profile);
        LayoutCate_List_Progress = findViewById(R.id.LayoutCate_List_Progress);

        if (getIntent() != null) {
            city_name = getIntent().getStringExtra("LOC");
            MyType = getIntent().getStringExtra("KeyType");
        }

        back_pro_cate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Get_Main_Category(session.getUser_Id());

        btn_next_for_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String subCatId = "";
                if (subCatItems.size() != 0){
                    for (int i =0;i<subCatItems.size();i++){
                        String catId;
                        if (i != subCatItems.size()-1)
                            catId = subCatItems.get(i)+",";
                        else
                            catId = subCatItems.get(i);
                        subCatId = subCatId.concat(catId);
                    }
                    Update_Main_CatSubcat(session.getUser_Id(), val, subCatId);
                }
            }
        });
    }

    private void Update_Main_CatSubcat(String user_id, String cate_id, String sUB_cate_id) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + update_main_catsubcat, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    progressDialog.dismiss();

                    Log.e(TAG, "onResponse: Update_Main_CatSubcat" + response);
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONObject data = jsonObject.getJSONObject("data");

                        String Name_Cate = data.getString("name");

                        Log.e(TAG, "++++++Name_Cate: " + Name_Cate);

                        Intent intent = new Intent(ProfessionalCategoryList.this, ProfileCreationActivity.class);

                        intent.putExtra("Cate_status", cate_status);
                        intent.putExtra("cate_name", Name_Cate);
                        startActivity(intent);
                    } else {
                        progressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }
            }
        }, error -> {
            progressDialog.dismiss();
            Toast.makeText(ProfessionalCategoryList.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("cat_id", cate_id);
                map.put("subcat_id", sUB_cate_id);

                Log.e(TAG, "getParams:UpdateCateSubonResponse    " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void Get_Main_Category(String user_id) {
        LayoutCate_List_Progress.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_main_category, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    LayoutCate_List_Progress.setVisibility(View.GONE);
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObject1 = jsonObject.getJSONObject("category_status");

                    cate_status = jsonObject1.getString("main_category_updated");

                    Log.e(TAG, "==onResponse:Get_Main_Category" + response);
                    Log.e(TAG, "----cate_status: " + cate_status);

                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Professional_ID = dataObj.getString("id");
                            String Profession_name = dataObj.getString("name");
                            String Profession_image = dataObj.getString("image");

                            ProfessionalNameList professionalNameList = new ProfessionalNameList(Profession_image, Profession_name, Professional_ID);
                            professionalNameLists.add(professionalNameList);
                        }

                        ProfessionalAdapterCategory professionalAdapterCategory = new ProfessionalAdapterCategory(ProfessionalCategoryList.this, professionalNameLists, new Profession_click() {
                            @Override
                            public void Profession_click(ProfessionalNameList item, ProfessionalNameList itemName) {
                                val = item.getProfession_Id();
                                session.setProfessionCateIDD(val);
                                Category_name = item.getProfession_name();

                                Log.e(TAG, "_____Category_name: " + Category_name);
                            }
                        });
                        LinearLayoutManager layoutManager = new LinearLayoutManager(ProfessionalCategoryList.this, LinearLayoutManager.VERTICAL, false);
                        professional_cate_recycler.setLayoutManager(layoutManager);
                        professional_cate_recycler.setAdapter(professionalAdapterCategory);
                    } else {
                        LayoutCate_List_Progress.setVisibility(View.GONE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    LayoutCate_List_Progress.setVisibility(View.GONE);
                }
            }
        }, error -> {
            LayoutCate_List_Progress.setVisibility(View.GONE);
            Toast.makeText(ProfessionalCategoryList.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("type", MyType);

                Log.e(TAG, "getParams:Get_Main_category -" + map);
                return map;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}