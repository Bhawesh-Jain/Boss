package com.social.mitra;

import static android.content.ContentValues.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_profile;
import static com.social.mitra.util.BaseUrl.login;
import static com.social.mitra.util.BaseUrl.subCatArray;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.core.motion.utils.Oscillator;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.RequestManager;
import com.social.mitra.activity.OtpVerificationActivity;
import com.social.mitra.adapter.User_Selected_SubCateAdapter;
import com.social.mitra.model.UserSelected_Subcat;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class AboutFragment extends Fragment {
    TextView edit_profile, mobile_tv, language_tv, txtProfession, company__, my_additionalNo;
    View root;
    Session session;
    String User_ID = "";
    String Mobile_Number;
    String lang = "English";
    String company = "self-employed";
    TextView mail_tv, company_tv;
    RecyclerView rvsubcat;
    ArrayList<UserSelected_Subcat> userSelected_subcats = new ArrayList<>();
    private TextView pincode_tv;
    private RelativeLayout mobile_layout, language_layout, company_layout, pincode_layout, additionalNumber_layout;
    private LinearLayout mail_layout, profession_layout, llsubcat;

    public AboutFragment() {

    }

    public AboutFragment(String user_ID) {
        this.User_ID = user_ID;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.fragment_about, container, false);
        company__ = root.findViewById(R.id.my_company);
        edit_profile = root.findViewById(R.id.edit_profile);
        mobile_tv = root.findViewById(R.id.set_mobile_num);
        language_tv = root.findViewById(R.id.my_language);
        txtProfession = root.findViewById(R.id.txtProfession);
        mail_tv = root.findViewById(R.id.txtmail);
        company_tv = root.findViewById(R.id.txtcom);
        pincode_tv = root.findViewById(R.id.txtpinc);
        my_additionalNo = root.findViewById(R.id.my_additionalNo);
        rvsubcat = root.findViewById(R.id.rvsubcat);

        mobile_layout = root.findViewById(R.id.mobile_no_layout);
        profession_layout = root.findViewById(R.id.profession_layout);
        language_layout = root.findViewById(R.id.language_layout);
        mail_layout = root.findViewById(R.id.email_layout);
        company_layout = root.findViewById(R.id.company_layout);
        pincode_layout = root.findViewById(R.id.pincode_layout);
        additionalNumber_layout = root.findViewById(R.id.additional_layout);

        session = new Session(getActivity());
        if (User_ID.equalsIgnoreCase(""))
            User_ID = session.getUser_Id();
        else edit_profile.setVisibility(View.GONE);
        Mobile_Number = session.getMobile();

        Log.e(TAG, "AboutFragment_Mobile_Number: " + Mobile_Number);
        Log.e(TAG, "AboutFragment_User_id: " + User_ID);

        mobile_tv.setText(Mobile_Number);
        language_tv.setText(session.getValue(Session.language));
        company__.setText(company);

        edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), UpdateDetailsActivity.class);
                startActivity(intent);
            }
        });
        Get_Profile(User_ID);
        checkAboutVis();

        return root;
    }

    private void checkAboutVis() {
        if (mobile_tv.getText().length() == 0) {
            mobile_layout.setVisibility(View.GONE);
        } else mobile_layout.setVisibility(View.VISIBLE);
        if (language_tv.getText().length() == 0) {
            language_layout.setVisibility(View.GONE);
        } else language_layout.setVisibility(View.VISIBLE);
        if (language_tv.getText().length() == 0) {
            profession_layout.setVisibility(View.GONE);
        } else profession_layout.setVisibility(View.VISIBLE);
        if (mail_tv.getText().length() == 0) {
            mail_layout.setVisibility(View.GONE);
        } else mail_layout.setVisibility(View.VISIBLE);
        if (company_tv.getText().length() == 0) {
            company_layout.setVisibility(View.GONE);
        } else company_layout.setVisibility(View.VISIBLE);
        if (pincode_tv.getText().length() == 0) {
            pincode_layout.setVisibility(View.GONE);
        } else pincode_layout.setVisibility(View.VISIBLE);
        if (my_additionalNo.getText().length() == 0) {
            additionalNumber_layout.setVisibility(View.GONE);
        } else additionalNumber_layout.setVisibility(View.VISIBLE);
    }

    private void Get_Profile(String user_id) {
        Log.e(Oscillator.TAG, "ProfileFragment_Get_Profile: ");
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(Oscillator.TAG, "onResponse: *****Get-Profile About -->      " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONObject data = jsonObject.getJSONObject("data");

                        String Mobile_ = data.getString("mobile");
                        String email = data.getString("email");
                        String category_name = data.getString("category_name");
                        String location = data.getString("location");
                        String company = data.getString("company");
                        String language = data.getString("language");
                        String additional_mobile = data.getString("additional_mobile");

                        my_additionalNo.setText(additional_mobile);

                        if (!Mobile_.equalsIgnoreCase(""))
                            mobile_tv.setText(Mobile_);
                        if (!category_name.equalsIgnoreCase(""))
                            txtProfession.setText(category_name);
                        if (!language.equalsIgnoreCase(""))
                            language_tv.setText(language);
                        if (!company.equalsIgnoreCase(""))
                            company__.setText(company);
                        if (!email.equalsIgnoreCase(""))
                            mail_tv.setText(email);
                        if (!location.equalsIgnoreCase(""))
                            pincode_tv.setText(location);
                        checkAboutVis();
                        subCatArray(session.getUser_Id());
                    } else checkAboutVis();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                checkAboutVis();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);

                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    private void subCatArray(String user_idd) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + subCatArray, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e(TAG, "==onResponse:get_my_community" + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        userSelected_subcats.clear();
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String id_ID = dataObj.getString("id");
                            String _name = dataObj.getString("name");

                            UserSelected_Subcat jobDataList = new UserSelected_Subcat(id_ID, _name);
                            userSelected_subcats.add(jobDataList);
                        }
                        User_Selected_SubCateAdapter user_selected_subCateAdapter = new User_Selected_SubCateAdapter(getContext(), userSelected_subcats);
                        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
//                        rvsubcat.setLayoutManager(layoutManager);
                        rvsubcat.setLayoutManager(new GridLayoutManager(getContext(), 3));
                        rvsubcat.setAdapter(user_selected_subCateAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(getContext(), "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_idd);

                Log.e(Oscillator.TAG, "getParams:  " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }
}
