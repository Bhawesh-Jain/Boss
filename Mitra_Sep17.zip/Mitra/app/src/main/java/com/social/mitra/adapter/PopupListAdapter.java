package com.social.mitra.adapter;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.interfa.On_cat_Click;
import com.social.mitra.interfa.On_catname_Click;
import com.social.mitra.model.ProfessionalNameList;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class PopupListAdapter extends RecyclerView.Adapter<PopupListAdapter.MyViewHolder> {
    private static final String TAG = "PopupListAdapter";
    Context context;
    ArrayList<ProfessionalNameList> notificationModels;
    Dialog height_dialog;
    On_cat_Click on_cat_click;
    On_catname_Click on_catname_click;
    public PopupListAdapter(Context context, ArrayList<ProfessionalNameList> notificationModels, Dialog height_dialog, On_cat_Click on_cat_click,On_catname_Click on_catname_click) {
        this.context = context;
        this.notificationModels = notificationModels;
        this.height_dialog = height_dialog;
        this.on_cat_click = on_cat_click;
        this.on_catname_click = on_catname_click;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {

        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.category_layout, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull PopupListAdapter.MyViewHolder holder, int position) {

        Log.e(TAG, "onBindViewHolder:<>><<><><>>   "+notificationModels.get(position).getProfession_Id() );
        Log.e(TAG, "onBindViewHolder:<>><<><><>>   "+notificationModels.get(position).getProfession_image() );
        Log.e(TAG, "onBindViewHolder:<>><<><><>>   "+notificationModels.get(position).getProfession_name() );
        holder.user_notifi.setText(notificationModels.get(position).getProfession_name());

        holder.user_notifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                on_cat_click.onClick(notificationModels.get(position).getProfession_Id());
                on_catname_click.onname(notificationModels.get(position).getProfession_name());
                Log.e(TAG, "getProfession_name: "+notificationModels.get(position).getProfession_name() );
                height_dialog.dismiss();
            }
        });
    }


    @Override
    public int getItemCount() {
        return notificationModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView user_notifi;

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            user_notifi = itemView.findViewById(R.id.user_notifi);
            user_notifi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    user_notifi.setBackgroundColor(context.getResources().getColor(R.color.gray_light));
                }
            });
        }

    }
}
