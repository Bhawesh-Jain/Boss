package com.social.mitra.adapter;

import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.Sec_Cate_img_Url;
import static com.social.mitra.util.BaseUrl.get_second_subcategory;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.interfa.MSubCateClick;
import com.social.mitra.interfa.MaterialCateClick;
import com.social.mitra.model.MaterialCateList;
import com.social.mitra.model.MaterialSubCateList;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MCateListSAdapter extends RecyclerView.Adapter<MCateListSAdapter.MyViewHolder>{

    ArrayList<MaterialCateList> materialCateListArrayList;
    Context context;
    MaterialCateClick listner;
    String cate_id;
    ArrayList<MaterialSubCateList> materialSubCateListArrayList = new ArrayList<>();

    public MCateListSAdapter(ArrayList<MaterialCateList> materialCateListArrayList, Context context, MaterialCateClick listner) {
        this.materialCateListArrayList = materialCateListArrayList;
        this.context = context;
        this.listner = listner;
    }

    @NonNull
    @Override
    public MCateListSAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_material_category,parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MCateListSAdapter.MyViewHolder holder, int position) {

        if (materialCateListArrayList.size() > 0){


            MaterialCateList materialCateList = materialCateListArrayList.get(position);

            holder.txt_material_list.setText(materialCateList.getMCate_name());

            Glide.with(context).load(Sec_Cate_img_Url + materialCateList.getMCate_image()).into(holder.Material_image);

            cate_id = materialCateList.getMCate_Id();

            holder.txt_material_list.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listner.MCateClick(materialCateList,materialCateList);
//                    Get_Second_SubCategory(cate_id,holder.material_sub_cate_recycler);
                }
            });
        }
    }

    private void Get_Second_SubCategory(String cate_id, RecyclerView material_sub_cate_recycler) {

        materialSubCateListArrayList.clear();

        Log.e(TAG, "***Get_Main_Subcat: ");
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_second_subcategory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "==onResponse:Get_Main_Category"+ response);
                    progressDialog.dismiss();
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            String Material_subCate_ID = dataObj.getString("id");

                            String Material_SubCate_name = dataObj.getString("name");

                            MaterialSubCateList materialSubCateList = new MaterialSubCateList(Material_subCate_ID,Material_SubCate_name);

                            materialSubCateListArrayList.add(materialSubCateList);
                        }

                        MSubCateAdapter mSubCateAdapter = new MSubCateAdapter(context, materialSubCateListArrayList, new MSubCateClick() {
                            @Override
                            public void MSubClicked(MaterialSubCateList itemClicked) {
                                itemClicked.getMSubCateId();
                                Log.e(TAG, "===itemClicked.getMSubCateId(): "+itemClicked.getMSubCateId());
                            }
                        });

                        LinearLayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
                        material_sub_cate_recycler.setLayoutManager(layoutManager);
                        material_sub_cate_recycler.setAdapter(mSubCateAdapter);
                        material_sub_cate_recycler.setVisibility(View.VISIBLE);


                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(context, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("cat_id",cate_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:***Get_Main_Subcat"+map );
                return map;
            }
        };

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    @Override
    public int getItemCount() {
        return materialCateListArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView Material_image;
        TextView txt_material_list;
        RecyclerView material_sub_cate_recycler;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Material_image = itemView.findViewById(R.id.Material_image);
            txt_material_list = itemView.findViewById(R.id.txt_material_list);
            material_sub_cate_recycler = itemView.findViewById(R.id.material_sub_cate_recycler);
        }
    }
}
