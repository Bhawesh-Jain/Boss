package com.social.mitra.model;

public class ReelComment {
    private String id,
            user_id,
            reel_id,
            comment,
            created_date,
            user_name,
            user_image, path;

    public ReelComment(String id, String user_id, String reel_id, String comment, String created_date, String user_name, String user_image, String path) {
        this.id = id;
        this.user_id = user_id;
        this.reel_id = reel_id;
        this.comment = comment;
        this.created_date = created_date;
        this.user_name = user_name;
        this.user_image = user_image;
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getReel_id() {
        return reel_id;
    }

    public void setReel_id(String reel_id) {
        this.reel_id = reel_id;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }
}
