package com.social.mitra.util;

public class BaseUrl {

    //Base Url
//    public static String Base_Url ="https://kuchvkharido.xyz/sameer/mitra/Api/";
    public static String Base_Url ="http://logicaltest.website/sameer/mitra/Api/";

    

    //Image and Video Base Url
    public static String Profession_icon = "http://logicaltest.website/sameer/mitra/assets/images/cat_image/";
    public static String City_url = "http://logicaltest.website/sameer/mitra/assets/images/cities/";
    public static String IMAGE_URL = "http://logicaltest.website/sameer/mitra/assets/images/users/";
    public static String Cate_image_url ="http://logicaltest.website/sameer/mitra/assets/images/signup_cat_image/";
    public static String Sec_Cate_img_Url = "http://logicaltest.website/sameer/mitra/assets/images/cat_image/";
    public static String Post_image_Url ="http://logicaltest.in/Exim_papa/assets/images/gallery/";
    public static String Post_Video_Url ="http://logicaltest.in/Exim_papa/assets/video/";
    public static String USER_JOB_URL ="http://logicaltest.website/sameer/mitra/assets/images/users/";
    public static String COMUNITY_PATH_URL ="http://logicaltest.website/sameer/mitra/assets/images/community/";


    //end point api
    public static String signup_user ="signup_user";
    public static String resend_otp ="resend_otp";
    public static String login ="login";
    public static String verify_otp ="verify_otp";
    public static String logout ="logout";
    public static String get_verify_profilestatus ="get_verify_profilestatus";
//    public static String get_cities ="get_cities";
    public static String get_state ="get_state";
    public static String get_experience ="get_experience";
    public static String get_promotion_banner ="get_promotion_banner";
    public static String get_second_category ="get_second_category";
    public static String get_second_subcategory ="get_second_subcategory";
    public static String like_unlike_community ="like_unlike_community";
    public static String load_comments ="load_comments";
    public static String comment_community ="comment_community";
    public static String delete_community ="delete_community";
    public static String like_unlike_community_comments ="like_unlike_community_comments";
    public static String get_form_status ="get_form_status";
    public static String get_community_countss ="get_community_countss";
    public static String get_category ="get_category";
    public static String verify_profile ="verify_profile";
    public static String get_subcategory ="get_subcategory";
    public static String update_profile_new ="update_profile_new";
    public static String update_type ="update_type";
    public static String update_details ="update_details";
    public static String update_profile ="update_profile";
    public static String update_main_catsubcat ="update_main_catsubcat";
    public static String update_profile_new_image ="update_profile_new_image";
    public static String update_only_name ="update_only_name";
    public static String update_catsubcat ="update_catsubcat";
    public static String update_main_catsubcat_new ="update_main_catsubcat_new";
    public static String update_extra_detail ="update_extra_detail";
    public static String get_profile ="get_profile";
    public static String get_main_category  ="get_main_category";
    public static String get_main_subcat    ="get_main_subcat";
    public static String add_community ="add_community";
    public static String get_community ="get_community";
    public static String Contact_us ="Contact_us";
    public static String like_unlike ="like_unlike";
    public static String like_unlike_ios ="like_unlike_ios";
    public static String References_unRef ="References_unRef";
    public static String delete_home_post ="delete_home_post";
    public static String count_like ="count_like";
    public static String get_company_type ="get_company_type";
    public static String get_post_by_user_id ="get_post_by_user_id";
    public static String get_single_post ="get_single_post";
    public static String fowllow_to_user ="fowllow_to_user";
    public static String get_my_community ="get_my_community";
    public static String get_cities ="get_cities";
    public static String subCatArray ="subCatArray";
    public static String followUnfollow ="followUnfollow";
    public static String get_folloing_userslist ="get_folloing_userslist";
    public static String get_follower_userslist ="get_follower_userslist";
    public static String get_single_profile ="get_single_profile";
    public static String get_all_categories_users ="get_all_categories_users";
    public static String report_community_post ="report_community_post";
    public static String get_my_design ="get_my_design";
    public static String get_notification_list ="get_notification_list";

    //Reel
    public static String get_reel_categories ="get_reel_categories";
    public static String get_hashtag_list ="get_hashtag_list";
    public static String add_hastags ="add_hastags";
    public static String get_reels ="get_reels";
    public static String add_reels ="add_reels";
    public static String like_reel ="like_reel";
    public static String load_reel_comments ="load_reel_comments";
    public static String comment_on_reel ="comment_on_reel";
    public static String report_reel_post ="report_reel_post";
    public static String get_my_reels ="get_my_reels";

}




