package com.social.mitra;

import static android.content.ContentValues.TAG;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_cities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.core.motion.utils.Oscillator;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.adapter.AdapterCityList;
import com.social.mitra.gps.GPSTracker;
import com.social.mitra.interfa.CityItemClick;
import com.social.mitra.model.CityList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SelectCityActivity extends AppCompatActivity {

    private static final int REQUEST_LOCATION = 1;
    private static final int MY_PERMISSION_ACCESS_COURSE_LOCATION = 12;

    GPSTracker gpsTracker;

    Button btnn_continue;
    ImageView check_six,check_five,check_four,check_three,check_two,check_one;
    RelativeLayout btn_city_six,btn_city_five,btn_city_four,btn_city_three,btn_city_two,btn_city_one;
    ImageView city_back;
    boolean tmp_one = false;
    boolean tmp_two = false;
    boolean tmp_three = false;
    boolean tmp_four = false;
    boolean tmp_five = false;
    boolean tmp_six = false;
    boolean isImageFitToScreen;
    ImageView img_city_six,img_city_five,img_city_four,img_city_three,img_city_two,img_city_one;
    RecyclerView recycler_list_city;
    AdapterCityList adapterCityList;
    ArrayList<CityList> cityListArrayList = new ArrayList<>();
    String VERIFY_PROFILE;
    String form_status;
    ArrayList<String> dataList = new ArrayList<>();
    Session session;
    String User_id;
    TextView Get_Current_loc,btn_current_loc,nxt_button_;
    String locality;
    String city;
    String region_code,zipcode;
    SessionLogOut sessionLogOut;
    String Loc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acti_select_city);
        sessionLogOut = new SessionLogOut(this);
        gpsTracker = new GPSTracker(SelectCityActivity.this);
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        session = new Session(SelectCityActivity.this);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.white));
        User_id = session.getUser_Id();
        Loc  = sessionLogOut.getLocName();


        if (getIntent() != null) {
            VERIFY_PROFILE  = getIntent().getStringExtra("status_key");
            form_status     = getIntent().getStringExtra("form_status");


        }
//        check_six  = findViewById(R.id.check_six);
//        check_five  = findViewById(R.id.check_five);
//        check_four  = findViewById(R.id.check_four);
//        check_three  = findViewById(R.id.check_three);
//        check_two   = findViewById(R.id.check_two);
//        check_one  = findViewById(R.id.check_one);
        btnn_continue  = findViewById(R.id.btnn_continue);
        city_back  = findViewById(R.id.city_back);
        Get_Current_loc  = findViewById(R.id.Get_Current_loc);
        btn_current_loc  = findViewById(R.id.btn_current_loc);
        nxt_button_  = findViewById(R.id.nxt_button_);
        recycler_list_city  = findViewById(R.id.recycler_list_city);
        City_list_data();







//        img_city_one  = findViewById(R.id.img_city_one);
//        img_city_two  = findViewById(R.id.img_city_two);
//        img_city_three  = findViewById(R.id.img_city_three);
//        img_city_four  = findViewById(R.id.img_city_four);
//        img_city_five  = findViewById(R.id.img_city_five);
//        img_city_six  = findViewById(R.id.img_city_six);




//        btn_city_one    = findViewById(R.id.btn_city_one);
//        btn_city_two    = findViewById(R.id.btn_city_two);
//        btn_city_three   = findViewById(R.id.btn_city_three);
//        btn_city_four  = findViewById(R.id.btn_city_four);
//        btn_city_five  = findViewById(R.id.btn_city_five);
//        btn_city_six  = findViewById(R.id.btn_city_six);

//                check_six.setVisibility(GONE);
//                check_five.setVisibility(GONE);
//                check_four.setVisibility(GONE);
//                check_three.setVisibility(GONE);
//                check_two.setVisibility(GONE);
//                check_one.setVisibility(GONE);

        city_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });






//        btn_city_one.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                tmp_one = !tmp_one;
//                check_one.setVisibility(tmp_one ? VISIBLE:GONE);
//                btn_city_one.setBackgroundResource(tmp_one ? R.drawable.background_selectonlang:R.drawable.line_border_bg);
//                btn_city_six.setBackgroundResource(R.drawable.line_border_sec );
//                btn_city_five.setBackgroundResource(R.drawable.line_border_sec );
//                btn_city_four.setBackgroundResource( R.drawable.line_border_sec );
//                btn_city_two.setBackgroundResource( R.drawable.line_border_sec);
//                btn_city_three.setBackgroundResource(R.drawable.line_border_sec);
//                check_six.setVisibility(GONE);
//                check_five.setVisibility(GONE);
//                check_four.setVisibility(GONE);
//                check_three.setVisibility(GONE);
//                check_two.setVisibility(GONE);
//                if(isImageFitToScreen) {
//                    isImageFitToScreen=false;
//                    img_city_one.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT));
//                    img_city_one.setAdjustViewBounds(true);
//                }else{
//                    isImageFitToScreen=true;
//                    img_city_one.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT));
//                    img_city_one.setScaleType(ImageView.ScaleType.FIT_XY);
//                }
//
//
//            }
//        });



//        btn_city_two.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                tmp_two = !tmp_two;
//                check_two.setVisibility(tmp_two ? VISIBLE:GONE);
//                btn_city_two.setBackgroundResource(tmp_two ? R.drawable.background_selectonlang:R.drawable.line_border_bg);
//                btn_city_six.setBackgroundResource(R.drawable.      line_border_bg );
//                btn_city_five.setBackgroundResource(R.drawable.     line_border_bg );
//                btn_city_four.setBackgroundResource(R.drawable.     line_border_bg );
//                btn_city_one.setBackgroundResource(R.drawable.      line_border_bg);
//                btn_city_three.setBackgroundResource(R.drawable.    line_border_bg);
//                check_one.setVisibility(GONE);
//                check_six.setVisibility(GONE);
//                check_five.setVisibility(GONE);
//                check_four.setVisibility(GONE);
//                check_three.setVisibility(GONE);
//
//                if(isImageFitToScreen) {
//                    isImageFitToScreen=false;
//                    img_city_two.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT));
//                    img_city_two.setAdjustViewBounds(true);
//                }else{
//                    isImageFitToScreen=true;
//                    img_city_two.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT));
//                    img_city_two.setScaleType(ImageView.ScaleType.FIT_XY);
//                }
//
//
//            }
//        });


//        btn_city_three.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                tmp_three = !tmp_three;
//                check_three.setVisibility(tmp_three ? VISIBLE : GONE);
//                btn_city_three.setBackgroundResource(tmp_three ? R.drawable.background_selectonlang:R.drawable.line_border_bg);
//                btn_city_six.setBackgroundResource( R.drawable.     line_border_bg);
//                btn_city_five.setBackgroundResource( R.drawable.    line_border_bg);
//                btn_city_four.setBackgroundResource( R.drawable.    line_border_bg);
//                btn_city_one.setBackgroundResource( R.drawable.     line_border_bg);
//                btn_city_two.setBackgroundResource( R.drawable.     line_border_bg);
//                check_six.setVisibility(GONE);
//                check_five.setVisibility(GONE);
//                check_four.setVisibility(GONE);
//                check_two.setVisibility(GONE);
//                check_one.setVisibility(GONE);
//
//
//            }
//        });

//        btn_city_four.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                tmp_four = !tmp_four;
//                check_four.setVisibility(tmp_four ? VISIBLE : GONE);
//                btn_city_four.setBackgroundResource(tmp_four ?R.drawable.background_selectonlang:R.drawable.line_border_bg);
//                btn_city_six.setBackgroundResource( R.drawable.     line_border_bg);
//                btn_city_five.setBackgroundResource( R.drawable.    line_border_bg);
//                btn_city_three.setBackgroundResource( R.drawable.   line_border_bg);
//                btn_city_one.setBackgroundResource(R.drawable.      line_border_bg);
//                btn_city_two.setBackgroundResource(R.drawable.      line_border_bg);
//                check_six.setVisibility(GONE);
//                check_five.setVisibility(GONE);
//                check_three.setVisibility(GONE);
//                check_two.setVisibility(GONE);
//                check_one.setVisibility(GONE);
//
//            }
//        });

//        btn_city_five.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//               tmp_five = !tmp_five;
//                check_five.setVisibility(tmp_five ? VISIBLE : GONE);
//                btn_city_five.setBackgroundResource(tmp_five ? R.drawable.background_selectonlang:R.drawable.line_border_bg);
//                btn_city_six.setBackgroundResource( R.drawable.line_border_bg);
//                btn_city_four.setBackgroundResource(R.drawable.     line_border_bg);
//                btn_city_three.setBackgroundResource( R.drawable.   line_border_bg);
//                btn_city_one.setBackgroundResource(R.drawable.      line_border_bg);
//                btn_city_two.setBackgroundResource(R.drawable.      line_border_bg);
//                check_six.setVisibility(GONE);
//                check_four.setVisibility(GONE);
//                check_three.setVisibility(GONE);
//                check_two.setVisibility(GONE);
//                check_one.setVisibility(GONE);
//
//
//
//            }
//        });

//        btn_city_six.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                tmp_six = !tmp_six;
//                check_six.setVisibility(tmp_six ? VISIBLE:GONE);
//                btn_city_six.setBackgroundResource(tmp_six ? R.drawable.background_selectonlang:R.drawable.line_border_bg);
//                btn_city_five.setBackgroundResource(R.drawable.line_border_bg );
//                btn_city_four.setBackgroundResource(R.drawable.line_border_bg );
//                btn_city_three.setBackgroundResource(R.drawable.line_border_bg );
//                btn_city_one.setBackgroundResource(R.drawable. line_border_bg);
//                btn_city_two.setBackgroundResource(R.drawable. line_border_bg);
//                check_five.setVisibility(GONE);
//                check_four.setVisibility(GONE);
//                check_three.setVisibility(GONE);
//                check_two.setVisibility(GONE);
//                check_one.setVisibility(GONE);
//            }
//        });

    }

    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(SelectCityActivity.this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getLocation() {
        double lat          =    gpsTracker.getLocation().getLatitude();
        double longitude    =  gpsTracker.getLocation().getLongitude();

        Log.e(TAG, "getLocation:lat "+lat );
        Log.e(TAG, "getLocation:longitude "+longitude );

//        Toast.makeText(ActivityLocation.this, gpsTracker.getLocation().toString(), Toast.LENGTH_SHORT).show();


        Geocoder geocoder = new Geocoder(SelectCityActivity.this, Locale.getDefault());
        List<Address>
                addresses = null;
        try {
            addresses = geocoder.getFromLocation(lat, longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (addresses.size() > 0) {
            Address address = addresses.get(0);
            locality     = address.getLocality();
            city         = address.getCountryName();
            region_code  = address.getCountryCode();
            zipcode      = address.getPostalCode();

//            Toast.makeText(ActivityLocation.this, "address =>" + locality, Toast.LENGTH_SHORT).show();
            Get_Current_loc.setText(locality);
            sessionLogOut.setLocName(locality);



        }
/*        if (ActivityCompat.checkSelfPermission(
                ActivityLocation.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                ActivityLocation.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                latitude = String.valueOf(lat);
                longitude = String.valueOf(longi);
                Log.e(TAG, "===latitude=getLocation: "+latitude);
                Log.e(TAG, "===longitude=getLocation: "+longitude);
//                showLocation.setText("Your Location: " + "\n" + "Latitude: " + latitude + "\n" + "Longitude: " + longitude);
            } else {
                Toast.makeText(this, "Unable to find location.", Toast.LENGTH_SHORT).show();
            }
        }*/
    }

    private void City_list_data() {
        Log.e(TAG, "City_list_data: ");
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_cities, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(TAG, "onResponse:City_list_data"+ response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++){

                            JSONObject json_data = jsonArray.getJSONObject(i);
                            String city_id = json_data.getString("id");
                            String city_name = json_data.getString("name");
                            String city_image = json_data.getString("image");

                            CityList cityList  = new CityList(city_id,city_name  );
                            cityListArrayList.add(cityList);

                        }
                        AdapterCityList adapterCityList1 = new AdapterCityList(SelectCityActivity.this, cityListArrayList, new CityItemClick() {
                            @Override
                            public void City_Item_Click(CityList CityId) {
                                CityId.getCityID();
                                CityId.getCityName();
                                Log.e(TAG, "====CityId.getCityName() "+CityId.getCityName());
                                String City_Name = CityId.getCityName();

                                Toast.makeText(SelectCityActivity.this, "city_id"+City_Name, Toast.LENGTH_SHORT).show();
                                btnn_continue.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(SelectCityActivity.this, SelectProfiletypesActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                        });

                        GridLayoutManager gridLayout = new GridLayoutManager(SelectCityActivity.this,3);
                        recycler_list_city.setLayoutManager(gridLayout);
                        recycler_list_city.setAdapter(adapterCityList1);

                    } else {
                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(SelectCityActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> map = new HashMap<>();
//                map.put("mobile",mobile);
//                map.put("fcm_id", "asdfhaiofhoa");
//                Log.e(TAG, "getParams:loginn onResponse "+map );
//                return map;
//            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }
}