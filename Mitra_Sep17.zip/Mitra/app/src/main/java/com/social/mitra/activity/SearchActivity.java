package com.social.mitra.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.mancj.materialsearchbar.MaterialSearchBar;
import com.mancj.materialsearchbar.adapter.SuggestionsAdapter;
import com.social.mitra.R;
import com.social.mitra.adapter.SearchProductAdapter;
import com.social.mitra.model.SearchProductModel;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {

    ImageView back_img;
    TextView search_tv;
    EditText search_edt;
    Session session;
    MaterialSearchBar search_hint;
    ArrayList<SearchProductModel> searchProductModels = new ArrayList<>();
    ArrayList<SearchProductModel> searchProductModelselect = new ArrayList<>();
    RecyclerView search_product_list;

    String country_name[] = {"Rice", "Ring", "Bike", "Car", "Computer"};

    SearchProductAdapter searchProductAdapter;

    List<String> suggestionsList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);


        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        session = new Session(this);
        back_img = findViewById(R.id.back_img);
        search_hint = findViewById(R.id.searchView);
        search_product_list = findViewById(R.id.search_product_list);


        search_hint.enableSearch();



                search_hint.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
                    @Override
                    public void onSearchStateChanged(boolean enabled) {

                    }

                    @Override
                    public void onSearchConfirmed(CharSequence text) {

                        startSearch(text.toString(), true, null, true);

                    }

                    @Override
                    public void onButtonClicked(int buttonCode) {
                        if (buttonCode == MaterialSearchBar.BUTTON_NAVIGATION) {
                            //opening or closing a navigation drawer
                        } else if (buttonCode == MaterialSearchBar.BUTTON_BACK) {
                            search_hint.disableSearch();
                        }
                    }
                });



        search_hint.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                if(suggestionsList.size()>0){

                        search_hint.showSuggestionsList();

                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(s.toString().equalsIgnoreCase(""))
                {

                }else {
                    suggestionsList.clear();

                    for (int i = 0; i < searchProductModels.size(); i++) {

                        if (searchProductModels.get(i).getCountry_name().equalsIgnoreCase(s.toString())) {

                            suggestionsList.add(searchProductModels.get(i).getCountry_name());
                        }
                    }

                    search_hint.updateLastSuggestions(suggestionsList);


                    if(suggestionsList.size()>0){
                        if (!search_hint.isSuggestionsVisible()) {
                            search_hint.showSuggestionsList();
                        }
                    }
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });



        search_hint.setSuggstionsClickListener(new SuggestionsAdapter.OnItemViewClickListener(){

            @Override
            public void OnItemClickListener(int position, View v) {

                if(suggestionsList.size()>0) {
                    String product = suggestionsList.get(position);
                    Intent intent = new Intent(SearchActivity.this, ProductListActivity.class);
                    intent.putExtra("product", product);
                    startActivity(intent);
                }else {
                    search_hint.hideSuggestionsList();
                    Toast.makeText(SearchActivity.this, "Please Search Again", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void OnItemDeleteListener(int position, View v) {
                if(suggestionsList.size()>0) {
                    suggestionsList.remove(position);
                    search_hint.clearSuggestions();
                }else {
                    Toast.makeText(SearchActivity.this, "Please Search Again", Toast.LENGTH_SHORT).show();
                }

            }
        });




        setStaticData();

    }

    private void setStaticData() {
        for (int i = 0; i < 5; i++) {

            SearchProductModel searchProductModel = new SearchProductModel();

            searchProductModel.setCountry_name(country_name[i]);
            searchProductModel.setPost_date("28/06/2021");
            searchProductModel.setPost_discription("fhsfaegfsdv sdhnsg sdgnoas sdgvoasd sdfv");
            searchProductModel.setPost_qty("10");
            searchProductModel.setProduct_id("" + i);
            searchProductModels.add(searchProductModel);
        }


    }

    @Override
    public boolean onQueryTextSubmit(String query) {

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {


        if (!newText.equals("")) {

            searchProductModelselect.clear();

            for (int i = 0; i < searchProductModels.size(); i++) {
                if (searchProductModels.get(i).getCountry_name().equalsIgnoreCase(newText)) {
                    searchProductModelselect.add(searchProductModels.get(i));
                }
            }

            searchProductAdapter = new SearchProductAdapter(this, searchProductModelselect);
            search_product_list.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
            search_product_list.setAdapter(searchProductAdapter);
        } else if(newText.equals("")) {

            searchProductAdapter = new SearchProductAdapter(this, searchProductModelselect);

            searchProductModelselect.clear();
            searchProductAdapter.notifyDataSetChanged();

        }

//        getProductList(session.getUser_Id(), newText);
        return false;
    }

    private void getProductList(final String userId, final String s) {


        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();

                } catch (JSONException e) {
                    progressDialog.dismiss();

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();

                return map;
            }
        };


        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }
}