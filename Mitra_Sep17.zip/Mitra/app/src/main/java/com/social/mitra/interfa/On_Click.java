package com.social.mitra.interfa;

public interface On_Click {

        void onClick(String value);

}
