package com.social.mitra;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static androidx.constraintlayout.core.motion.utils.Oscillator.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.update_type;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.gps.GPSTracker;
import com.social.mitra.sessionData.Session;
import com.social.mitra.sessionData.SessionLogOut;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SelectProfiletypesActivity extends AppCompatActivity {

    private static final int REQUEST_LOCATION = 1;
    private static final int MY_PERMISSION_ACCESS_COURSE_LOCATION = 12;
    TextView messageView, CHOOSE_CITY;
    RelativeLayout homeowner, serviceprovider, material_supplier;
    Context context;
    Resources resources;
    TextView next_btn_activity, Location_name;
    String usertype = " ";
    ImageView green_check, green_check_sec, green_check_third;
    Boolean temp_one = false;
    Boolean temp_two = false;
    Boolean temp_three = false;
    String user_id;
    Session session;
    String verify_staus = "";
    String form_status = "";
    String Varify_pr_status = "0";
    String city_name = "";
    String M_type;
    RelativeLayout LayoutType_Progress;
    SessionLogOut sessionLogOut;
    String Type = "0";
    String City_Name;
    String loca;
    GPSTracker gps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_profiletypes);
        context = getApplicationContext();
        // referencing the text and button views

        sessionLogOut = new SessionLogOut(this);


        messageView = findViewById(R.id.textView);
        homeowner = findViewById(R.id.homeowner);
        serviceprovider = findViewById(R.id.serviceprovider);
        material_supplier = findViewById(R.id.material_supplier);
        next_btn_activity = findViewById(R.id.next_btn_activity);
        CHOOSE_CITY = findViewById(R.id.CHOOSE_CITY);
        Location_name = findViewById(R.id.Location_name);

        LayoutType_Progress = findViewById(R.id.LayoutType_Progress);

        green_check = findViewById(R.id.green_check);
        green_check_sec = findViewById(R.id.green_check_sec);
        green_check_third = findViewById(R.id.green_check_third);

        // setting up on click listener event over the button
        // in order to change the language with the help of
        // LocaleHelper class

        green_check.setVisibility(GONE);
        green_check_sec.setVisibility(GONE);
        green_check_third.setVisibility(GONE);

        session = new Session(SelectProfiletypesActivity.this);
        user_id = session.getUser_Id();
        City_Name = session.getcity_name();

        if (getIntent() != null) {
            verify_staus = getIntent().getStringExtra("status_key");
            form_status = getIntent().getStringExtra("form_status");
            M_type = getIntent().getStringExtra("KeyType");
            loca = getIntent().getStringExtra("LOC");
//            city_name = getIntent().getStringExtra("KEYCITY");
            Log.e(TAG, "SelectProfiletypeloca>>>" + loca);
            Log.e(TAG, "SelectProfiletypesActivity_city_name>>>" + city_name);
            Log.e(TAG, "SelectProfiletypesActivity_form_status>>>" + form_status);
        }

        Log.e(TAG, "---City_Name: " + City_Name);


        getlatlang();


        Log.e(TAG, "SelectProfiletypesActivity_onCreate: " + user_id);


        homeowner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usertype = "home_owner";
                temp_one = !temp_one;
//                green_check.setVisibility(temp_one ? VISIBLE:GONE);
                green_check.setVisibility(VISIBLE);
                green_check_sec.setVisibility(GONE);
                green_check_third.setVisibility(GONE);
                context = LocaleHelper.setLocale(SelectProfiletypesActivity.this, "en");
                resources = context.getResources();
                //messageView.setText("language");
//                homeowner.setBackgroundResource( temp_one ? R.drawable.background_selectonlang: R.drawable.line_border_bg);
//                serviceprovider.setBackgroundResource(temp_one ?R.drawable.line_border_bg : R.drawable.line_border_sec);
//                suppliers.setBackgroundResource(temp_one ? R.drawable.line_border_bg: R.drawable.line_border_sec);
                serviceprovider.setBackgroundResource(R.drawable.line_border_bg);
                homeowner.setBackgroundResource(R.drawable.background_selectonlang);
                material_supplier.setBackgroundResource(R.drawable.line_border_bg);
                next_btn_activity.setBackgroundResource(R.drawable.btn_accept_new_bg);
            }


        });

        serviceprovider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usertype = "service_provider";
                temp_two = !temp_two;
//                green_check_sec.setVisibility(temp_two ? VISIBLE : GONE);
                green_check_sec.setVisibility(VISIBLE);
                green_check_third.setVisibility(GONE);
                green_check.setVisibility(GONE);
                context = LocaleHelper.setLocale(SelectProfiletypesActivity.this, "hi");
                resources = context.getResources();

                //messageView.setText("language");

//                serviceprovider.setBackgroundResource(temp_two ? R.drawable.background_selectonlang: R.drawable.line_border_bg);
//                homeowner.setBackgroundResource(temp_two ? R.drawable.line_border_bg:R.drawable.line_border_sec);
//                suppliers.setBackgroundResource(temp_two ? R.drawable.line_border_bg:R.drawable.line_border_sec);
                homeowner.setBackgroundResource(R.drawable.line_border_bg);
                material_supplier.setBackgroundResource(R.drawable.line_border_bg);
                serviceprovider.setBackgroundResource(R.drawable.background_selectonlang);


                next_btn_activity.setBackgroundResource(R.drawable.btn_accept_new_bg);
            }

        });


        material_supplier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usertype = "material_supplier";
                temp_three = !temp_three;
//                green_check_third.setVisibility(temp_three ? VISIBLE:GONE);
                green_check_third.setVisibility(VISIBLE);
                green_check.setVisibility(GONE);
                green_check_sec.setVisibility(GONE);
                context = LocaleHelper.setLocale(SelectProfiletypesActivity.this, "en");
                resources = context.getResources();

                //messageView.setText("language");
//                homeowner.setBackgroundResource(temp_three ? R.drawable.line_border_bg: R.drawable.line_border_sec);
//                serviceprovider.setBackgroundResource(temp_three ? R.drawable.line_border_bg: R.drawable.line_border_sec);
//                suppliers.setBackgroundResource(temp_three ? R.drawable.background_selectonlang:R.drawable.line_border_sec);
                material_supplier.setBackgroundResource(R.drawable.background_selectonlang);
                homeowner.setBackgroundResource(R.drawable.line_border_bg);
                serviceprovider.setBackgroundResource(R.drawable.line_border_bg);


                next_btn_activity.setBackgroundResource(R.drawable.btn_accept_new_bg);
            }

        });


        next_btn_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (usertype.equalsIgnoreCase("home_owner")) {
//                    Intent intent = new Intent(SelectProfiletypesActivity.this,ActivityStageOfHouse.class);
//                    startActivity(intent);
                    M_type = "home_owner";
                    Update_Type(user_id, M_type);
                    Log.e(TAG, "+++usertype_home_owner_onClick: " + usertype);
                } else if (usertype.equalsIgnoreCase("service_provider")) {
//                    Intent intent = new Intent(SelectProfiletypesActivity.this,HomeActivity.class);
//                    startActivity(intent);
                    M_type = "service_provider";
                    Update_Type(user_id, M_type);
                    Log.e(TAG, "+++usertype_service_provider_onClick: " + usertype);
                } else if (usertype.equalsIgnoreCase("material_supplier")) {
//                    Intent intent = new Intent(SelectProfiletypesActivity.this,HomeActivity.class);
//                    startActivity(intent);
                    M_type = "material_supplier";
                    Update_Type(user_id, M_type);
                    Log.e(TAG, "+++usertype_material_supplier_onClick: " + usertype);
                } else {
                    Toast.makeText(SelectProfiletypesActivity.this, "Please choose one of the above options", Toast.LENGTH_SHORT).show();
                }
            }
        });


//        lang_continue.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//
//
//if (usertype == ""){
//    Toast.makeText(SelectProfiletypesActivity.this, "Please select a type", Toast.LENGTH_SHORT).show();
//    myDialog();
//}else   {
//
//    Intent intent = new Intent(SelectProfiletypesActivity.this, HomeActivity.class);
//    startActivity(intent);
//
//}
//
//            }
//
//        });


        CHOOSE_CITY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectProfiletypesActivity.this, SelectCityActivity.class);
                intent.putExtra("status_key", verify_staus);
                intent.putExtra("form_status", form_status);
                startActivity(intent);

            }

        });


    }

   /* private void getLocation() {
        double lat          =    gpsTracker.getLocation().getLatitude();
        double longitude    =  gpsTracker.getLocation().getLongitude();

        Log.e(ContentValues.TAG, "getLocation:lat "+lat );
        Log.e(ContentValues.TAG, "getLocation:longitude "+longitude );

//        Toast.makeText(ActivityLocation.this, gpsTracker.getLocation().toString(), Toast.LENGTH_SHORT).show();


        Geocoder geocoder = new Geocoder(SelectProfiletypesActivity.this, Locale.getDefault());
        List<Address>
                addresses = null;
        try {
            addresses = geocoder.getFromLocation(lat, longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (addresses.size() > 0) {
            Address address = addresses.get(0);
            locality     = address.getLocality();
            city         = address.getCountryName();
            region_code  = address.getCountryCode();
            zipcode      = address.getPostalCode();

//            Toast.makeText(ActivityLocation.this, "address =>" + locality, Toast.LENGTH_SHORT).show();
            Location_name.setText(locality);

            sessionLogOut.setLocName(locality);

        }*/
/*        if (ActivityCompat.checkSelfPermission(
                ActivityLocation.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                ActivityLocation.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                latitude = String.valueOf(lat);
                longitude = String.valueOf(longi);
                Log.e(TAG, "===latitude=getLocation: "+latitude);
                Log.e(TAG, "===longitude=getLocation: "+longitude);
//                showLocation.setText("Your Location: " + "\n" + "Latitude: " + latitude + "\n" + "Longitude: " + longitude);
            } else {
                Toast.makeText(this, "Unable to find location.", Toast.LENGTH_SHORT).show();
            }
        }*/


    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(SelectProfiletypesActivity.this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void Update_Type(String user_id, String usertype) {
        LayoutType_Progress.setVisibility(VISIBLE);
        Log.e(TAG, "Update_Type: ");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + update_type, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Log.e("-----Sign Up Acti  ", "-----logout: >>" + response);
                    if (jsonObject.getString("result").equals("true")) {
                        LayoutType_Progress.setVisibility(GONE);
                        sessionLogOut.setTypeSelect(true);
                        if (usertype.equalsIgnoreCase("home_owner")) {
                            session.setAppTYpe("home_owner");
                            Intent intent = new Intent(SelectProfiletypesActivity.this, ActivityNameHomeModule.class);
                            session.setLogin(true);
                            intent.putExtra("KeyType", M_type);
                            intent.putExtra("LOC", loca);
                            intent.putExtra("status_key", verify_staus);
                            intent.putExtra("form_status", form_status);
                            startActivity(intent);

                        } else if (usertype.equalsIgnoreCase("service_provider")) {
                            session.setLogin(true);
                            Intent intent = new Intent(SelectProfiletypesActivity.this, ProfessionalCategoryList.class);
                            intent.putExtra("status_key", verify_staus);
                            intent.putExtra("KeyType", M_type);
                            intent.putExtra("LOC", loca);
                            intent.putExtra("form_status", form_status);
                            intent.putExtra("KEYCITY", city_name);
                            startActivity(intent);

                        } else if (usertype.equalsIgnoreCase("material_supplier")) {

                            session.setLogin(true);
//                            Intent intent = new Intent(SelectProfiletypesActivity.this, MaterialProfessionalCateListActivity.class);
                            Intent intent = new Intent(SelectProfiletypesActivity.this, ProfessionalCategoryList.class);
                            intent.putExtra("KeyType", M_type);
                            intent.putExtra("KEYCITY", city_name);
                            intent.putExtra("LOC", loca);
                            intent.putExtra("status_key", verify_staus);
                            intent.putExtra("form_status", form_status);
                            intent.putExtra("TYPE", usertype);

                            startActivity(intent);

                        }
                    } else {

                        LayoutType_Progress.setVisibility(GONE);
                        Toast.makeText(SelectProfiletypesActivity.this, "error1" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {

                    LayoutType_Progress.setVisibility(GONE);
                    e.printStackTrace();
                    Toast.makeText(SelectProfiletypesActivity.this, "error2" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
                LayoutType_Progress.setVisibility(GONE);
                Toast.makeText(SelectProfiletypesActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("type", usertype);
                Log.e(TAG, "getParams: " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(SelectProfiletypesActivity.this).addToRequestQueue(stringRequest);
    }


    private void myDialog() {
        final Dialog dialog = new Dialog(SelectProfiletypesActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.popupdialog);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        TextView buttonShowDilog = dialog.findViewById(R.id.buttonOk);
        buttonShowDilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                Intent intent = new Intent(SelectProfiletypesActivity.this, HomeActivity.class);
                startActivity(intent);

            }
        }
    }


    public void getlatlang() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(SelectProfiletypesActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            //    Toast.makeText(LoginActivity.this,"You need have granted permission",Toast.LENGTH_SHORT).show();
            gps = new GPSTracker(getApplicationContext());
            if (gps.canGetLocation()) {
                Double latitude = gps.getLatitude();
                Double longitude = gps.getLongitude();
                String latt = String.valueOf(latitude);
                String longi = String.valueOf(longitude);

                List<Address> addresses = null;

                try {
                    Geocoder geocoder;
                    geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

                    addresses = geocoder.getFromLocation(latitude, longitude, 5); // Here 1 represent max location result to returned, by documents it recommended 1 to 5

                    String city = addresses.get(0).getLocality();
                    String subLocality = addresses.get(0).getSubLocality();
                    String state = addresses.get(0).getAdminArea();
                    String country = addresses.get(0).getCountryName();
                    String postalCode = addresses.get(0).getPostalCode();
                    Location_name.setText("" + subLocality + " " + city + " " + state + " " + " " + country);
                    Log.e(TAG, "getlatlang: " + addresses);
                    session.setcity_name(city);
                    Log.e(TAG, "---city: " + city);
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        }
    }

}
