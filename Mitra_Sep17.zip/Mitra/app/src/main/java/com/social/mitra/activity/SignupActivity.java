package com.social.mitra.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.hbb20.CountryCodePicker;
import com.social.mitra.ActivityLogin;
import com.social.mitra.R;
import com.social.mitra.sessionData.Session;


public class SignupActivity extends AppCompatActivity {


    Button AG_SIGNUP;
    TextView AG_FORGOTPASSWORD, AG_LOGIN;
    String[] sign_type = {"Select Profession", "Exporter", "Supplier", "Importer", "Buyer", "Broker", "International Buying Agent", "Logistics", "CHA", "ShippingAgent",
            "ShippingLines", "Warehouse", "Cold Storage", "Inspection", "Insurance", "Investor"};
    Spinner sign_upType_spinner;
    String select_sign_type = "";
    EditText full_name_edt, uniqe_username_edt, mobile_edt, email_edt;
    String country_code = "";
    Session session;
    CountryCodePicker ccp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        session = new Session(this);

        sign_upType_spinner = findViewById(R.id.sign_upType_spinner);
        AG_SIGNUP = findViewById(R.id.AG_SIGNUP);
        AG_LOGIN = findViewById(R.id.AG_LOGIN);
        full_name_edt = findViewById(R.id.full_name_edt);
        uniqe_username_edt = findViewById(R.id.uniqe_username_edt);
        mobile_edt = findViewById(R.id.mobile_edt);
        email_edt = findViewById(R.id.email_edt);
        ccp = findViewById(R.id.select_cc);


        ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected() {

                country_code = ccp.getSelectedCountryCode();
                Toast.makeText(SignupActivity.this, "" + country_code, Toast.LENGTH_SHORT).show();
            }
        });


        ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item,
                sign_type);
        sign_upType_spinner.setAdapter(spinnerArrayAdapter);


        sign_upType_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                select_sign_type = sign_type[position];
//                Toast.makeText(SignupActivity.this, ""+sign_type[position], Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        AG_SIGNUP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (full_name_edt.getText().toString().equals("")) {

                    full_name_edt.setFocusable(true);
                    full_name_edt.setError("Enter Your First Name");

                } else if (uniqe_username_edt.getText().toString().equals("")) {

                    uniqe_username_edt.setFocusable(true);
                    uniqe_username_edt.setError("Enter User Name");

                } else {

                    if (country_code.equals("")) {

                        ccp.setFocusable(true);

                    } else {

                        if (mobile_edt.getText().toString().equals("")) {
                            mobile_edt.setFocusable(true);
                            mobile_edt.setError("Enter User Mobile No.");

                        } else {

                            if (email_edt.getText().toString().equals("")) {
                                email_edt.setFocusable(true);
                                email_edt.setError("Enter Your Email");

                            } else {
                                  /*signUpUser();*/
                          //    Intent intent = new Intent(SignupActivity.this, OtpVerificationActivity.class);
                               // intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                //startActivity(intent);
                               // overridePendingTransition(R.anim.enter, R.anim.exit);

                            }
                        }
                    }


                }

            }
        });


        AG_LOGIN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, ActivityLogin.class);
                startActivity(intent);
                overridePendingTransition(R.anim.enter, R.anim.exit);
            }
        });


    }

//    private void signUpUser() {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + signup_user, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//                    Log.e("Sign Up Acti  ", "onResponse: >>" + jsonObject.toString());
//                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
//
//                        JSONObject data = jsonObject.getJSONObject("data");
//
//                        Log.e("Sign Up Acti  ", "onResponse: >>" + jsonObject.toString());
//
//                        String id = data.getString("id");
//                        String otp = data.getString("otp");
//
//                        progressDialog.dismiss();
//
//                        session.setLogin(true);
//                        session.setUser_Id(id);
//                        Toast.makeText(SignupActivity.this, ""+otp, Toast.LENGTH_LONG).show();
//                        Intent intent = new Intent(SignupActivity.this, OtpVerificationActivity.class);
//                        intent.putExtra("user_id",id);
//                        intent.putExtra("otp",otp);
//                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                        startActivity(intent);
//                        overridePendingTransition(R.anim.enter, R.anim.exit);
//
//                    } else {
//                        progressDialog.dismiss();
//                        Toast.makeText(SignupActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    Toast.makeText(SignupActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//                Toast.makeText(SignupActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> map = new HashMap<>();
//                map.put("name", full_name_edt.getText().toString());
//                map.put("username", uniqe_username_edt.getText().toString());
//                map.put("email", email_edt.getText().toString());
//                map.put("phone_number", mobile_edt.getText().toString());
//                map.put("countery_code", country_code);
//                map.put("fcm_id", "asdfhaiofhoa");
//
//                return map;
//            }
//        };
//
//        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
//    }
}