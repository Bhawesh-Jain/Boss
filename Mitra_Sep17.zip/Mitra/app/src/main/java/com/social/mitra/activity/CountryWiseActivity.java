package com.social.mitra.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.social.mitra.R;

public class CountryWiseActivity extends AppCompatActivity {


    TextView india, usa, sa, brazil;
    ImageView back_img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_wise);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        india = findViewById(R.id.india);
        usa = findViewById(R.id.usa);
        sa = findViewById(R.id.sa);
        brazil = findViewById(R.id.brazil);
        back_img = findViewById(R.id.back_img);


        india.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(CountryWiseActivity.this,SearchBuyLeadActivity.class).putExtra("type","India"));
            }
        });
        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onBackPressed();
           }
        });
        usa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CountryWiseActivity.this,SearchBuyLeadActivity.class).putExtra("type","USA"));

            }
        });
        sa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CountryWiseActivity.this,SearchBuyLeadActivity.class).putExtra("type","South Africa"));

            }
        });
        brazil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CountryWiseActivity.this,SearchBuyLeadActivity.class).putExtra("type","Brazil"));

            }
        });


    }
}