package com.social.mitra.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.R;
import com.social.mitra.activity.homePage.HomeActivity;
import com.social.mitra.adapter.MyJobAdapter;
import com.social.mitra.model.JobDataList;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_my_community;


public class MyJobsFragment extends Fragment {
    private static final String TAG = "MyJobsFragment";
    Session session;
    RecyclerView rv_posts;

    ArrayList<JobDataList> jobDataListArrayList = new ArrayList<>();
    String _liked;
    String _like_count;
    String _comment_count;
    String Community_id;
    String other = "", id = "";

    public MyJobsFragment(String other, String id) {
        this.other = other;
        this.id = id;
    }

    public MyJobsFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View root = inflater.inflate(R.layout.fragment_my_jobs, container, false);
        session = new Session(getActivity());
        rv_posts = root.findViewById(R.id.rv_posts);
        LinearLayout parent = root.findViewById(R.id.parent);

        parent.setOnClickListener(view -> {
            startActivity(new Intent(getContext(), HomeActivity.class));
            session.setValue("startWorkTab", "yes");
        });

        rv_posts.setOnClickListener(view -> {
            startActivity(new Intent(getContext(), HomeActivity.class));
            session.setValue("startWorkTab", "yes");
        });

        if (id.equalsIgnoreCase(""))
        _Get_Community(session.getUser_Id());
        else _Get_Community(id);

        return root;
    }


    private void _Get_Community(String user_idd) {
        Log.e(TAG, "***_Get_Community: ");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_my_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    Log.e(TAG, "onResponse: ");
//                    progressDialog.dismiss();
                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject dataObj = jsonArray.getJSONObject(i);

                            Community_id = dataObj.getString("id");

                            Log.e(TAG, "----Community_id: " + Community_id);

                            String id_ID = dataObj.getString("id");
                            String _name = dataObj.getString("name");
                            String _image = dataObj.getString("user_image");
                            String _required = dataObj.getString("required");
                            String _description = dataObj.getString("description");
                            String _created_date = dataObj.getString("created_date");
                            String _ago_time = dataObj.getString("ago_time");
                            String _community_image = dataObj.getString("community_image");
                            _liked = dataObj.getString("liked");
                            _like_count = dataObj.getString("like_count");
                            _comment_count = dataObj.getString("comment_count");
                            String city_name = dataObj.getString("city_name");
                            String user_type = dataObj.getString("usertype");
                            String post_user_category = dataObj.getString("my_category_name");
                            String is_phone = dataObj.getString("isphone");


                            JobDataList jobDataList = new JobDataList(Community_id, id_ID, _name, _image, _required, _description, _community_image, _created_date, _ago_time, _liked, _like_count, _comment_count, city_name, user_type, is_phone, post_user_category, "user_mobile");

                            jobDataListArrayList.add(jobDataList);
                        }
                        try {
                            MyJobAdapter jobAdapter = new MyJobAdapter(getActivity(), jobDataListArrayList, "community_path", other);
                            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
                            rv_posts.setLayoutManager(layoutManager);
                            rv_posts.setAdapter(jobAdapter);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, error -> Toast.makeText(getActivity(), "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_idd);

                Log.e(TAG, "getParams:  " + map);
                return map;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }
}