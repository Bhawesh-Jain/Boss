package com.social.mitra.interfa;

import com.social.mitra.model.SubCategoryModel;

public interface Sub_item_click {

    void SubItemClick(SubCategoryModel item);
}
