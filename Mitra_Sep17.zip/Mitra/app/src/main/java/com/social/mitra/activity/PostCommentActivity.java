package com.social.mitra.activity;

import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.USER_JOB_URL;
import static com.social.mitra.util.BaseUrl.comment_community;
import static com.social.mitra.util.BaseUrl.load_comments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.adapter.CommentListAdapter;
import com.social.mitra.adapter.CommentsAdapter;
import com.social.mitra.model.CommentsLists;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PostCommentActivity extends AppCompatActivity {
    private static final String TAG = "PostCommentActivity";
    TextView commnet_tv2, comment_post, __comment_post;
    RelativeLayout my_lay;
    EditText __comment_edt;
    ImageView back_img, USER_IMG__;
    Session session;
    String post_id, user_id;
    RecyclerView comments_recycler_view2;
    String Com_id;
    String User_id;
    String comments;
    ImageView Post_user_image;
    TextView _username, _position, _positionlocation, DESC;

    ArrayList<CommentsLists> commentsLists = new ArrayList<>();


    CommentListAdapter commentListAdapter;


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        session.setValue("firstTime", "false");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        session = new Session(PostCommentActivity.this);

        User_id = session.getUser_Id();

       /* my_lay = findViewById(R.id.my_lay);
        nice = findViewById(R.id.nice);
        wow = findViewById(R.id.wow);
        omg = findViewById(R.id.omg);
        congrats = findViewById(R.id.congrats);*/

        back_img = findViewById(R.id.back_img);


        commnet_tv2 = findViewById(R.id.commnet_tv2);


        Post_user_image = findViewById(R.id.Post_user_image);
        _username = findViewById(R.id._username);
        _position = findViewById(R.id._position);
        _positionlocation = findViewById(R.id._positionlocation);
        DESC = findViewById(R.id.DESC);
        USER_IMG__ = findViewById(R.id.USER_IMG__);
        __comment_edt = findViewById(R.id.__comment_edt);
        __comment_post = findViewById(R.id.__comment_post);
        comments_recycler_view2 = findViewById(R.id.comments_recycler_view2);


        if (getIntent() != null) {
            post_id = getIntent().getStringExtra("post_id");
            user_id = getIntent().getStringExtra("user_id");
            Com_id = getIntent().getStringExtra("id");
            Log.e(TAG, "onCreate:Com_id=-=--=    " + Com_id);
        }


        Load_Comments(Com_id);

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        __comment_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* if (!comment_edt.getText().toString().equals("")) {
                    my_lay.setVisibility(View.VISIBLE);
                    commnet_tv2.setText(comment_edt.getText().toString());
                    comment_edt.setText("");
//                    commentOnPost(comment_edt.getText().toString());
                } else {
                    my_lay.setVisibility(View.GONE);
                    comment_edt.setFocusable(true);
                    comment_edt.setError("Enter Your Comment");
                }*/
                Comment_Community(Com_id, User_id);
                __comment_edt.setText("");


            }
        });
    }

    private void Comment_Community(String com_id, String user_id) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        String COMMENT = __comment_edt.getText().toString();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + comment_community, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        Load_Comments(Com_id);

                    } else {
                        progressDialog.dismiss();

                        Toast.makeText(PostCommentActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    progressDialog.dismiss();

                    e.printStackTrace();
                    Toast.makeText(PostCommentActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Log.e("Post Comment", "onErrorResponse: " + error.getLocalizedMessage());
                Toast.makeText(PostCommentActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();

                map.put("community_id", com_id);
                map.put("user_id", user_id);
                map.put("comment", COMMENT);
                return map;
            }
        };
        VolleySingleton.getInstance(PostCommentActivity.this).addToRequestQueue(stringRequest);
    }


    private void Load_Comments(String com_id) {
        Log.e(TAG, "Load_Comments: ");
        Log.e(TAG, "--com_id_Load_Comments: " + com_id);
        commentsLists.clear();

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + load_comments, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();

                    Log.e(TAG, "onResponse: Load_Comments------     " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("datass");

                        String User_id = data.getString("id");
                        String description = data.getString("description");
                        String community_image = data.getString("community_image");
                        String user_id = data.getString("user_id");
                        String user_name = data.getString("user_name");
                        String user_image = data.getString("user_image");
                        Log.e(TAG, "----onResponse: " + description);
                        _username.setText(user_name);
                        _position.setText("indore");
                        _positionlocation.setText("1 hr");
                        DESC.setText(description);
                        Glide.with(PostCommentActivity.this).load(USER_JOB_URL + user_image)
                                .into(Post_user_image);

                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject dataObj = jsonArray.getJSONObject(i);

                                String _ID = dataObj.getString("id");

                                comments = dataObj.getString("comments");

                                Log.e(TAG, "=====comments: " + comments);

                                String created_date = dataObj.getString("created_date");
                                String _user_id = dataObj.getString("user_id");
                                String _user_name = dataObj.getString("user_name");
                                String _user_image = dataObj.getString("user_image");
                                String _like_counts = dataObj.getString("like_counts");

                                Log.e(TAG, "++++_user_name: " + _user_name);

                                CommentsLists commentsList = new CommentsLists(_ID, comments, created_date, _user_id, _user_name, _user_image, _like_counts);

                                commentsLists.add(commentsList);
                            }

                            CommentsAdapter commentsAdapter = new CommentsAdapter(commentsLists, PostCommentActivity.this);
                            LinearLayoutManager layoutManager = new LinearLayoutManager(PostCommentActivity.this, LinearLayoutManager.VERTICAL, false);
                            comments_recycler_view2.setLayoutManager(layoutManager);
                            comments_recycler_view2.setAdapter(commentsAdapter);
                        }

                    } else {
                        progressDialog.dismiss();


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();


                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Toast.makeText(PostCommentActivity.this, "onErrorResponse" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("community_id", com_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(TAG, "getParams:loginn onResponse " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

//    private void commentOnPost(String comment) {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + comment_on_post, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//
//                        progressDialog.dismiss();
//
//                    } else {
//                        progressDialog.dismiss();
//
//                        Toast.makeText(PostCommentActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//                    }
//                } catch (JSONException e) {
//                    progressDialog.dismiss();
//
//                    e.printStackTrace();
//                    Toast.makeText(PostCommentActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//
//                Log.e("Post Comment", "onErrorResponse: " + error.getLocalizedMessage());
//                Toast.makeText(PostCommentActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> map = new HashMap<>();
//
//                map.put("user_id", user_id);
//                map.put("post_id", post_id);
//                map.put("comment_text", comment_edt.getText().toString());
//                return map;
//            }
//        };
//    }
//
//
//    private void getAllcommentOnPost(String post_id) {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.show();
//
//        commentListModels.clear();
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + comment_on_post, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (jsonObject.getString("result").equals("true")) {
//
//                        progressDialog.dismiss();
//
//                        JSONArray jsonArray = jsonObject.getJSONArray("");
//                        for(int i=0;i<jsonArray.length();i++){
//
//                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
//
//                            CommentListModel commentListModel =new CommentListModel();
//                            commentListModel.setTime_ago(jsonObject1.getString(""));
//                            commentListModel.setTotalLike(jsonObject1.getString(""));
//                            commentListModel.setUserComment(jsonObject1.getString(""));
//                            commentListModel.setUserImage(jsonObject1.getString(""));
//                            commentListModel.setUserName(jsonObject1.getString(""));
//
//                            commentListModels.add(commentListModel);
//
//                        }
//
//                        commentListAdapter = new CommentListAdapter(PostCommentActivity.this,commentListModels);
//                        post_comment_list.setLayoutManager(new LinearLayoutManager(PostCommentActivity.this));
//                        post_comment_list.setAdapter(commentListAdapter);
//
//
//                    } else {
//                        progressDialog.dismiss();
//
//                        Toast.makeText(PostCommentActivity.this, "" + jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
//                    }
//                } catch (JSONException e) {
//                    progressDialog.dismiss();
//
//                    e.printStackTrace();
//                    Toast.makeText(PostCommentActivity.this, "" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progressDialog.dismiss();
//
//                Log.e("Post Comment", "onErrorResponse: " + error.getLocalizedMessage());
//                Toast.makeText(PostCommentActivity.this, "" + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> map = new HashMap<>();
//
//                map.put("post_id", post_id);
//                return map;
//            }
//        };
//        VolleySingleton.getInstance(PostCommentActivity.this).addToRequestQueue(stringRequest);
//    }

}