package com.social.mitra.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.mancj.materialsearchbar.MaterialSearchBar;
import com.mancj.materialsearchbar.adapter.SuggestionsAdapter;
import com.social.mitra.R;

import java.util.ArrayList;
import java.util.List;

public class SearchByCountryNameActivity extends AppCompatActivity {

    ImageView back_img;
    String product;
    MaterialSearchBar country_searchView;
    String[] country = {"India", "Nepal", "Bhutan", "America", "NewIsland"};

    List<String> suggestion_list = new ArrayList<>();
    List<String> suggestion_select_list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_by_country_name);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        back_img = findViewById(R.id.back_img);
        country_searchView = findViewById(R.id.country_searchView);


        if (getIntent() != null) {

            product = getIntent().getStringExtra("product");
        }
        Toast.makeText(this, "" + product, Toast.LENGTH_SHORT).show();

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        for (int i = 0; i < country.length; i++) {


            suggestion_list.add(country[i]);

        }


        country_searchView.enableSearch();

        country_searchView.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {

            }

            @Override
            public void onSearchConfirmed(CharSequence text) {

                startSearch(text.toString(), true, null, true);

            }

            @Override
            public void onButtonClicked(int buttonCode) {
                if (buttonCode == MaterialSearchBar.BUTTON_NAVIGATION) {
                    //opening or closing a navigation drawer
                } else if (buttonCode == MaterialSearchBar.BUTTON_BACK) {
                    country_searchView.disableSearch();
                }
            }
        });


        country_searchView.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                if (suggestion_list.size() > 0) {

                    country_searchView.showSuggestionsList();

                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.toString().equalsIgnoreCase("")) {

                } else {

                    suggestion_select_list.clear();
                    for (int i = 0; i < suggestion_list.size(); i++) {

                        if (suggestion_list.get(i).equalsIgnoreCase(s.toString())) {

                            suggestion_select_list.add(suggestion_list.get(i));
                        }
                    }

                    country_searchView.updateLastSuggestions(suggestion_select_list);

                    if (suggestion_select_list.size() > 0) {
                        if (!country_searchView.isSuggestionsVisible()) {
                            country_searchView.showSuggestionsList();
                        }
                    }
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        country_searchView.setSuggstionsClickListener(new SuggestionsAdapter.OnItemViewClickListener() {
            @Override
            public void OnItemClickListener(int position, View v) {

                if (suggestion_select_list.size() > 0) {
                    Toast.makeText(SearchByCountryNameActivity.this, "" + suggestion_select_list.get(position), Toast.LENGTH_SHORT).show();

                } else {

                    country_searchView.hideSuggestionsList();
                    Toast.makeText(SearchByCountryNameActivity.this, "Please Search Again", Toast.LENGTH_SHORT).show();

                }

            }

            @Override
            public void OnItemDeleteListener(int position, View v) {

                if (suggestion_select_list.size() > 0) {
                    suggestion_select_list.remove(position);
                    country_searchView.clearSuggestions();
                } else {
                    Toast.makeText(SearchByCountryNameActivity.this, "Please Search Again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}