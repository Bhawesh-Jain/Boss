package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.model.MainCatmodel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import static com.social.mitra.util.BaseUrl.IMAGE_URL;

public class MainprocatAdapter extends RecyclerView.Adapter<MainprocatAdapter.MyViewHolder> {

    Context context;
    ArrayList<MainCatmodel> followersListModels;

    public MainprocatAdapter(Context context, ArrayList<MainCatmodel> followersListModels) {
        this.context = context;
        this.followersListModels = followersListModels;

    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {

        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.followers_list_layout, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MainprocatAdapter.MyViewHolder holder, int position) {

        if (followersListModels.size() > 0) {

            holder.txtname.setText(followersListModels.get (position).getName());


        }
    }

    @Override
    public int getItemCount() {
        return followersListModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtname;
ImageView user_img;
        public MyViewHolder(@NonNull @NotNull View itemView) {

            super(itemView);
            txtname = itemView.findViewById(R.id.txtname);
            user_img = itemView.findViewById(R.id.user_img);
        }
    }

}
