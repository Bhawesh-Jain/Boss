package com.social.mitra.model;

public class SubCategoryModel {
    String sub_cate_id,sub_cate_name;

    public SubCategoryModel(String sub_cate_id, String sub_cate_name) {
        this.sub_cate_id = sub_cate_id;
        this.sub_cate_name = sub_cate_name;
    }

    public String getSub_cate_id() {
        return sub_cate_id;
    }

    public void setSub_cate_id(String sub_cate_id) {
        this.sub_cate_id = sub_cate_id;
    }

    public String getSub_cate_name() {
        return sub_cate_name;
    }

    public void setSub_cate_name(String sub_cate_name) {
        this.sub_cate_name = sub_cate_name;
    }
}
