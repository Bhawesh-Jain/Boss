package com.social.mitra;

import static android.content.ContentValues.TAG;
import static com.social.mitra.util.BaseUrl.Base_Url;
import static com.social.mitra.util.BaseUrl.get_profile;
import static com.social.mitra.util.BaseUrl.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.core.motion.utils.Oscillator;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.social.mitra.activity.OtpVerificationActivity;
import com.social.mitra.sessionData.Session;
import com.social.mitra.util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AboutFragmentothers#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AboutFragmentothers extends Fragment {
    TextView edit_profile,set_mobile_num,my_language,my_company,txtcomp;
    View root;

    Session session;
    String User_ID;
    String Mobile_Number;
    String lang = "English";
    String company = "self-employed";

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AboutFragmentothers() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AboutFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AboutFragmentothers newInstance(String param1, String param2) {
        AboutFragmentothers fragment = new AboutFragmentothers();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       root = inflater.inflate(R.layout.fragment_about2, container, false);
        edit_profile = root.findViewById(R.id.edit_profile);
        set_mobile_num = root.findViewById(R.id.set_mobile_num);
        my_language = root.findViewById(R.id.my_language);
        my_company = root.findViewById(R.id.my_company);
        txtcomp = root.findViewById(R.id.txtcomp);
        session  = new Session(getActivity());
        User_ID = session.getUser_Id();
        Mobile_Number = session.getMobile();
        Log.e(TAG, "AboutFragment_User_id: "+ Mobile_Number);

        Log.e(TAG, "AboutFragment_User_id: "+ User_ID);


        edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), UpdateDetailsActivity.class);
                startActivity(intent);


            }
        });

        Get_Profile(session.getUser_Id());
     return root;

    }


    private void Get_Profile(String user_id) {
        Log.e(Oscillator.TAG, "ProfileFragment_Get_Profile: ");
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_Url + get_profile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {

                    JSONObject jsonObject = new JSONObject(response);

                    progressDialog.dismiss();
                    Log.e(Oscillator.TAG, "onResponse: *****      " + response);

                    if (jsonObject.getString("result").equalsIgnoreCase("true")) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        String User_id = data.getString("id");
                        String name__ = data.getString("name");
                        String First_name = data.getString("fname");
                        String Last_name = data.getString("lname");
                        String Mobile_ = data.getString("mobile");
                        String TYPE = data.getString("type");
                        String IMAGGE = data.getString("image");
                        String company = data.getString("company");
                        String language = data.getString("language");


//                        Bundle simple_bundle=new Bundle();
//                        simple_bundle.putString("MOBILE",user_mobile);
//                        simple_bundle.putString("ID",User_id);
//                        simple_bundle.putString("OTP",user_otp);

                        set_mobile_num.setText(Mobile_);
                        my_language.setText(language);
                        my_company.setText(company);


                        txtcomp.setText(company);

                    } else {

                        progressDialog.dismiss();

                    }
                } catch (JSONException e) {

                    e.printStackTrace();

                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
//                map.put("fcm_id", "asdfhaiofhoa");
                Log.e(Oscillator.TAG, "--getParams:ProfileFragment " + map);
                return map;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }

}
