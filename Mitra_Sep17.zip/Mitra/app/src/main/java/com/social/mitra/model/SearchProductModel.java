package com.social.mitra.model;

public class SearchProductModel {

    String product_id,country_name,post_discription,post_qty,post_of_discharge,interasted_tv,post_date;

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public String getPost_discription() {
        return post_discription;
    }

    public void setPost_discription(String post_discription) {
        this.post_discription = post_discription;
    }

    public String getPost_qty() {
        return post_qty;
    }

    public void setPost_qty(String post_qty) {
        this.post_qty = post_qty;
    }

    public String getPost_of_discharge() {
        return post_of_discharge;
    }

    public void setPost_of_discharge(String post_of_discharge) {
        this.post_of_discharge = post_of_discharge;
    }

    public String getInterasted_tv() {
        return interasted_tv;
    }

    public void setInterasted_tv(String interasted_tv) {
        this.interasted_tv = interasted_tv;
    }

    public String getPost_date() {
        return post_date;
    }

    public void setPost_date(String post_date) {
        this.post_date = post_date;
    }


}
