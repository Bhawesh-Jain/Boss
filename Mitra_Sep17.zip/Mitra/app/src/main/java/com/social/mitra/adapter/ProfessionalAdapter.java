package com.social.mitra.adapter;

import static com.social.mitra.FilterActivity.selectedProfession;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.model.ProfessionalNameList;

import java.util.ArrayList;

public class ProfessionalAdapter extends RecyclerView.Adapter<ProfessionalAdapter.ViewHolderProfession> {
    private Context context;
    private ArrayList<ProfessionalNameList> data;

    public ProfessionalAdapter(Context applicationContext, ArrayList<ProfessionalNameList> professionalNameLists) {
        this.context = applicationContext;
        this.data = professionalNameLists;
    }

    @NonNull
    @Override
    public ViewHolderProfession onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolderProfession(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderProfession holder, int position) {
        if (data.get(position) != null){
            ProfessionalNameList nameList = data.get(position);
            holder.txt.setText(data.get(position).getProfession_name());

            holder.checkBox.setOnCheckedChangeListener((compoundButton, b) -> {
                try {
                    if (b){
                        selectedProfession.add(nameList);
                    } else selectedProfession.remove(nameList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolderProfession extends RecyclerView.ViewHolder {
        TextView txt;
        CheckBox checkBox;

        public ViewHolderProfession(@NonNull View itemView) {
            super(itemView);

            checkBox = itemView.findViewById(R.id.checkbox);
            txt = itemView.findViewById(R.id.texts_view);
        }
    }
}
