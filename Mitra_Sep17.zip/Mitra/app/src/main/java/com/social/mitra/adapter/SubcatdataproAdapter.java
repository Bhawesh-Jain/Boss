package com.social.mitra.adapter;

import static com.social.mitra.util.BaseUrl.IMAGE_URL;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.activity.VisitSingleProfileActivity;
import com.social.mitra.model.SubCatmodel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class SubcatdataproAdapter extends RecyclerView.Adapter<SubcatdataproAdapter.MyViewHolder> {
    private final Context context;
    private final ArrayList<SubCatmodel> followersListModels;

    public SubcatdataproAdapter(Context context, ArrayList<SubCatmodel> followersListModels) {
        this.context = context;
        this.followersListModels = followersListModels;
    }

    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.row_horizontal_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SubcatdataproAdapter.MyViewHolder holder, int position) {
        if (followersListModels.size() > 0) {
            SubCatmodel model = followersListModels.get(position);
            holder.txt.setText(model.getUser_name());
            holder.txtcat.setText(model.getCategory_name());
            holder.txtfolowers.setText(model.getFollowers_count());
            holder.txtpostcount.setText(model.getPost_counts());

            String mychar = "X";
            if (!model.getUser_name().equalsIgnoreCase(""))
                mychar = Character.toString(model.getUser_name().charAt(0)).toUpperCase();

            if (model.getUser_image().equalsIgnoreCase(""))
                holder.txtlet.setText(mychar.toUpperCase());
            else{
                Glide.with(context).load(IMAGE_URL + model.getUser_image()).into(holder.user_img);
                holder.txtlet.setVisibility(View.GONE);
                holder.user_img.setVisibility(View.VISIBLE);
            }
            holder.llclik.setOnClickListener(v -> {
                Intent intent = new Intent(context, VisitSingleProfileActivity.class);
                intent.putExtra("id", model.getUser_id());

                context.startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        if (followersListModels != null)
            return followersListModels.size();
        return 0;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txt, txtcat, txtfolowers, txtpostcount, txtlet;
        CircleImageView user_img;
        LinearLayout llclik;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txt = itemView.findViewById(R.id.txt);
            txtcat = itemView.findViewById(R.id.txtcat);
            user_img = itemView.findViewById(R.id.user_img);
            txtfolowers = itemView.findViewById(R.id.txtfolowers);
            llclik = itemView.findViewById(R.id.llclik);
            txtlet = itemView.findViewById(R.id.txtlet);
            txtpostcount = itemView.findViewById(R.id.txtpostcount);
        }
    }
}