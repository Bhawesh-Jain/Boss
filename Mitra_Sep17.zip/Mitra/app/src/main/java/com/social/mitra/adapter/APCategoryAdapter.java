package com.social.mitra.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.social.mitra.R;
import com.social.mitra.interfa.AddPostInterface;
import com.social.mitra.model.CityList;

import java.util.ArrayList;

public class APCategoryAdapter extends RecyclerView.Adapter<APCategoryAdapter.ViewHolder> {
    private final Context context;
    private ArrayList<CityList> cateList = new ArrayList<>();
    private final AddPostInterface addPostInterface;

    public APCategoryAdapter(Context context, ArrayList<CityList> cateList, AddPostInterface addPostInterface) {
        this.context = context;
        this.cateList = cateList;
        this.addPostInterface = addPostInterface;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (cateList != null)
            if (cateList.size() != 0){
                CityList model = cateList.get(holder.getAbsoluteAdapterPosition());

                holder.textView.setText(model.getCityName());

                holder.textView.setOnClickListener(view -> {
                    holder.textView.setBackgroundColor(context.getResources().getColor(R.color.gray_light));
                    addPostInterface.onCateClick(cateList.get(holder.getAbsoluteAdapterPosition()).getCityID());
                });
            }
    }

    @Override
    public int getItemCount() {
        return cateList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.user_notifi);

        }
    }
}
