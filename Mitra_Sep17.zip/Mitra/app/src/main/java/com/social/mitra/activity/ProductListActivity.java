package com.social.mitra.activity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.chip.Chip;
import com.social.mitra.R;
import com.social.mitra.adapter.SearchProductAdapter;
import com.social.mitra.model.SearchProductModel;
import com.social.mitra.sessionData.Session;

import java.util.ArrayList;

public class ProductListActivity extends AppCompatActivity {

    RecyclerView search_product_list;
    Chip chip_country, chip_company;
    ArrayList<SearchProductModel> searchProductModels = new ArrayList<>();

    ImageView back_img;

    SearchProductAdapter searchProductAdapter;
    String product = "";

    Session session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        chip_country = findViewById(R.id.chip_country);
        chip_company = findViewById(R.id.chip_company);
        search_product_list = findViewById(R.id.search_product_list);
        back_img = findViewById(R.id.back_img);
        session = new Session(this);

        if (getIntent() != null) {

            product = getIntent().getStringExtra("product");
        }


        chip_country.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                chip_country.setChipBackgroundColorResource(R.color.colorPrimary);
                chip_company.setChipBackgroundColorResource(R.color.gray_light);
                countryBottomsheet();

            }
        });

        chip_company.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chip_company.setChipBackgroundColorResource(R.color.colorPrimary);
                chip_country.setChipBackgroundColorResource(R.color.gray_light);

                companyBottomsheet();
            }
        });

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onBackPressed();

            }
        });

        setStaticData();

    }

    private void companyBottomsheet() {

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialog);

        bottomSheetDialog.setContentView(R.layout.company_bottomsheet);
        bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        bottomSheetDialog.setCanceledOnTouchOutside(true);


        RelativeLayout close_lay = bottomSheetDialog.findViewById(R.id.close_lay);


        close_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bottomSheetDialog.dismiss();

            }
        });


        bottomSheetDialog.show();
    }


    private void countryBottomsheet() {

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialog);

        bottomSheetDialog.setContentView(R.layout.country_bottomsheet);
        bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        bottomSheetDialog.setCanceledOnTouchOutside(true);


        RelativeLayout close_lay = bottomSheetDialog.findViewById(R.id.close_lay);


        close_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bottomSheetDialog.dismiss();

            }
        });


        bottomSheetDialog.show();
    }


    private void setStaticData() {
        for (int i = 0; i < 5; i++) {

            SearchProductModel searchProductModel = new SearchProductModel();

            searchProductModel.setCountry_name(product + "  " + i);
            searchProductModel.setPost_date("28/06/2021");
            searchProductModel.setPost_discription("fhsfaegfsdv sdhnsg sdgnoas sdgvoasd sdfv");
            searchProductModel.setPost_qty("10");
            searchProductModel.setProduct_id("" + i);
            searchProductModel.setPost_of_discharge("India");
            searchProductModels.add(searchProductModel);
        }


        searchProductAdapter = new SearchProductAdapter(this, searchProductModels);
        search_product_list.setLayoutManager(new LinearLayoutManager(ProductListActivity.this));
        search_product_list.setAdapter(searchProductAdapter);


    }

}