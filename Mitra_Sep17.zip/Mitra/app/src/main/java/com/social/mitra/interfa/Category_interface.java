package com.social.mitra.interfa;

import com.social.mitra.model.HouseGetCategoryModel;

public interface Category_interface {
    void onItemClick(HouseGetCategoryModel item);
}
