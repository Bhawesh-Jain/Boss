package com.social.mitra.adapter;

import static com.social.mitra.util.BaseUrl.City_url;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.social.mitra.R;
import com.social.mitra.interfa.CityItemClick;
import com.social.mitra.model.CityList;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class AdapterCityList extends RecyclerView.Adapter<AdapterCityList.MyViewHolder> {

    Context context;
    ArrayList<CityList> cityListArrayList;
    CityItemClick listener;
    int selectedPosition = -1;

    public AdapterCityList(Context context, ArrayList<CityList> cityListArrayList, CityItemClick listener) {
        this.context = context;
        this.cityListArrayList = cityListArrayList;
        this.listener = listener;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_list_city, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        if (cityListArrayList.size() > 0) {
            CityList cityList = cityListArrayList.get(position);


            holder.city_name.setText(cityList.getCityName());

            Glide.with(context).load(City_url + cityList.getCityImage()).into(holder.image_city);

            if (selectedPosition == position) {
                System.out.println("select pos  -----   ");
                holder.city_check.setVisibility(View.VISIBLE);
                holder.city_layout_click.setBackgroundDrawable(ContextCompat.getDrawable
                        (context, R.drawable.background_selectonlang));

            }else {
                System.out.println("deselect pos  -----   ");
                holder.city_check.setVisibility(View.GONE);
                holder.city_layout_click.setBackgroundDrawable(ContextCompat.getDrawable
                        (context, R.drawable.line_border_bg));

            }
            holder.city_layout_click.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedPosition = position;
                    notifyDataSetChanged();
                    listener.City_Item_Click(cityList);

                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return cityListArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout city_layout_click;
        ImageView city_check,image_city;
        TextView city_name;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            city_layout_click = itemView.findViewById(R.id.city_layout_click);
            city_check = itemView.findViewById(R.id.city_check);
            image_city = itemView.findViewById(R.id.image_city);
            city_name = itemView.findViewById(R.id.city_name);
            city_check.setVisibility(View.GONE);
        }
    }
}




