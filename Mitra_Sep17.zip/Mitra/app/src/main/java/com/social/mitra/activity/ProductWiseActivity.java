package com.social.mitra.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.social.mitra.R;

public class ProductWiseActivity extends AppCompatActivity {


    TextView spices, pulses, garment, rice;
    ImageView back_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_wise);
        //        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        spices = findViewById(R.id.spices);
        back_img = findViewById(R.id.back_img);
        pulses = findViewById(R.id.pulses);
        garment = findViewById(R.id.garment);
        rice = findViewById(R.id.rice);

        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        spices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(ProductWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Product  Spices"));
            }
        });
        pulses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(ProductWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Product  Pulses"));
            }
        });
        garment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProductWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Product  Garments"));

            }
        });
        rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(ProductWiseActivity.this, SearchBuyLeadActivity.class).putExtra("type", "Product  Rice"));
            }
        });
    }
}