package com.social.mitra.model;

public class SubCatmodel {

    String user_id,
    user_name,
            user_image,
    category_name,
            post_counts,
    followers_count,
            following_count, city_name;


    public SubCatmodel(String user_id, String user_name, String user_image, String category_name, String post_counts, String followers_count, String following_count, String city_name) {
        this.user_id = user_id;
        this.user_name = user_name;
        this.user_image = user_image;
        this.city_name = city_name;
        this.category_name = category_name;
        this.post_counts = post_counts;
        this.followers_count = followers_count;
        this.following_count = following_count;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getPost_counts() {
        return post_counts;
    }

    public void setPost_counts(String post_counts) {
        this.post_counts = post_counts;
    }

    public String getFollowers_count() {
        return followers_count;
    }

    public void setFollowers_count(String followers_count) {
        this.followers_count = followers_count;
    }

    public String getFollowing_count() {
        return following_count;
    }

    public void setFollowing_count(String following_count) {
        this.following_count = following_count;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }
}
